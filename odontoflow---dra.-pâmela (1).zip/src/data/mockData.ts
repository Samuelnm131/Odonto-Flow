import {
  Patient,
  Appointment,
  PatientDentalChart,
  Budget,
  ClinicalEvolution,
  ClinicalDocument,
  ClinicalPhoto,
  ConsentForm,
} from '../types';

export function getTodayString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getOffsetDateString(daysOffset: number): string {
  const d = new Date();
  d.setDate(d.getDate() + daysOffset);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const INITIAL_PATIENTS: Patient[] = [
  {
    id: 'pat-1',
    name: 'Ana Clara Santos',
    cpf: '123.456.789-01',
    phone: '(11) 98765-4321',
    birthDate: '1994-05-14',
    gender: 'feminino',
    profession: 'Arquiteta de Interiores',
    address: 'Av. Paulista, 1500, Apto 42 - Bela Vista, São Paulo - SP',
    emergencyContact: {
      name: 'Roberto Santos (Pai)',
      phone: '(11) 98888-1122',
      relationship: 'Pai',
    },
    allergies: ['Penicilina', 'Dipirona'],
    medicalAlerts: ['Rinite Alérgica', 'Hipotireoidismo'],
    currentMedications: 'Levotiroxina 50mcg em jejum',
    notes: 'Paciente relata sensibilidade térmica em molares superiores. Prefere anestesia sem vasoconstritor forte.',
    createdAt: '2025-01-15',
    generalHealth: {
      allergies: ['Penicilina', 'Dipirona'],
      systemicDiseases: ['Hipotireoidismo', 'Asma / Rinite'],
      continuousMedications: 'Levotiroxina 50mcg diário pela manhã',
      hasAnticoagulantsOrBisphosphonates: false,
      pregnancyStatus: 'nao',
      healingOrBleedingIssues: false,
      habitsSmoking: 'nao',
      habitsAlcohol: 'socialmente',
    },
    dentalHealth: {
      chiefComplaint: 'Sensibilidade aguda ao tomar água gelada e incômodo estético em dente superior.',
      lastDentalVisit: '6 a 12 meses',
      brushingFrequency: '3x ou mais ao dia',
      flossFrequency: 'Diariamente',
      toothSensitivity: { cold: true, hot: false, sweet: true },
      gumBleeding: 'ao_escovar',
      tmjOrBruxism: { jawPainOrClicking: false, bruxismOrClenching: false },
      previousAnestheticReactions: 'Nenhuma reação adversa conhecida.',
    },
  },
  {
    id: 'pat-2',
    name: 'Carlos Eduardo Silva',
    cpf: '234.567.890-12',
    phone: '(11) 99123-8877',
    birthDate: '1982-10-25',
    gender: 'masculino',
    profession: 'Engenheiro de Software',
    address: 'Rua Oscar Freire, 820 - Jardins, São Paulo - SP',
    emergencyContact: {
      name: 'Luciana Silva (Esposa)',
      phone: '(11) 99333-4455',
      relationship: 'Esposa',
    },
    allergies: [],
    medicalAlerts: ['Hipertensão Controlada'],
    currentMedications: 'Losartana 50mg pela manhã',
    notes: 'Histórico de bruxismo noturno. Faz uso de placa miorrelaxante.',
    createdAt: '2025-02-02',
    generalHealth: {
      allergies: [],
      systemicDiseases: ['Hipertensão arterial'],
      continuousMedications: 'Losartana Potássica 50mg',
      hasAnticoagulantsOrBisphosphonates: false,
      pregnancyStatus: 'nao',
      healingOrBleedingIssues: false,
      habitsSmoking: 'ex_fumante',
      habitsAlcohol: 'socialmente',
    },
    dentalHealth: {
      chiefComplaint: 'Apertamento dental ao acordar, dor nos músculos masseteres e desgaste incisal.',
      lastDentalVisit: 'Menos de 6 meses',
      brushingFrequency: '2x ao dia',
      flossFrequency: 'Às vezes',
      toothSensitivity: { cold: true, hot: false, sweet: false },
      gumBleeding: 'nenhum',
      tmjOrBruxism: { jawPainOrClicking: true, bruxismOrClenching: true },
      previousAnestheticReactions: 'Sem intercorrências prévias.',
    },
  },
  {
    id: 'pat-3',
    name: 'Beatriz Lima Rocha',
    cpf: '345.678.901-23',
    phone: '(11) 97654-3210',
    birthDate: '1998-08-30',
    gender: 'feminino',
    profession: 'Advogada',
    address: 'Rua Vergueiro, 2400, Bloco B - Vila Mariana, São Paulo - SP',
    emergencyContact: {
      name: 'Marcos Rocha (Marido)',
      phone: '(11) 97111-2233',
      relationship: 'Cônjuge',
    },
    allergies: ['Látex'],
    medicalAlerts: ['Gestante (2º Trimestre)'],
    currentMedications: 'Polivitamínico pré-natal e Ômega 3',
    notes: 'Atenção especial: gestante de 18 semanas. Usar luvas nitrílicas livres de látex.',
    createdAt: '2025-02-18',
    generalHealth: {
      allergies: ['Látex'],
      systemicDiseases: [],
      continuousMedications: 'Polivitamínico Pré-Natal, Sulfato Ferroso',
      hasAnticoagulantsOrBisphosphonates: false,
      pregnancyStatus: 'gestante',
      pregnancyDetails: '18 semanas (2º trimestre de gestação)',
      healingOrBleedingIssues: false,
      habitsSmoking: 'nao',
      habitsAlcohol: 'nao',
    },
    dentalHealth: {
      chiefComplaint: 'Gengiva inchada e sangrando ao escovar (gengivite gravídica) e profilaxia de rotina.',
      lastDentalVisit: '6 a 12 meses',
      brushingFrequency: '3x ou mais ao dia',
      flossFrequency: 'Diariamente',
      toothSensitivity: { cold: false, hot: false, sweet: false },
      gumBleeding: 'ao_escovar',
      tmjOrBruxism: { jawPainOrClicking: false, bruxismOrClenching: false },
      previousAnestheticReactions: 'Preferência por anestesia odontológica segura para gestantes.',
    },
  },
  {
    id: 'pat-4',
    name: 'Mateus Oliveira Costa',
    cpf: '456.789.012-34',
    phone: '(11) 98234-5678',
    birthDate: '2001-03-12',
    gender: 'masculino',
    profession: 'Estudante Universitário',
    address: 'Rua Augusta, 1100 - Consolação, São Paulo - SP',
    emergencyContact: {
      name: 'Cláudia Costa (Mãe)',
      phone: '(11) 98111-9988',
      relationship: 'Mãe',
    },
    allergies: [],
    medicalAlerts: ['Ansiedade Odontológica'],
    currentMedications: '',
    notes: 'Paciente demonstra fobia a agulhas. Explicar procedimentos com calma e aplicar anestésico tópico generoso.',
    createdAt: '2025-03-01',
    generalHealth: {
      allergies: [],
      systemicDiseases: ['Ansiedade Odontológica / Fobia'],
      continuousMedications: '',
      hasAnticoagulantsOrBisphosphonates: false,
      pregnancyStatus: 'nao',
      healingOrBleedingIssues: true,
      healingBleedingNotes: 'Episódio de lipotimia / tontura em consultório anterior por ansiedade.',
      habitsSmoking: 'nao',
      habitsAlcohol: 'socialmente',
    },
    dentalHealth: {
      chiefComplaint: 'Avaliação inicial para clareamento dental e limpeza geral.',
      lastDentalVisit: 'Mais de 1 ano',
      brushingFrequency: '2x ao dia',
      flossFrequency: 'Raramente / Nunca',
      toothSensitivity: { cold: false, hot: false, sweet: false },
      gumBleeding: 'ao_escovar',
      tmjOrBruxism: { jawPainOrClicking: false, bruxismOrClenching: false },
      previousAnestheticReactions: 'Sensação de taquicardia associada a ansiedade.',
    },
  },
  {
    id: 'pat-5',
    name: 'Mariana Duarte Mendes',
    cpf: '567.890.123-45',
    phone: '(11) 99876-1122',
    birthDate: '1976-07-09',
    gender: 'feminino',
    profession: 'Professora',
    address: 'Alameda Santos, 600 - Cerqueira César, São Paulo - SP',
    emergencyContact: {
      name: 'Paulo Mendes (Esposo)',
      phone: '(11) 99444-5566',
      relationship: 'Cônjuge',
    },
    allergies: ['Anti-inflamatórios (AINEs)'],
    medicalAlerts: ['Diabetes Tipo 2'],
    currentMedications: 'Metformina 850mg 2x/dia',
    notes: 'Glicemia controlada. Acompanhamento semestral para profilaxia periodontal.',
    createdAt: '2025-03-10',
    generalHealth: {
      allergies: ['Anti-inflamatórios (AINEs)'],
      systemicDiseases: ['Diabetes Tipo 2'],
      continuousMedications: 'Metformina 850mg 2x ao dia após refeições',
      hasAnticoagulantsOrBisphosphonates: false,
      pregnancyStatus: 'nao',
      healingOrBleedingIssues: true,
      healingBleedingNotes: 'Cicatrização mais demorada devido ao diabetes.',
      habitsSmoking: 'nao',
      habitsAlcohol: 'nao',
    },
    dentalHealth: {
      chiefComplaint: 'Dor pulsátil ao mastigar no primeiro molar superior direito (dente 16).',
      lastDentalVisit: 'Mais de 1 ano',
      brushingFrequency: '2x ao dia',
      flossFrequency: 'Diariamente',
      toothSensitivity: { cold: true, hot: true, sweet: true },
      gumBleeding: 'espontaneo',
      tmjOrBruxism: { jawPainOrClicking: false, bruxismOrClenching: false },
      previousAnestheticReactions: 'Sem reações conhecidas.',
    },
  },
  {
    id: 'pat-6',
    name: 'Juliana Mendonça',
    cpf: '678.901.234-56',
    phone: '(11) 97123-4567',
    birthDate: `${new Date().getFullYear() - 32}-${String(new Date().getMonth() + 1).padStart(2, '0')}-12`,
    gender: 'feminino',
    profession: 'Designer Gráfica',
    address: 'Rua Bela Cintra, 740 - Consolação, São Paulo - SP',
    emergencyContact: {
      name: 'Felipe Mendonça (Irmão)',
      phone: '(11) 97999-1122',
      relationship: 'Irmão',
    },
    allergies: [],
    medicalAlerts: [],
    currentMedications: '',
    notes: 'Paciente muito cuidadosa com higiene bucal. Retorno para profilaxia a cada 6 meses.',
    createdAt: '2024-06-15',
    generalHealth: {
      allergies: [],
      systemicDiseases: [],
      continuousMedications: '',
      hasAnticoagulantsOrBisphosphonates: false,
      pregnancyStatus: 'nao',
      healingOrBleedingIssues: false,
      habitsSmoking: 'nao',
      habitsAlcohol: 'socialmente',
    },
    dentalHealth: {
      chiefComplaint: 'Manutenção preventiva periódica e polimento de resinas.',
      lastDentalVisit: 'Mais de 6 meses',
      brushingFrequency: '3x ou mais ao dia',
      flossFrequency: 'Diariamente',
      toothSensitivity: { cold: false, hot: false, sweet: false },
      gumBleeding: 'nenhum',
      tmjOrBruxism: { jawPainOrClicking: false, bruxismOrClenching: false },
      previousAnestheticReactions: 'Sem intercorrências.',
    },
  },
  {
    id: 'pat-7',
    name: 'Lucas Gabriel Souza (Infantil)',
    cpf: '789.012.345-67',
    phone: '(11) 98456-7890',
    birthDate: `${new Date().getFullYear() - 8}-${String(new Date().getMonth() + 1).padStart(2, '0')}-25`,
    gender: 'masculino',
    profession: 'Estudante (8 anos)',
    address: 'Rua Pamplona, 450 - Jardim Paulista, São Paulo - SP',
    emergencyContact: {
      name: 'Mariana Souza (Mãe)',
      phone: '(11) 98456-7890',
      relationship: 'Mãe',
    },
    allergies: [],
    medicalAlerts: ['Odontopediatria', 'Dentição Mista / Decídua'],
    currentMedications: '',
    notes: 'Paciente infantil. Muito cooperativo com reforço positivo lúdico. Troca de dentição decídua para permanente.',
    createdAt: '2024-07-20',
    generalHealth: {
      allergies: [],
      systemicDiseases: [],
      continuousMedications: '',
      hasAnticoagulantsOrBisphosphonates: false,
      pregnancyStatus: 'nao',
      healingOrBleedingIssues: false,
      habitsSmoking: 'nao',
      habitsAlcohol: 'nao',
    },
    dentalHealth: {
      chiefComplaint: 'Acompanhamento de erupção de dentes permanentes e prevenção de cáries em dentes decíduos.',
      lastDentalVisit: 'Mais de 6 meses',
      brushingFrequency: '2x ao dia',
      flossFrequency: 'Às vezes',
      toothSensitivity: { cold: false, hot: false, sweet: false },
      gumBleeding: 'nenhum',
      tmjOrBruxism: { jawPainOrClicking: false, bruxismOrClenching: false },
      previousAnestheticReactions: 'Nenhuma.',
    },
  },
];

export function getInitialAppointments(): Appointment[] {
  const today = getTodayString();
  const tomorrow = getOffsetDateString(1);
  const yesterday = getOffsetDateString(-1);

  return [
    {
      id: 'apt-1',
      patientId: 'pat-1',
      patientName: 'Ana Clara Santos',
      patientPhone: '(11) 98765-4321',
      date: today,
      time: '09:00',
      durationMinutes: 45,
      procedure: 'Restauração em Resina Composta',
      status: 'confirmado',
      notes: 'Restauração oclusal dente 16 e acabamento estético.',
      estimatedPrice: 320,
    },
    {
      id: 'apt-2',
      patientId: 'pat-2',
      patientName: 'Carlos Eduardo Silva',
      patientPhone: '(11) 99123-8877',
      date: today,
      time: '10:30',
      durationMinutes: 30,
      procedure: 'Ajuste Oclusal / Placa de Bruximsmo',
      status: 'agendado',
      notes: 'Verificar retenção e pontos de contato da placa acrílica.',
      estimatedPrice: 180,
    },
    {
      id: 'apt-3',
      patientId: 'pat-3',
      patientName: 'Beatriz Lima Rocha',
      patientPhone: '(11) 97654-3210',
      date: today,
      time: '14:00',
      durationMinutes: 45,
      procedure: 'Profilaxia e Limpeza',
      status: 'confirmado',
      notes: 'Lembrar de luvas sem látex. Gestante no 2º trimestre.',
      estimatedPrice: 250,
    },
    {
      id: 'apt-4',
      patientId: 'pat-4',
      patientName: 'Mateus Oliveira Costa',
      patientPhone: '(11) 98234-5678',
      date: today,
      time: '16:00',
      durationMinutes: 60,
      procedure: 'Avaliação Inicial / Check-up',
      status: 'agendado',
      notes: 'Primeira consulta com a Dra. Pâmela. Exame clínico completo.',
      estimatedPrice: 150,
    },
    {
      id: 'apt-5',
      patientId: 'pat-5',
      patientName: 'Mariana Duarte Mendes',
      patientPhone: '(11) 99876-1122',
      date: tomorrow,
      time: '10:00',
      durationMinutes: 60,
      procedure: 'Endodontia (Tratamento de Canal)',
      status: 'agendado',
      notes: 'Sessão única se ausência de exsudato.',
      estimatedPrice: 850,
    },
    {
      id: 'apt-6',
      patientId: 'pat-1',
      patientName: 'Ana Clara Santos',
      patientPhone: '(11) 98765-4321',
      date: yesterday,
      time: '15:00',
      durationMinutes: 30,
      procedure: 'Profilaxia e Limpeza',
      status: 'concluido',
      notes: 'Profilaxia realizada com ultrassom e jato de bicarbonato.',
      estimatedPrice: 220,
    },
    {
      id: 'apt-7',
      patientId: 'pat-6',
      patientName: 'Juliana Mendonça',
      patientPhone: '(11) 97123-4567',
      date: getOffsetDateString(-210), // ~7 meses atrás (sem retorno agendado)
      time: '14:30',
      durationMinutes: 45,
      procedure: 'Profilaxia e Raspagem Subgengival',
      status: 'concluido',
      notes: 'Limpeza semestral concluída. Recomendado retorno preventivo em 6 meses.',
      estimatedPrice: 280,
    },
    {
      id: 'apt-8',
      patientId: 'pat-7',
      patientName: 'Lucas Gabriel Souza (Infantil)',
      patientPhone: '(11) 98456-7890',
      date: getOffsetDateString(-195), // ~6.5 meses atrás (sem retorno agendado)
      time: '11:00',
      durationMinutes: 40,
      procedure: 'Aplicação Tópica de Flúor e Profilaxia Infantil',
      status: 'concluido',
      notes: 'Odontopediatria. Excelente colaboração. Retorno preventivo recomendado.',
      estimatedPrice: 200,
    },
  ];
}

export const INITIAL_DENTAL_CHARTS: Record<string, PatientDentalChart> = {
  'pat-1': {
    16: {
      toothNumber: 16,
      status: 'tratamento_necessario',
      conditionTitle: 'Cárie Oclusal ativa',
      facesAffected: ['O'],
      estimatedPrice: 320,
      notes: 'Lesão cariosa em esmalte e dentina média. Indicação de restauração em resina.',
      updatedAt: '2025-03-12',
    },
    11: {
      toothNumber: 11,
      status: 'tratamento_concluido',
      conditionTitle: 'Faceta em Resina',
      facesAffected: ['V'],
      estimatedPrice: 650,
      notes: 'Facetamento estético realizado com sucesso.',
      updatedAt: '2025-01-20',
    },
    24: {
      toothNumber: 24,
      status: 'tratamento_concluido',
      conditionTitle: 'Restauração MO',
      facesAffected: ['M', 'O'],
      estimatedPrice: 320,
      notes: 'Restauração em resina composta Z350.',
      updatedAt: '2025-02-10',
    },
    48: {
      toothNumber: 48,
      status: 'ausente_extraido',
      conditionTitle: 'Exodontia de Siso',
      notes: 'Extraído em 2024 sem intercorrências.',
      updatedAt: '2024-11-05',
    },
    38: {
      toothNumber: 38,
      status: 'ausente_extraido',
      conditionTitle: 'Exodontia de Siso',
      notes: 'Extraído em 2024.',
      updatedAt: '2024-11-05',
    },
  },
  'pat-2': {
    26: {
      toothNumber: 26,
      status: 'tratamento_necessario',
      conditionTitle: 'Infiltração marginal em amálgama',
      facesAffected: ['O', 'D'],
      estimatedPrice: 350,
      notes: 'Troca de restauração antiga por resina estética recomendada.',
      updatedAt: '2025-02-15',
    },
    36: {
      toothNumber: 36,
      status: 'tratamento_concluido',
      conditionTitle: 'Coroa Metalocerâmica',
      estimatedPrice: 1600,
      notes: 'Excelente adaptação marginal e oclusão ajustada.',
      updatedAt: '2024-09-12',
    },
  },
  'pat-7': {
    54: {
      toothNumber: 54,
      status: 'tratamento_concluido',
      conditionTitle: 'Restauração Ionômero de Vidro',
      facesAffected: ['O'],
      estimatedPrice: 190,
      notes: 'Primeiro molar decíduo superior direito restaurado.',
      updatedAt: '2025-01-10',
    },
    65: {
      toothNumber: 65,
      status: 'tratamento_necessario',
      conditionTitle: 'Selante Preventivo de Fissuras',
      facesAffected: ['O'],
      estimatedPrice: 140,
      notes: 'Segundo molar decíduo superior esquerdo necessita selamento.',
      updatedAt: '2025-02-15',
    },
  },
};

export const INITIAL_CLINICAL_EVOLUTIONS: Record<string, ClinicalEvolution[]> = {
  'pat-1': [
    {
      id: 'evo-1',
      patientId: 'pat-1',
      date: getOffsetDateString(-1),
      time: '15:30',
      author: 'Dra. Pâmela',
      procedureDone: 'Profilaxia e Limpeza Ultrassônica',
      toothNumber: 16,
      anestheticUsed: 'Tópico de Lidocaína 5%',
      content: 'Realizada profilaxia com ultrassom e aplicação tópica de flúor neutro. Observada cárie ativa na face oclusal do dente 16. Orientada quanto a higiene e agendada restauração estética.',
      nextSessionPlan: 'Restauração em resina composta no dente 16.',
    },
    {
      id: 'evo-2',
      patientId: 'pat-1',
      date: getOffsetDateString(-30),
      time: '10:00',
      author: 'Dra. Pâmela',
      procedureDone: 'Avaliação Inicial e Fotos Intraorais',
      content: 'Exame clínico geral. Paciente queixa-se de sensibilidade térmica ao frio. Confirmadas alergias a Penicilina e Dipirona na anamnese.',
      nextSessionPlan: 'Profilaxia e planejamento de facetas estéticas.',
    },
  ],
  'pat-2': [
    {
      id: 'evo-3',
      patientId: 'pat-2',
      date: getOffsetDateString(-2),
      time: '11:15',
      author: 'Dra. Pâmela',
      procedureDone: 'Moldagem para Placa de Bruxismo',
      content: 'Moldagem das arcadas com hidrocolóide para confecção de placa miorrelaxante em acrílico. Paciente relata dores matinais nos masseteres.',
      nextSessionPlan: 'Instalação e ajuste oclusal com carbono fino.',
    },
  ],
};

export const INITIAL_BUDGETS: Budget[] = [
  {
    id: 'bdg-1',
    patientId: 'pat-1',
    patientName: 'Ana Clara Santos',
    patientPhone: '(11) 98765-4321',
    date: getTodayString(),
    items: [
      { id: 'bi-1', description: 'Restauração Resina Dente 16', toothNumber: 16, value: 320 },
      { id: 'bi-2', description: 'Clareamento Dental Caseiro c/ Moldeira', value: 750 },
    ],
    totalValue: 1070,
    status: 'pendente',
    paymentMethod: 'pix',
    notes: 'Aguardando confirmação do pagamento inicial',
  },
  {
    id: 'bdg-2',
    patientId: 'pat-2',
    patientName: 'Carlos Eduardo Silva',
    patientPhone: '(11) 99123-8877',
    date: getOffsetDateString(-2),
    items: [
      { id: 'bi-3', description: 'Substituição de Amálgama Dente 26', toothNumber: 26, value: 350 },
      { id: 'bi-4', description: 'Nova Placa de Bruxismo em Acrílico', value: 600 },
    ],
    totalValue: 950,
    status: 'aprovado',
    paymentMethod: 'cartao_credito',
    approvedDate: getOffsetDateString(-1),
    notes: 'Aprovado em 3x sem juros no cartão',
  },
  {
    id: 'bdg-3',
    patientId: 'pat-4',
    patientName: 'Mateus Oliveira Costa',
    patientPhone: '(11) 98234-5678',
    date: getTodayString(),
    items: [
      { id: 'bi-5', description: 'Profilaxia e Aplicação Tópica de Flúor', value: 240 },
    ],
    totalValue: 240,
    status: 'pendente',
    paymentMethod: 'pix',
  },
  {
    id: 'bdg-4',
    patientId: 'pat-3',
    patientName: 'Beatriz Lima Rocha',
    patientPhone: '(11) 97654-3210',
    date: getOffsetDateString(-12),
    items: [
      { id: 'bi-6', description: 'Profilaxia Pré-Natal Especial', value: 280 },
      { id: 'bi-7', description: 'Tratamento Gengival Suave', value: 350 },
    ],
    totalValue: 630,
    status: 'aprovado',
    paymentMethod: 'pix',
    approvedDate: getOffsetDateString(-10),
  },
  {
    id: 'bdg-5',
    patientId: 'pat-5',
    patientName: 'Mariana Duarte Mendes',
    patientPhone: '(11) 99876-1122',
    date: getOffsetDateString(-25),
    items: [
      { id: 'bi-8', description: 'Tratamento Endodôntico (Canal)', value: 850 },
      { id: 'bi-9', description: 'Restauração Provisória e Definitiva', value: 400 },
    ],
    totalValue: 1250,
    status: 'aprovado',
    paymentMethod: 'cartao_credito',
    approvedDate: getOffsetDateString(-23),
  },
  {
    id: 'bdg-6',
    patientId: 'pat-1',
    patientName: 'Ana Clara Santos',
    patientPhone: '(11) 98765-4321',
    date: getOffsetDateString(-45),
    items: [
      { id: 'bi-10', description: 'Faceta em Resina Dente 11', toothNumber: 11, value: 650 },
      { id: 'bi-11', description: 'Restauração MO Dente 24', toothNumber: 24, value: 320 },
    ],
    totalValue: 970,
    status: 'aprovado',
    paymentMethod: 'pix',
    approvedDate: getOffsetDateString(-44),
  },
  {
    id: 'bdg-7',
    patientId: 'pat-2',
    patientName: 'Carlos Eduardo Silva',
    patientPhone: '(11) 99123-8877',
    date: getOffsetDateString(-60),
    items: [
      { id: 'bi-12', description: 'Coroa Metalocerâmica Dente 36', toothNumber: 36, value: 1600 },
    ],
    totalValue: 1600,
    status: 'aprovado',
    paymentMethod: 'cartao_credito',
    approvedDate: getOffsetDateString(-58),
  },
];

export const HISTORICAL_MONTHLY_DATA = [
  {
    month: 'Mai',
    fullMonth: 'Maio',
    faturamento: 14200,
    orcamentosAprovados: 16500,
    orcamentosPendentes: 3200,
    qtdConsultas: 38,
    qtdAprovados: 12,
  },
  {
    month: 'Jun',
    fullMonth: 'Junho',
    faturamento: 16800,
    orcamentosAprovados: 18400,
    orcamentosPendentes: 2900,
    qtdConsultas: 44,
    qtdAprovados: 15,
  },
  {
    month: 'Jul',
    fullMonth: 'Julho',
    faturamento: 15300,
    orcamentosAprovados: 14900,
    orcamentosPendentes: 4100,
    qtdConsultas: 40,
    qtdAprovados: 11,
  },
  {
    month: 'Ago',
    fullMonth: 'Agosto',
    faturamento: 19100,
    orcamentosAprovados: 21800,
    orcamentosPendentes: 3800,
    qtdConsultas: 49,
    qtdAprovados: 18,
  },
  {
    month: 'Set',
    fullMonth: 'Setembro',
    faturamento: 22400,
    orcamentosAprovados: 24600,
    orcamentosPendentes: 3100,
    qtdConsultas: 56,
    qtdAprovados: 21,
  },
  {
    month: 'Out',
    fullMonth: 'Outubro (Atual)',
    faturamento: 18750,
    orcamentosAprovados: 22100,
    orcamentosPendentes: 2260,
    qtdConsultas: 42,
    qtdAprovados: 17,
  },
];

export const REVENUE_BY_PROCEDURE = [
  { procedure: 'Restaurações', valor: 28400, consultas: 82 },
  { procedure: 'Endodontia', valor: 22100, consultas: 26 },
  { procedure: 'Clareamentos', valor: 18900, consultas: 22 },
  { procedure: 'Próteses & Coroas', valor: 17500, consultas: 14 },
  { procedure: 'Profilaxias', valor: 12800, consultas: 58 },
  { procedure: 'Placas Bruxismo', valor: 7850, consultas: 12 },
];

export interface MedicationPreset {
  id: string;
  name: string;
  posology: string;
  quantity: string;
  notes?: string;
  category: 'analgesico' | 'antibiotico' | 'antiinflamatorio' | 'antisseptico' | 'corticoide';
}

export const MEDICATION_PRESETS: MedicationPreset[] = [
  {
    id: 'med-1',
    name: 'Dipirona Sódica 500mg',
    posology: 'Tomar 1 comprimido via oral de 6 em 6 horas se houver dor ou febre (não exceder 4 comprimidos ao dia).',
    quantity: '1 caixa (10 comprimidos)',
    notes: 'Uso se dor. Pacientes com alergia prévia a pirazolonas não devem utilizar.',
    category: 'analgesico',
  },
  {
    id: 'med-2',
    name: 'Amoxicilina 500mg',
    posology: 'Tomar 1 cápsula via oral de 8 em 8 horas durante 7 dias consecutivos, sem interrupção.',
    quantity: '1 caixa (21 cápsulas)',
    notes: 'Ingerir com bastante água. Manter horário rigoroso.',
    category: 'antibiotico',
  },
  {
    id: 'med-3',
    name: 'Nimesulida 100mg',
    posology: 'Tomar 1 comprimido via oral de 12 em 12 horas após as principais refeições por até 3 a 5 dias.',
    quantity: '1 caixa (12 comprimidos)',
    notes: 'Uso pós-alimentação. Contraindicado em casos de úlcera péptica ou disfunção hepática.',
    category: 'antiinflamatorio',
  },
  {
    id: 'med-4',
    name: 'Perioxidil Colutório (Clorexidina 0,12%)',
    posology: 'Bochechar 15ml puro durante 1 minuto, 2 vezes ao dia (manhã e noite, 30min após escovar os dentes) por 7 a 14 dias.',
    quantity: '1 frasco (250ml)',
    notes: 'Não engolir e não enxaguar a boca com água nem ingerir alimentos pelos próximos 30 minutos.',
    category: 'antisseptico',
  },
  {
    id: 'med-5',
    name: 'Ibuprofeno 600mg',
    posology: 'Tomar 1 comprimido via oral de 8 em 8 horas por 3 dias para controle de dor e edema.',
    quantity: '1 caixa (10 comprimidos)',
    notes: 'Ingerir acompanhado de alimentos ou leite para proteção gástrica.',
    category: 'antiinflamatorio',
  },
  {
    id: 'med-6',
    name: 'Paracetamol 750mg',
    posology: 'Tomar 1 comprimido via oral a cada 6 a 8 horas se dor moderada (máximo 3g ao dia).',
    quantity: '1 caixa (10 comprimidos)',
    notes: 'Excelente opção analgésica para pacientes alérgicos a AINEs ou Dipirona.',
    category: 'analgesico',
  },
  {
    id: 'med-7',
    name: 'Dexametasona 4mg',
    posology: 'Tomar 1 comprimido via oral 1 hora antes do procedimento cirúrgico (dose única pré-operatória).',
    quantity: '1 comprimido',
    notes: 'Controle profilático potente do edema e trismo pós-operatório.',
    category: 'corticoide',
  },
  {
    id: 'med-8',
    name: 'Amoxicilina + Clavulanato de Potássio 875/125mg',
    posology: 'Tomar 1 comprimido via oral de 12 em 12 horas por 7 dias contínuos.',
    quantity: '1 caixa (14 comprimidos)',
    notes: 'Indicado para infecções odontogênicas com resistência bacteriana.',
    category: 'antibiotico',
  },
];

export const DENTAL_CID_LIST = [
  { code: 'K02.9', description: 'Cárie dentária, não especificada' },
  { code: 'K04.0', description: 'Pulpite aguda / irreversível' },
  { code: 'K04.7', description: 'Abscesso periapical sem fístula' },
  { code: 'K05.3', description: 'Periodontite crônica' },
  { code: 'K07.6', description: 'Transtornos da articulação temporomandibular (ATM)' },
  { code: 'K08.1', description: 'Perda de dentes devida a acidente, extração ou doença periodontal' },
  { code: 'K01.1', description: 'Dentes inclusos / impactados (Exodontia de terceiros molares)' },
  { code: 'Z01.2', description: 'Exame odontológico de rotina e controle pós-operatório' },
  { code: 'Z76.0', description: 'Emissão de atestado médico-odontológico' },
];

export const INITIAL_CLINICAL_DOCUMENTS: ClinicalDocument[] = [
  {
    id: 'doc-1',
    type: 'receita',
    patientId: 'pat-2',
    patientName: 'Carlos Eduardo Mendes',
    patientCpf: '234.567.890-12',
    patientPhone: '(11) 97654-3210',
    date: getTodayString(),
    medicines: [
      {
        id: 'med-rx-1',
        name: 'Amoxicilina 500mg',
        quantity: '21 cápsulas',
        posology: 'Tomar 1 cápsula de 8 em 8 horas durante 7 dias consecutivos.',
        notes: 'Ingerir com água.',
      },
      {
        id: 'med-rx-2',
        name: 'Nimesulida 100mg',
        quantity: '1 caixa (12 comprimidos)',
        posology: 'Tomar 1 comprimido de 12 em 12 horas após as refeições por 3 dias.',
        notes: 'Uso pós-alimentação para alívio inflamatório.',
      },
      {
        id: 'med-rx-3',
        name: 'Perioxidil Colutório (Clorexidina 0,12%)',
        quantity: '1 frasco (250ml)',
        posology: 'Bochechar 15ml puro durante 1 minuto, 2x ao dia por 7 dias.',
        notes: 'Não enxaguar com água imediatamente após.',
      },
    ],
    generalInstructions:
      'Em caso de dor intensa persistente, sangramento ou febre alta, faça contato imediato com o consultório da Dra. Pâmela.',
    createdAt: `${getTodayString()}T10:30:00.000Z`,
  },
  {
    id: 'doc-2',
    type: 'atestado',
    certificateType: 'comparecimento',
    patientId: 'pat-1',
    patientName: 'Ana Clara Santos',
    patientCpf: '123.456.789-01',
    patientPhone: '(11) 98765-4321',
    date: getTodayString(),
    startTime: '09:00',
    endTime: '10:30',
    cid: 'Z01.2 - Exame odontológico de rotina e controle pós-operatório',
    reason: 'Consulta odontológica clínica de avaliação e profilaxia preventiva.',
    notes: 'Atestado emitido para justificativa de ausência no período matutino.',
    createdAt: `${getTodayString()}T10:35:00.000Z`,
  },
  {
    id: 'doc-3',
    type: 'atestado',
    certificateType: 'repouso',
    patientId: 'pat-2',
    patientName: 'Carlos Eduardo Mendes',
    patientCpf: '234.567.890-12',
    patientPhone: '(11) 97654-3210',
    date: getTodayString(),
    startDate: getTodayString(),
    restDays: 2,
    cid: 'K08.1 - Perda de dentes devida a acidente, extração ou doença periodontal',
    reason: 'Procedimento cirúrgico odontológico (Exodontia).',
    notes: 'Paciente necessita de repouso físico e afastamento laboral para cicatrização pós-operatória.',
    createdAt: `${getTodayString()}T11:00:00.000Z`,
  },
];

// Clean aesthetic dental mock images (SVG Data URLs)
export const MOCK_SMILE_BEFORE = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="100%" height="100%">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="%231e293b"/><stop offset="100%" stop-color="%230f172a"/></linearGradient>
    <linearGradient id="gum" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="%23fb7185"/><stop offset="100%" stop-color="%23e11d48"/></linearGradient>
    <linearGradient id="toothBefore" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="%23fef08a"/><stop offset="100%" stop-color="%23eab308"/></linearGradient>
  </defs>
  <rect width="400" height="300" fill="url(%23bg)"/>
  <rect x="20" y="20" width="360" height="260" rx="16" fill="%231e1b4b" stroke="%23334155" stroke-width="2"/>
  <path d="M 50 110 Q 200 80 350 110 Q 320 70 200 65 Q 80 70 50 110 Z" fill="url(%23gum)"/>
  <!-- Upper Teeth Initial/Before -->
  <rect x="90" y="105" width="45" height="75" rx="10" fill="url(%23toothBefore)" stroke="%23ca8a04" stroke-width="2"/>
  <rect x="140" y="102" width="55" height="85" rx="12" fill="url(%23toothBefore)" stroke="%23ca8a04" stroke-width="2"/>
  <rect x="200" y="102" width="55" height="85" rx="12" fill="url(%23toothBefore)" stroke="%23ca8a04" stroke-width="2"/>
  <rect x="260" y="105" width="45" height="75" rx="10" fill="url(%23toothBefore)" stroke="%23ca8a04" stroke-width="2"/>
  <!-- Tag -->
  <rect x="35" y="35" width="105" height="28" rx="8" fill="%23e11d48"/>
  <text x="87" y="53" font-family="sans-serif" font-size="12" font-weight="bold" fill="white" text-anchor="middle">INICIAL • ANTES</text>
  <text x="200" y="240" font-family="sans-serif" font-size="13" font-weight="bold" fill="%23cbd5e1" text-anchor="middle">Escala Vita A3.5 • Pigmentação Severa</text>
  <text x="200" y="260" font-family="sans-serif" font-size="11" fill="%2394a3b8" text-anchor="middle">Dra. Pâmela • Registro Fotográfico OdontoFlow</text>
</svg>`;

export const MOCK_SMILE_AFTER = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="100%" height="100%">
  <defs>
    <linearGradient id="bgAfter" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="%23042f2e"/><stop offset="100%" stop-color="%230f172a"/></linearGradient>
    <linearGradient id="gumAfter" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="%23fda4af"/><stop offset="100%" stop-color="%23f43f5e"/></linearGradient>
    <linearGradient id="toothAfter" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="%23ffffff"/><stop offset="70%" stop-color="%23f0fdfa"/><stop offset="100%" stop-color="%23ccfbf1"/></linearGradient>
  </defs>
  <rect width="400" height="300" fill="url(%23bgAfter)"/>
  <rect x="20" y="20" width="360" height="260" rx="16" fill="%230f2928" stroke="%230d9488" stroke-width="2"/>
  <path d="M 50 110 Q 200 80 350 110 Q 320 70 200 65 Q 80 70 50 110 Z" fill="url(%23gumAfter)"/>
  <!-- Upper Teeth Bright White -->
  <rect x="90" y="105" width="45" height="75" rx="10" fill="url(%23toothAfter)" stroke="%2399f6e4" stroke-width="2"/>
  <rect x="140" y="102" width="55" height="85" rx="12" fill="url(%23toothAfter)" stroke="%2399f6e4" stroke-width="2"/>
  <rect x="200" y="102" width="55" height="85" rx="12" fill="url(%23toothAfter)" stroke="%2399f6e4" stroke-width="2"/>
  <rect x="260" y="105" width="45" height="75" rx="10" fill="url(%23toothAfter)" stroke="%2399f6e4" stroke-width="2"/>
  <!-- Sparkles -->
  <circle cx="160" cy="120" r="3" fill="white"/>
  <circle cx="230" cy="115" r="4" fill="white"/>
  <!-- Tag -->
  <rect x="35" y="35" width="115" height="28" rx="8" fill="%230d9488"/>
  <text x="92" y="53" font-family="sans-serif" font-size="12" font-weight="bold" fill="white" text-anchor="middle">RESULTADO • DEPOIS</text>
  <text x="200" y="240" font-family="sans-serif" font-size="13" font-weight="bold" fill="%235eead4" text-anchor="middle">Escala Vita BL1 • Clareamento Concluído</text>
  <text x="200" y="260" font-family="sans-serif" font-size="11" fill="%2399f6e4" text-anchor="middle">Dra. Pâmela • Registro Fotográfico OdontoFlow</text>
</svg>`;

export const MOCK_XRAY = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" width="100%" height="100%">
  <rect width="400" height="300" fill="%2309090b"/>
  <rect x="25" y="20" width="350" height="260" rx="12" fill="%2318181b" stroke="%233f3f46" stroke-width="2"/>
  <!-- Bone and tooth structure in radiograph style -->
  <path d="M 60 210 Q 200 190 340 210 L 340 260 L 60 260 Z" fill="%2352525b" opacity="0.8"/>
  <!-- Root Canals & Pulp -->
  <path d="M 160 100 Q 150 180 170 230 Q 185 240 190 220 Q 200 180 195 100 Z" fill="%23d4d4d8" stroke="%2371717a" stroke-width="2"/>
  <path d="M 210 100 Q 205 180 225 230 Q 240 240 245 220 Q 255 180 250 100 Z" fill="%23d4d4d8" stroke="%2371717a" stroke-width="2"/>
  <!-- Root Canal filling white line -->
  <path d="M 178 130 L 178 220" stroke="%23ffffff" stroke-width="3" stroke-linecap="round"/>
  <path d="M 228 130 L 232 220" stroke="%23ffffff" stroke-width="3" stroke-linecap="round"/>
  <!-- Tag -->
  <rect x="40" y="35" width="130" height="28" rx="8" fill="%23475569"/>
  <text x="105" y="53" font-family="sans-serif" font-size="11" font-weight="bold" fill="white" text-anchor="middle">RADIOGRAFIA PERIAPICAL</text>
  <text x="200" y="250" font-family="monospace" font-size="12" fill="%23e4e4e7" text-anchor="middle">Rx Dente 16 • Conduto Obturado</text>
</svg>`;

export const MOCK_SIGNATURE = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 100" width="300" height="100%">
  <path d="M 30 65 Q 60 20 80 50 Q 110 80 130 35 T 170 60 Q 200 20 230 65 Q 260 70 280 50" fill="none" stroke="%230f766e" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M 50 75 Q 150 72 260 76" fill="none" stroke="%230d9488" stroke-width="1.5" stroke-linecap="round"/>
</svg>`;

export const INITIAL_CLINICAL_PHOTOS: Record<string, ClinicalPhoto[]> = {
  'pat-1': [
    {
      id: 'photo-1',
      patientId: 'pat-1',
      title: 'Sorriso Inicial - Antes do Clareamento',
      category: 'antes',
      imageData: MOCK_SMILE_BEFORE,
      date: '2025-01-15',
      toothNumber: 11,
      notes: 'Matriz A3.5 de escala Vita. Pigmentação por café e chá.',
      createdAt: '2025-01-15T10:00:00.000Z',
    },
    {
      id: 'photo-2',
      patientId: 'pat-1',
      title: 'Resultado Final - Pós Clareamento Consultório',
      category: 'depois',
      imageData: MOCK_SMILE_AFTER,
      date: '2025-02-10',
      toothNumber: 11,
      notes: 'Resultado alcançado escala Vita BL1. Paciente extremamente satisfeita com a harmonia.',
      createdAt: '2025-02-10T16:00:00.000Z',
    },
    {
      id: 'photo-3',
      patientId: 'pat-1',
      title: 'Radiografia Periapical de Controle',
      category: 'radiografia',
      imageData: MOCK_XRAY,
      date: '2025-01-20',
      toothNumber: 16,
      notes: 'Lâmina dura íntegra e obturação satisfatória.',
      createdAt: '2025-01-20T11:00:00.000Z',
    },
  ],
};

export const INITIAL_CONSENT_FORMS: Record<string, ConsentForm[]> = {
  'pat-1': [
    {
      id: 'tcle-1',
      patientId: 'pat-1',
      patientName: 'Ana Clara Santos',
      patientCpf: '123.456.789-01',
      category: 'clareamento',
      title: 'Termo de Consentimento para Clareamento Dental',
      content:
        'Declaro que fui devidamente esclarecido(a) pela Dra. Pâmela sobre os benefícios, limitações e eventuais efeitos colaterais do clareamento dental, incluindo sensibilidade dentinária transitória e cuidados com ingestão de corantes (café, vinho, refrigerantes) durante e após o tratamento. Autorizo a execução do plano terapêutico proposto.',
      signatureDataUrl: MOCK_SIGNATURE,
      signedDate: '2025-01-15 10:15',
      signedByName: 'Ana Clara Santos',
      professionalName: 'Dra. Pâmela',
      professionalCro: 'CRO/SP 123.456',
      createdAt: '2025-01-15T10:15:00.000Z',
    },
  ],
};

