import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Patient,
  Appointment,
  AppointmentStatus,
  PatientDentalChart,
  ToothRecord,
  Budget,
  BudgetStatus,
  BudgetItem,
  ClinicalEvolution,
  AppBackupData,
  ClinicalDocument,
  ClinicalDocumentInput,
  ClinicalPhoto,
  ConsentForm,
} from '../types';
import {
  INITIAL_PATIENTS,
  getInitialAppointments,
  INITIAL_DENTAL_CHARTS,
  INITIAL_BUDGETS,
  INITIAL_CLINICAL_EVOLUTIONS,
  INITIAL_CLINICAL_DOCUMENTS,
  INITIAL_CLINICAL_PHOTOS,
  INITIAL_CONSENT_FORMS,
  getTodayString,
} from '../data/mockData';
import { db, auth } from '../lib/firebase';
import { doc, setDoc, deleteDoc, collection, onSnapshot } from 'firebase/firestore';

interface ToastInfo {
  id: string;
  text: string;
  type: 'success' | 'info' | 'error';
}

interface AppContextType {
  patients: Patient[];
  appointments: Appointment[];
  dentalCharts: Record<string, PatientDentalChart>;
  budgets: Budget[];
  clinicalEvolutions: Record<string, ClinicalEvolution[]>;
  activeTab: 'dashboard' | 'patients' | 'schedule' | 'odontogram' | 'finance';
  setActiveTab: (tab: 'dashboard' | 'patients' | 'schedule' | 'odontogram' | 'finance') => void;
  selectedPatientIdForOdontogram: string;
  setSelectedPatientIdForOdontogram: (id: string) => void;
  toast: ToastInfo | null;
  showToast: (text: string, type?: 'success' | 'info' | 'error') => void;

  // Patient methods
  addPatient: (data: Omit<Patient, 'id' | 'createdAt'>) => Patient;
  updatePatient: (id: string, data: Partial<Patient>) => void;
  deletePatient: (id: string) => void;
  getPatientById: (id: string) => Patient | undefined;

  // Appointment methods
  addAppointment: (data: Omit<Appointment, 'id'>) => Appointment;
  updateAppointment: (id: string, data: Partial<Appointment>) => void;
  updateAppointmentStatus: (id: string, status: AppointmentStatus) => void;
  deleteAppointment: (id: string) => void;

  // Dental chart methods
  getPatientChart: (patientId: string) => PatientDentalChart;
  updateToothRecord: (
    patientId: string,
    toothNumber: number,
    record: Partial<ToothRecord>,
    addToPendingBudget?: boolean
  ) => void;

  // Budget methods
  addBudget: (data: Omit<Budget, 'id'>) => Budget;
  updateBudget: (id: string, data: Partial<Budget>) => void;
  updateBudgetStatus: (id: string, status: BudgetStatus) => void;
  deleteBudget: (id: string) => void;
  addToothToPendingBudget: (
    patientId: string,
    item: { description: string; toothNumber: number; value: number }
  ) => void;

  // Clinical Evolutions methods
  addClinicalEvolution: (
    patientId: string,
    data: Omit<ClinicalEvolution, 'id' | 'patientId'>
  ) => ClinicalEvolution;
  deleteClinicalEvolution: (patientId: string, evolutionId: string) => void;
  getPatientEvolutions: (patientId: string) => ClinicalEvolution[];

  // Clinical Documents (Receituários e Atestados) methods
  documents: ClinicalDocument[];
  addDocument: (data: ClinicalDocumentInput) => ClinicalDocument;
  deleteDocument: (id: string) => void;
  getPatientDocuments: (patientId: string) => ClinicalDocument[];
  isDocumentModalOpen: boolean;
  setIsDocumentModalOpen: (open: boolean) => void;
  documentModalConfig: {
    patientId?: string;
    initialType?: 'receita' | 'atestado';
    documentToView?: ClinicalDocument;
  };
  openDocumentModal: (config?: {
    patientId?: string;
    initialType?: 'receita' | 'atestado';
    documentToView?: ClinicalDocument;
  }) => void;
  closeDocumentModal: () => void;

  // Clinical Photos (Antes & Depois & Raio-X)
  photos: Record<string, ClinicalPhoto[]>;
  addPhoto: (patientId: string, photo: Omit<ClinicalPhoto, 'id' | 'createdAt'>) => ClinicalPhoto;
  deletePhoto: (patientId: string, photoId: string) => void;
  getPatientPhotos: (patientId: string) => ClinicalPhoto[];

  // Termos de Consentimento (TCLE) com Assinatura Digital
  consentForms: Record<string, ConsentForm[]>;
  addConsentForm: (patientId: string, form: Omit<ConsentForm, 'id' | 'createdAt'>) => ConsentForm;
  deleteConsentForm: (patientId: string, formId: string) => void;
  getPatientConsentForms: (patientId: string) => ConsentForm[];

  // Quick modals triggers
  isNewPatientOpen: boolean;
  setIsNewPatientOpen: (open: boolean) => void;
  patientToEdit: Patient | null;
  setPatientToEdit: (patient: Patient | null) => void;
  openPatientModal: (patient?: Patient) => void;
  closePatientModal: () => void;

  isNewAppointmentOpen: boolean;
  setIsNewAppointmentOpen: (open: boolean) => void;
  appointmentToEdit: Appointment | null;
  setAppointmentToEdit: (apt: Appointment | null) => void;
  appointmentDefaultDate: string | undefined;
  setAppointmentDefaultDate: (date: string | undefined) => void;
  openAppointmentModal: (apt?: Appointment, defaultDate?: string, defaultPatientId?: string) => void;
  closeAppointmentModal: () => void;

  isNewBudgetOpen: boolean;
  setIsNewBudgetOpen: (open: boolean) => void;
  isBackupModalOpen: boolean;
  setIsBackupModalOpen: (open: boolean) => void;
  preselectedPatientForAppointment: string | null;
  setPreselectedPatientForAppointment: (id: string | null) => void;

  // Quick jump helper
  openOdontogramForPatient: (patientId: string) => void;

  // Backup & Restore
  exportBackupData: () => void;
  importBackupData: (jsonString: string) => boolean;

  // Reset data
  resetToMockData: () => void;

  // Gemini AI Chatbot
  isGeminiChatOpen: boolean;
  setIsGeminiChatOpen: (open: boolean) => void;
  openGeminiChat: () => void;
}

const STORAGE_KEYS = {
  PATIENTS: 'odontoflow_dra_pamela_patients',
  APPOINTMENTS: 'odontoflow_dra_pamela_appointments',
  CHARTS: 'odontoflow_dra_pamela_charts',
  BUDGETS: 'odontoflow_dra_pamela_budgets',
  EVOLUTIONS: 'odontoflow_dra_pamela_evolutions',
  DOCUMENTS: 'odontoflow_dra_pamela_documents',
  PHOTOS: 'odontoflow_dra_pamela_photos',
  CONSENTS: 'odontoflow_dra_pamela_consents',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [patients, setPatients] = useState<Patient[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PATIENTS);
      return saved ? JSON.parse(saved) : INITIAL_PATIENTS;
    } catch {
      return INITIAL_PATIENTS;
    }
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.APPOINTMENTS);
      return saved ? JSON.parse(saved) : getInitialAppointments();
    } catch {
      return getInitialAppointments();
    }
  });

  const [dentalCharts, setDentalCharts] = useState<Record<string, PatientDentalChart>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CHARTS);
      return saved ? JSON.parse(saved) : INITIAL_DENTAL_CHARTS;
    } catch {
      return INITIAL_DENTAL_CHARTS;
    }
  });

  const [budgets, setBudgets] = useState<Budget[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.BUDGETS);
      return saved ? JSON.parse(saved) : INITIAL_BUDGETS;
    } catch {
      return INITIAL_BUDGETS;
    }
  });

  const [clinicalEvolutions, setClinicalEvolutions] = useState<Record<string, ClinicalEvolution[]>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.EVOLUTIONS);
      return saved ? JSON.parse(saved) : INITIAL_CLINICAL_EVOLUTIONS;
    } catch {
      return INITIAL_CLINICAL_EVOLUTIONS;
    }
  });

  const [documents, setDocuments] = useState<ClinicalDocument[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
      return saved ? JSON.parse(saved) : INITIAL_CLINICAL_DOCUMENTS;
    } catch {
      return INITIAL_CLINICAL_DOCUMENTS;
    }
  });

  const [photos, setPhotos] = useState<Record<string, ClinicalPhoto[]>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PHOTOS);
      return saved ? JSON.parse(saved) : INITIAL_CLINICAL_PHOTOS;
    } catch {
      return INITIAL_CLINICAL_PHOTOS;
    }
  });

  const [consentForms, setConsentForms] = useState<Record<string, ConsentForm[]>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONSENTS);
      return saved ? JSON.parse(saved) : INITIAL_CONSENT_FORMS;
    } catch {
      return INITIAL_CONSENT_FORMS;
    }
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'patients' | 'schedule' | 'odontogram' | 'finance'>('dashboard');
  const [selectedPatientIdForOdontogram, setSelectedPatientIdForOdontogram] = useState<string>(
    INITIAL_PATIENTS[0]?.id || ''
  );

  const [isNewPatientOpen, setIsNewPatientOpen] = useState(false);
  const [patientToEdit, setPatientToEdit] = useState<Patient | null>(null);
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [appointmentToEdit, setAppointmentToEdit] = useState<Appointment | null>(null);
  const [appointmentDefaultDate, setAppointmentDefaultDate] = useState<string | undefined>(undefined);
  const [isNewBudgetOpen, setIsNewBudgetOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [isDocumentModalOpen, setIsDocumentModalOpen] = useState(false);
  const [documentModalConfig, setDocumentModalConfig] = useState<{
    patientId?: string;
    initialType?: 'receita' | 'atestado';
    documentToView?: ClinicalDocument;
  }>({});
  const [preselectedPatientForAppointment, setPreselectedPatientForAppointment] = useState<string | null>(null);
  const [isGeminiChatOpen, setIsGeminiChatOpen] = useState<boolean>(false);
  const openGeminiChat = () => setIsGeminiChatOpen(true);

  // Firestore Real-time Cloud Synchronization when user is authenticated
  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged((user) => {
      if (user) {
        // Sync Patients from Firestore
        const unsubPatients = onSnapshot(
          collection(db, 'patients'),
          (snapshot) => {
            if (!snapshot.empty) {
              const remotePatients: Patient[] = snapshot.docs.map((docSnap) => docSnap.data() as Patient);
              setPatients(remotePatients);
            }
          },
          (err) => console.warn('Firestore patients sync notice:', err)
        );

        // Sync Appointments from Firestore
        const unsubAppointments = onSnapshot(
          collection(db, 'appointments'),
          (snapshot) => {
            if (!snapshot.empty) {
              const remoteAppointments: Appointment[] = snapshot.docs.map((docSnap) => docSnap.data() as Appointment);
              setAppointments(remoteAppointments);
            }
          },
          (err) => console.warn('Firestore appointments sync notice:', err)
        );

        // Sync Budgets from Firestore
        const unsubBudgets = onSnapshot(
          collection(db, 'budgets'),
          (snapshot) => {
            if (!snapshot.empty) {
              const remoteBudgets: Budget[] = snapshot.docs.map((docSnap) => docSnap.data() as Budget);
              setBudgets(remoteBudgets);
            }
          },
          (err) => console.warn('Firestore budgets sync notice:', err)
        );

        return () => {
          unsubPatients();
          unsubAppointments();
          unsubBudgets();
        };
      }
    });

    return () => unsubscribeAuth();
  }, []);

  const [toast, setToast] = useState<ToastInfo | null>(null);

  const openPatientModal = (patient?: Patient) => {
    setPatientToEdit(patient || null);
    setIsNewPatientOpen(true);
  };

  const closePatientModal = () => {
    setIsNewPatientOpen(false);
    setPatientToEdit(null);
  };

  const openAppointmentModal = (apt?: Appointment, defaultDate?: string, defaultPatientId?: string) => {
    setAppointmentToEdit(apt || null);
    if (defaultDate) {
      setAppointmentDefaultDate(defaultDate);
    }
    if (defaultPatientId !== undefined) {
      setPreselectedPatientForAppointment(defaultPatientId);
    }
    setIsNewAppointmentOpen(true);
  };

  const closeAppointmentModal = () => {
    setIsNewAppointmentOpen(false);
    setAppointmentToEdit(null);
  };

  // Sync state to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PATIENTS, JSON.stringify(patients));
    } catch (e) {
      console.warn('LocalStorage error saving patients', e);
    }
  }, [patients]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.APPOINTMENTS, JSON.stringify(appointments));
    } catch (e) {
      console.warn('LocalStorage error saving appointments', e);
    }
  }, [appointments]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CHARTS, JSON.stringify(dentalCharts));
    } catch (e) {
      console.warn('LocalStorage error saving dental charts', e);
    }
  }, [dentalCharts]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.BUDGETS, JSON.stringify(budgets));
    } catch (e) {
      console.warn('LocalStorage error saving budgets', e);
    }
  }, [budgets]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.EVOLUTIONS, JSON.stringify(clinicalEvolutions));
    } catch (e) {
      console.warn('LocalStorage error saving evolutions', e);
    }
  }, [clinicalEvolutions]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(documents));
    } catch (e) {
      console.warn('LocalStorage error saving documents', e);
    }
  }, [documents]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.PHOTOS, JSON.stringify(photos));
    } catch (e) {
      console.warn('LocalStorage error saving photos', e);
    }
  }, [photos]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.CONSENTS, JSON.stringify(consentForms));
    } catch (e) {
      console.warn('LocalStorage error saving consents', e);
    }
  }, [consentForms]);

  const showToast = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Date.now().toString();
    setToast({ id, text, type });
    setTimeout(() => {
      setToast((curr) => (curr?.id === id ? null : curr));
    }, 3500);
  };

  const addPatient = (data: Omit<Patient, 'id' | 'createdAt'>): Patient => {
    const newPatient: Patient = {
      ...data,
      id: `pat-${Date.now()}`,
      createdAt: getTodayString(),
    };
    setPatients((prev) => [newPatient, ...prev]);
    showToast(`Paciente ${newPatient.name} cadastrado com sucesso!`);
    return newPatient;
  };

  const updatePatient = (id: string, data: Partial<Patient>) => {
    setPatients((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          return { ...p, ...data };
        }
        return p;
      })
    );
    if (data.name || data.phone) {
      setAppointments((prev) =>
        prev.map((apt) => {
          if (apt.patientId === id) {
            return {
              ...apt,
              patientName: data.name ?? apt.patientName,
              patientPhone: data.phone ?? apt.patientPhone,
            };
          }
          return apt;
        })
      );
      setBudgets((prev) =>
        prev.map((b) => {
          if (b.patientId === id) {
            return {
              ...b,
              patientName: data.name ?? b.patientName,
              patientPhone: data.phone ?? b.patientPhone,
            };
          }
          return b;
        })
      );
    }
    showToast('Cadastro atualizado com sucesso!');
  };

  const deletePatient = (id: string) => {
    const patientToDelete = patients.find((p) => p.id === id);
    setPatients((prev) => prev.filter((p) => p.id !== id));
    setAppointments((prev) => prev.filter((apt) => apt.patientId !== id));
    setBudgets((prev) => prev.filter((b) => b.patientId !== id));
    showToast(`Paciente ${patientToDelete?.name || ''} removido.`, 'info');
  };

  const getPatientById = (id: string) => {
    return patients.find((p) => p.id === id);
  };

  const addAppointment = (data: Omit<Appointment, 'id'>): Appointment => {
    const newApt: Appointment = {
      ...data,
      id: `apt-${Date.now()}`,
    };
    setAppointments((prev) => [newApt, ...prev]);
    showToast(`Consulta agendada para ${newApt.patientName}!`);
    return newApt;
  };

  const updateAppointment = (id: string, data: Partial<Appointment>) => {
    setAppointments((prev) =>
      prev.map((apt) => (apt.id === id ? { ...apt, ...data } : apt))
    );
    showToast('Consulta atualizada com sucesso!');
  };

  const updateAppointmentStatus = (id: string, status: AppointmentStatus) => {
    setAppointments((prev) =>
      prev.map((apt) => (apt.id === id ? { ...apt, status } : apt))
    );
    const labels: Record<AppointmentStatus, string> = {
      agendado: 'marcada como Agendada',
      confirmado: 'marcada como Confirmada',
      concluido: 'concluída com sucesso',
      cancelado: 'cancelada',
    };
    showToast(`Consulta ${labels[status]}!`);
  };

  const deleteAppointment = (id: string) => {
    setAppointments((prev) => prev.filter((apt) => apt.id !== id));
    showToast('Agendamento excluído.', 'info');
  };

  const getPatientChart = (patientId: string): PatientDentalChart => {
    return dentalCharts[patientId] || {};
  };

  const addToothToPendingBudget = (
    patientId: string,
    item: { description: string; toothNumber: number; value: number }
  ) => {
    const patient = patients.find((p) => p.id === patientId);
    if (!patient) return;

    setBudgets((prev) => {
      const existingPending = prev.find(
        (b) => b.patientId === patientId && b.status === 'pendente'
      );

      const newItem: BudgetItem = {
        id: `bi-${Date.now()}`,
        description: item.description,
        toothNumber: item.toothNumber,
        value: item.value,
      };

      if (existingPending) {
        // Check if tooth is already in this budget, replace or append
        const filteredItems = existingPending.items.filter(
          (i) => i.toothNumber !== item.toothNumber || i.description !== item.description
        );
        const updatedItems = [...filteredItems, newItem];
        const newTotal = updatedItems.reduce((acc, it) => acc + it.value, 0);

        return prev.map((b) =>
          b.id === existingPending.id
            ? { ...b, items: updatedItems, totalValue: newTotal }
            : b
        );
      } else {
        const newBudget: Budget = {
          id: `bdg-${Date.now()}`,
          patientId,
          patientName: patient.name,
          patientPhone: patient.phone,
          date: getTodayString(),
          items: [newItem],
          totalValue: item.value,
          status: 'pendente',
          paymentMethod: 'pix',
          notes: `Gerado a partir do Odontograma (Dente ${item.toothNumber})`,
        };
        return [newBudget, ...prev];
      }
    });

    showToast(`Dente ${item.toothNumber} adicionado ao orçamento pendente de ${patient.name}!`);
  };

  const updateToothRecord = (
    patientId: string,
    toothNumber: number,
    record: Partial<ToothRecord>,
    addToPendingBudgetFlag?: boolean
  ) => {
    setDentalCharts((prev) => {
      const patientChart = prev[patientId] || {};
      const currentTooth = patientChart[toothNumber] || {
        toothNumber,
        status: 'higido',
      };

      const updatedTooth: ToothRecord = {
        ...currentTooth,
        ...record,
        updatedAt: getTodayString(),
      };

      return {
        ...prev,
        [patientId]: {
          ...patientChart,
          [toothNumber]: updatedTooth,
        },
      };
    });

    // If option was checked to add to pending budget
    if (addToPendingBudgetFlag && record.status === 'tratamento_necessario') {
      const val = Number(record.estimatedPrice) || 280;
      const desc = record.conditionTitle?.trim() || `Tratamento Dente ${toothNumber}`;
      addToothToPendingBudget(patientId, {
        description: desc,
        toothNumber,
        value: val,
      });
    } else {
      showToast(`Dente ${toothNumber} atualizado no Odontograma!`);
    }
  };

  const addBudget = (data: Omit<Budget, 'id'>): Budget => {
    const newBudget: Budget = {
      ...data,
      id: `bdg-${Date.now()}`,
    };
    setBudgets((prev) => [newBudget, ...prev]);
    showToast(`Orçamento para ${newBudget.patientName} gerado com sucesso!`);
    return newBudget;
  };

  const updateBudget = (id: string, data: Partial<Budget>) => {
    setBudgets((prev) =>
      prev.map((b) => (b.id === id ? { ...b, ...data } : b))
    );
    showToast('Orçamento atualizado!');
  };

  const updateBudgetStatus = (id: string, status: BudgetStatus) => {
    const today = getTodayString();
    setBudgets((prev) =>
      prev.map((b) => {
        if (b.id === id) {
          return {
            ...b,
            status,
            approvedDate: status === 'aprovado' || status === 'pago' ? today : b.approvedDate,
          };
        }
        return b;
      })
    );
    const labels: Record<BudgetStatus, string> = {
      aprovado: 'Aprovado com sucesso! 🎉',
      pago: 'marcado como Pago! 💰',
      pendente: 'marcado como Pendente.',
      recusado: 'marcado como Recusado.',
    };
    showToast(`Orçamento ${labels[status]}`);
  };

  const deleteBudget = (id: string) => {
    setBudgets((prev) => prev.filter((b) => b.id !== id));
    showToast('Orçamento excluído.', 'info');
  };

  const addClinicalEvolution = (
    patientId: string,
    data: Omit<ClinicalEvolution, 'id' | 'patientId'>
  ): ClinicalEvolution => {
    const newEvo: ClinicalEvolution = {
      ...data,
      id: `evo-${Date.now()}`,
      patientId,
    };

    setClinicalEvolutions((prev) => {
      const patientEvos = prev[patientId] || [];
      return {
        ...prev,
        [patientId]: [newEvo, ...patientEvos],
      };
    });

    showToast('Evolução clínica registrada no prontuário!');
    return newEvo;
  };

  const deleteClinicalEvolution = (patientId: string, evolutionId: string) => {
    setClinicalEvolutions((prev) => {
      const patientEvos = prev[patientId] || [];
      return {
        ...prev,
        [patientId]: patientEvos.filter((e) => e.id !== evolutionId),
      };
    });
    showToast('Evolução clínica removida.', 'info');
  };

  const getPatientEvolutions = (patientId: string): ClinicalEvolution[] => {
    return clinicalEvolutions[patientId] || [];
  };

  // CLINICAL DOCUMENTS (Receituários e Atestados)
  const addDocument = (data: ClinicalDocumentInput): ClinicalDocument => {
    const newDoc = {
      ...data,
      id: `doc-${Date.now()}`,
      createdAt: new Date().toISOString(),
    } as ClinicalDocument;

    setDocuments((prev) => [newDoc, ...prev]);
    const docLabel = newDoc.type === 'receita' ? 'Receituário' : 'Atestado';
    showToast(`${docLabel} emitido com sucesso para ${newDoc.patientName}!`);
    return newDoc;
  };

  const deleteDocument = (id: string) => {
    setDocuments((prev) => prev.filter((doc) => doc.id !== id));
    showToast('Documento clínico removido do histórico.', 'info');
  };

  const getPatientDocuments = (patientId: string): ClinicalDocument[] => {
    return documents.filter((doc) => doc.patientId === patientId);
  };

  const openDocumentModal = (config?: {
    patientId?: string;
    initialType?: 'receita' | 'atestado';
    documentToView?: ClinicalDocument;
  }) => {
    setDocumentModalConfig(config || {});
    setIsDocumentModalOpen(true);
  };

  const closeDocumentModal = () => {
    setIsDocumentModalOpen(false);
    setDocumentModalConfig({});
  };

  const openOdontogramForPatient = (patientId: string) => {
    setSelectedPatientIdForOdontogram(patientId);
    setActiveTab('odontogram');
  };

  // CLINICAL PHOTOS (Antes & Depois & Raio-X)
  const addPhoto = (
    patientId: string,
    photoData: Omit<ClinicalPhoto, 'id' | 'createdAt'>
  ): ClinicalPhoto => {
    const newPhoto: ClinicalPhoto = {
      ...photoData,
      id: `photo-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };

    setPhotos((prev) => ({
      ...prev,
      [patientId]: [newPhoto, ...(prev[patientId] || [])],
    }));
    showToast(`Foto clínica adicionada com sucesso!`);
    return newPhoto;
  };

  const deletePhoto = (patientId: string, photoId: string) => {
    setPhotos((prev) => ({
      ...prev,
      [patientId]: (prev[patientId] || []).filter((p) => p.id !== photoId),
    }));
    showToast('Foto removida da galeria.', 'info');
  };

  const getPatientPhotos = (patientId: string): ClinicalPhoto[] => {
    return photos[patientId] || [];
  };

  // TERMOS DE CONSENTIMENTO (TCLE)
  const addConsentForm = (
    patientId: string,
    formData: Omit<ConsentForm, 'id' | 'createdAt'>
  ): ConsentForm => {
    const newForm: ConsentForm = {
      ...formData,
      id: `tcle-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };

    setConsentForms((prev) => ({
      ...prev,
      [patientId]: [newForm, ...(prev[patientId] || [])],
    }));
    showToast(`Termo assinado e salvo com sucesso!`);
    return newForm;
  };

  const deleteConsentForm = (patientId: string, formId: string) => {
    setConsentForms((prev) => ({
      ...prev,
      [patientId]: (prev[patientId] || []).filter((f) => f.id !== formId),
    }));
    showToast('Termo de consentimento removido.', 'info');
  };

  const getPatientConsentForms = (patientId: string): ConsentForm[] => {
    return consentForms[patientId] || [];
  };

  // EXPORT BACKUP TO .JSON
  const exportBackupData = () => {
    try {
      const backupData: AppBackupData = {
        version: '1.4.0',
        exportDate: new Date().toISOString(),
        exportedBy: 'Dra. Pâmela - OdontoFlow',
        patients,
        appointments,
        dentalCharts,
        budgets,
        evolutions: clinicalEvolutions,
        documents,
        photos,
        consentForms,
      };

      const jsonStr = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const dateStr = getTodayString();
      link.href = url;
      link.download = `odontoflow-backup-dra-pamela-${dateStr}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      showToast('Backup exportado com sucesso! Arquivo .json baixado.');
    } catch (err) {
      console.error(err);
      showToast('Erro ao exportar backup.', 'error');
    }
  };

  // IMPORT & RESTORE BACKUP FROM .JSON
  const importBackupData = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString) as Partial<AppBackupData>;

      if (!data.patients || !Array.isArray(data.patients)) {
        throw new Error('Arquivo de backup inválido: lista de pacientes não encontrada.');
      }

      setPatients(data.patients);
      if (data.appointments && Array.isArray(data.appointments)) {
        setAppointments(data.appointments);
      }
      if (data.dentalCharts && typeof data.dentalCharts === 'object') {
        setDentalCharts(data.dentalCharts);
      }
      if (data.budgets && Array.isArray(data.budgets)) {
        setBudgets(data.budgets);
      }
      if (data.evolutions && typeof data.evolutions === 'object') {
        setClinicalEvolutions(data.evolutions);
      }
      if (data.documents && Array.isArray(data.documents)) {
        setDocuments(data.documents);
      }
      if (data.photos && typeof data.photos === 'object') {
        setPhotos(data.photos);
      }
      if (data.consentForms && typeof data.consentForms === 'object') {
        setConsentForms(data.consentForms);
      }

      showToast('Backup restaurado com sucesso! Todos os dados foram atualizados.');
      return true;
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Erro ao importar arquivo de backup.', 'error');
      return false;
    }
  };

  const resetToMockData = () => {
    localStorage.removeItem(STORAGE_KEYS.PATIENTS);
    localStorage.removeItem(STORAGE_KEYS.APPOINTMENTS);
    localStorage.removeItem(STORAGE_KEYS.CHARTS);
    localStorage.removeItem(STORAGE_KEYS.BUDGETS);
    localStorage.removeItem(STORAGE_KEYS.EVOLUTIONS);
    localStorage.removeItem(STORAGE_KEYS.DOCUMENTS);
    localStorage.removeItem(STORAGE_KEYS.PHOTOS);
    localStorage.removeItem(STORAGE_KEYS.CONSENTS);
    setPatients(INITIAL_PATIENTS);
    setAppointments(getInitialAppointments());
    setDentalCharts(INITIAL_DENTAL_CHARTS);
    setBudgets(INITIAL_BUDGETS);
    setClinicalEvolutions(INITIAL_CLINICAL_EVOLUTIONS);
    setDocuments(INITIAL_CLINICAL_DOCUMENTS);
    setPhotos(INITIAL_CLINICAL_PHOTOS);
    setConsentForms(INITIAL_CONSENT_FORMS);
    setSelectedPatientIdForOdontogram(INITIAL_PATIENTS[0]?.id || '');
    showToast('Dados restaurados para o padrão de demonstração!', 'info');
  };

  return (
    <AppContext.Provider
      value={{
        patients,
        appointments,
        dentalCharts,
        budgets,
        clinicalEvolutions,
        documents,
        activeTab,
        setActiveTab,
        selectedPatientIdForOdontogram,
        setSelectedPatientIdForOdontogram,
        toast,
        showToast,
        addPatient,
        updatePatient,
        deletePatient,
        getPatientById,
        addAppointment,
        updateAppointment,
        updateAppointmentStatus,
        deleteAppointment,
        getPatientChart,
        updateToothRecord,
        addBudget,
        updateBudget,
        updateBudgetStatus,
        deleteBudget,
        addToothToPendingBudget,
        addClinicalEvolution,
        deleteClinicalEvolution,
        getPatientEvolutions,
        addDocument,
        deleteDocument,
        getPatientDocuments,
        isDocumentModalOpen,
        setIsDocumentModalOpen,
        documentModalConfig,
        openDocumentModal,
        closeDocumentModal,
        photos,
        addPhoto,
        deletePhoto,
        getPatientPhotos,
        consentForms,
        addConsentForm,
        deleteConsentForm,
        getPatientConsentForms,
        isNewPatientOpen,
        setIsNewPatientOpen,
        patientToEdit,
        setPatientToEdit,
        openPatientModal,
        closePatientModal,
        isNewAppointmentOpen,
        setIsNewAppointmentOpen,
        appointmentToEdit,
        setAppointmentToEdit,
        appointmentDefaultDate,
        setAppointmentDefaultDate,
        openAppointmentModal,
        closeAppointmentModal,
        isNewBudgetOpen,
        setIsNewBudgetOpen,
        isBackupModalOpen,
        setIsBackupModalOpen,
        preselectedPatientForAppointment,
        setPreselectedPatientForAppointment,
        openOdontogramForPatient,
        exportBackupData,
        importBackupData,
        resetToMockData,
        isGeminiChatOpen,
        setIsGeminiChatOpen,
        openGeminiChat,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
