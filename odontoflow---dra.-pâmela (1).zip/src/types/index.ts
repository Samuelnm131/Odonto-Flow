export type ToothStatus =
  | 'higido'
  | 'tratamento_necessario'
  | 'tratamento_concluido'
  | 'em_andamento'
  | 'ausente_extraido';

export type ToothFace = 'O' | 'M' | 'D' | 'V' | 'L'; // Oclusal, Mesial, Distal, Vestibular, Lingual/Palatina

export interface ToothRecord {
  toothNumber: number;
  status: ToothStatus;
  conditionTitle?: string;
  facesAffected?: ToothFace[];
  estimatedPrice?: number; // Preço estimado para orçamento automático
  notes?: string;
  updatedAt?: string;
}

export type PatientDentalChart = Record<number, ToothRecord>;

export interface EmergencyContact {
  name: string;
  phone: string;
  relationship?: string;
}

export interface GeneralHealthAnamnesis {
  allergies: string[]; // e.g. Penicilina, Dipirona, AINEs, Anestésicos locais c/ vaso, Látex, Iodo
  systemicDiseases: string[]; // Hipertensão arterial, Diabetes Tipo 1/2, Cardiopatias, Asma/Respiratório, Doença renal, Doença hepática
  continuousMedications: string; // Detalhes de medicações
  hasAnticoagulantsOrBisphosphonates: boolean; // Alerta crítico
  pregnancyStatus: 'nao' | 'gestante' | 'lactante';
  pregnancyDetails?: string; // ex: 2º trimestre (18 semanas)
  healingOrBleedingIssues: boolean; // Cicatrização lenta, hemorragias ou queda de pressão
  healingBleedingNotes?: string;
  habitsSmoking: 'nao' | 'fumante' | 'ex_fumante';
  habitsAlcohol: 'nao' | 'socialmente' | 'frequente';
}

export interface DentalAnamnesis {
  chiefComplaint: string; // Queixa principal
  lastDentalVisit: string; // 'Menos de 6 meses' | '6 a 12 meses' | 'Mais de 1 ano' | 'Mais de 2 anos' | 'Primeira vez'
  brushingFrequency: string; // '1x ao dia' | '2x ao dia' | '3x ou mais ao dia'
  flossFrequency: string; // 'Diariamente' | 'Às vezes' | 'Raramente / Nunca'
  toothSensitivity: {
    cold: boolean;
    hot: boolean;
    sweet: boolean;
  };
  gumBleeding: 'nenhum' | 'ao_escovar' | 'espontaneo';
  tmjOrBruxism: {
    jawPainOrClicking: boolean; // Dor ou estalos na mandíbula / ATM
    bruxismOrClenching: boolean; // Bruxismo ou apertamento
  };
  previousAnestheticReactions: string; // Desconforto prévio com anestésico local
  additionalNotes?: string;
}

export interface ClinicalEvolution {
  id: string;
  patientId: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  author: string; // "Dra. Pâmela"
  procedureDone?: string;
  toothNumber?: number;
  anestheticUsed?: string;
  content: string; // Relato da evolução clínica da sessão
  nextSessionPlan?: string;
}

export interface Patient {
  id: string;
  name: string;
  cpf: string;
  phone: string;
  birthDate: string; // YYYY-MM-DD
  gender?: 'feminino' | 'masculino' | 'outro' | 'prefiro_nao_informar';
  profession?: string;
  address: string;
  emergencyContact?: EmergencyContact;

  // Direct alert shortcuts (synced with generalHealth for fast querying)
  allergies: string[];
  medicalAlerts: string[];
  currentMedications?: string;
  notes?: string;
  createdAt: string;

  // Complete Step 2 & 3 Anamneses
  generalHealth?: GeneralHealthAnamnesis;
  dentalHealth?: DentalAnamnesis;

  // Evoluções Clínicas Contínuas
  clinicalEvolutions?: ClinicalEvolution[];
}

export type AppointmentStatus = 'agendado' | 'confirmado' | 'concluido' | 'cancelado';

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  durationMinutes: number;
  procedure: string;
  status: AppointmentStatus;
  notes?: string;
  estimatedPrice?: number;
}

export type BudgetStatus = 'pendente' | 'aprovado' | 'recusado' | 'pago';

export interface BudgetItem {
  id: string;
  description: string;
  toothNumber?: number;
  value: number;
}

export interface Budget {
  id: string;
  patientId: string;
  patientName: string;
  patientPhone?: string;
  date: string; // YYYY-MM-DD
  items: BudgetItem[];
  totalValue: number;
  status: BudgetStatus;
  paymentMethod?: 'pix' | 'cartao_credito' | 'cartao_debito' | 'dinheiro' | 'boleto';
  notes?: string;
  approvedDate?: string;
}

export interface MonthlyFinancialSummary {
  month: string;
  fullMonth: string;
  faturamento: number;
  orcamentosAprovados: number;
  orcamentosPendentes: number;
  qtdConsultas: number;
  qtdAprovados: number;
}

export interface AppBackupData {
  version: string;
  exportDate: string;
  exportedBy: string;
  patients: Patient[];
  appointments: Appointment[];
  dentalCharts: Record<string, PatientDentalChart>;
  budgets: Budget[];
  evolutions: Record<string, ClinicalEvolution[]>;
  documents?: ClinicalDocument[];
  photos?: Record<string, ClinicalPhoto[]>;
  consentForms?: Record<string, ConsentForm[]>;
}

export type DocumentType = 'receita' | 'atestado';
export type CertificateType = 'comparecimento' | 'repouso';

export interface PrescriptionMedicine {
  id: string;
  name: string;
  posology: string;
  quantity: string;
  notes?: string;
}

export interface PrescriptionDocument {
  id: string;
  type: 'receita';
  patientId: string;
  patientName: string;
  patientCpf?: string;
  patientPhone?: string;
  date: string; // YYYY-MM-DD
  medicines: PrescriptionMedicine[];
  generalInstructions?: string;
  createdAt: string;
}

export interface CertificateDocument {
  id: string;
  type: 'atestado';
  certificateType: CertificateType; // 'comparecimento' | 'repouso'
  patientId: string;
  patientName: string;
  patientCpf?: string;
  patientPhone?: string;
  date: string; // YYYY-MM-DD
  startTime?: string;
  endTime?: string;
  restDays?: number;
  startDate?: string;
  cid?: string;
  reason?: string;
  notes?: string;
  createdAt: string;
}

export type ClinicalDocument = PrescriptionDocument | CertificateDocument;

export type ClinicalDocumentInput =
  | Omit<PrescriptionDocument, 'id' | 'createdAt'>
  | Omit<CertificateDocument, 'id' | 'createdAt'>;

// Clinical Photos & Radiographs (Antes & Depois)
export type ClinicalPhotoCategory = 'antes' | 'depois' | 'evolucao' | 'radiografia' | 'outro';

export interface ClinicalPhoto {
  id: string;
  patientId: string;
  title: string;
  category: ClinicalPhotoCategory;
  imageData: string; // base64 or URL
  date: string; // YYYY-MM-DD
  toothNumber?: number;
  notes?: string;
  createdAt: string;
}

// Termo de Consentimento Livre e Esclarecido (TCLE) com Assinatura Digital
export type ConsentFormCategory =
  | 'clareamento'
  | 'extracao_siso'
  | 'endodontia'
  | 'implante_protese'
  | 'restauracao_estetica'
  | 'geral';

export interface ConsentForm {
  id: string;
  patientId: string;
  patientName: string;
  patientCpf: string;
  category: ConsentFormCategory;
  title: string;
  content: string;
  signatureDataUrl: string; // PNG base64 captured from canvas
  signedDate: string; // YYYY-MM-DD HH:mm
  signedByName: string;
  responsibleName?: string;
  professionalName: string; // Dra. Pâmela
  professionalCro: string; // CRO/SP
  createdAt: string;
}


