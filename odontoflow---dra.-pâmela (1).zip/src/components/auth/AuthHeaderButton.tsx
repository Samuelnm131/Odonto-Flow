import React, { useState, useRef, useEffect } from 'react';
import {
  LogIn,
  LogOut,
  User as UserIcon,
  ShieldCheck,
  Database,
  CheckCircle2,
  FileCheck,
  Download,
  Smartphone,
  ChevronDown,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const AuthHeaderButton: React.FC = () => {
  const { user, loading, error, signInWithGoogle, logout } = useAuth();
  const { openDocumentModal, setIsBackupModalOpen, documents } = useApp();
  const { isInstallable, isInstalled, install, isIOS } = usePWAInstall();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (loading) {
    return (
      <div className="w-8 h-8 rounded-full bg-slate-100 animate-pulse flex items-center justify-center" />
    );
  }

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 p-1 sm:pl-2 sm:pr-1.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-200/90 shadow-2xs transition-all active:scale-95 text-xs"
        title="Menu do Consultório & Conta Dra. Pâmela"
        aria-label="Menu do Consultório"
      >
        {user ? (
          <>
            <div className="text-right hidden sm:block">
              <p className="text-[11px] font-bold text-slate-800 leading-tight truncate max-w-[90px]">
                {user.displayName?.split(' ')[0] || 'Dra. Pâmela'}
              </p>
              <p className="text-[9px] text-teal-700 font-medium leading-none flex items-center justify-end gap-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                Nuvem
              </p>
            </div>
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'Usuário'}
                className="w-7 h-7 rounded-lg object-cover border border-teal-500/30"
              />
            ) : (
              <div className="w-7 h-7 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs">
                {user.displayName?.[0] || 'P'}
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center gap-1 px-1 py-0.5 text-slate-700">
            <div className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600">
              <UserIcon className="w-3.5 h-3.5" />
            </div>
            <span className="hidden sm:inline font-semibold text-[11px]">Menu</span>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </div>
        )}
      </button>

      {/* Unified Clinic & Account Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200/90 p-3 z-50 animate-in fade-in zoom-in-95 duration-150">
          {/* Header Profile / Google Section */}
          <div className="pb-3 border-b border-slate-100">
            {user ? (
              <div className="flex items-center gap-2.5">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'Usuário'}
                    className="w-9 h-9 rounded-xl object-cover border border-slate-200"
                  />
                ) : (
                  <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold text-sm">
                    {user.displayName?.[0] || 'P'}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-slate-900 truncate">
                    {user.displayName || 'Dra. Pâmela Meneghetti'}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                  <span className="inline-flex items-center gap-1 mt-0.5 px-1.5 py-0.2 rounded-md text-[9px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    Firestore Sincronizado
                  </span>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-teal-50 flex items-center justify-center text-teal-700">
                    <UserIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900">Dra. Pâmela Meneghetti</p>
                    <p className="text-[10px] text-slate-500">Modo Local / Offline</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setIsOpen(false);
                    signInWithGoogle();
                  }}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold text-xs shadow-2xs transition-all"
                >
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Conectar Conta Google</span>
                </button>
              </div>
            )}
          </div>

          {/* Quick Clinic Tools */}
          <div className="py-2 space-y-0.5 text-xs text-slate-700">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
              Ferramentas Clínicas
            </p>

            <button
              onClick={() => {
                setIsOpen(false);
                openDocumentModal();
              }}
              className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors text-left"
            >
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-teal-50 flex items-center justify-center text-teal-700">
                  <FileCheck className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="font-semibold text-slate-800">Receitas & Atestados</p>
                  <p className="text-[10px] text-slate-400">Modelos timbrados com assinatura</p>
                </div>
              </div>
              <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">
                {documents.length}
              </span>
            </button>

            <button
              onClick={() => {
                setIsOpen(false);
                setIsBackupModalOpen(true);
              }}
              className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors text-left"
            >
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700">
                  <Database className="w-3.5 h-3.5" />
                </div>
                <div>
                  <p className="font-semibold text-slate-800">Backup & Segurança</p>
                  <p className="text-[10px] text-slate-400">Exportar dados em JSON / Firestore</p>
                </div>
              </div>
            </button>

            {/* Install PWA Option if installable */}
            {isInstallable && (
              <button
                onClick={() => {
                  setIsOpen(false);
                  install();
                }}
                className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors text-left text-teal-800"
              >
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-teal-50 flex items-center justify-center text-teal-700">
                    <Download className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="font-bold text-teal-800">Instalar Aplicativo</p>
                    <p className="text-[10px] text-slate-400">Usar em tela cheia no dispositivo</p>
                  </div>
                </div>
              </button>
            )}
          </div>

          {/* Sign Out */}
          {user && (
            <div className="pt-1 border-t border-slate-100">
              <button
                onClick={() => {
                  setIsOpen(false);
                  logout();
                }}
                className="w-full flex items-center justify-center gap-1.5 p-2 rounded-xl text-rose-700 hover:bg-rose-50 font-bold text-xs transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Desconectar Conta Google</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
