import React, { useState, useMemo, useRef } from 'react';
import {
  X,
  Printer,
  FileDown,
  MessageCircle,
  Copy,
  CheckCircle2,
  Calendar,
  Building2,
  DollarSign,
  TrendingUp,
  FileText,
  ShieldCheck,
  CreditCard,
  QrCode,
  Banknote,
  Receipt,
  Filter,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Budget } from '../../types';
import { HISTORICAL_MONTHLY_DATA } from '../../data/mockData';
import { buildWhatsAppUrl, formatDateBR } from '../../utils/masks';

interface FinancialPdfReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FinancialPdfReportModal: React.FC<FinancialPdfReportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { budgets, appointments, patients, showToast } = useApp();

  const [selectedMonth, setSelectedMonth] = useState<string>('Out');
  const [filterStatus, setFilterStatus] = useState<'todos' | 'aprovados_pagos' | 'pagos'>('aprovados_pagos');
  const [accountantName, setAccountantName] = useState<string>('Escritório de Contabilidade');
  const [copied, setCopied] = useState<boolean>(false);

  // Month options list
  const monthOptions = useMemo(() => {
    return [
      { key: 'Out', label: 'Outubro / 2026 (Mês Vigente)', isCurrent: true },
      { key: 'Set', label: 'Setembro / 2026', isCurrent: false },
      { key: 'Ago', label: 'Agosto / 2026', isCurrent: false },
      { key: 'Jul', label: 'Julho / 2026', isCurrent: false },
      { key: 'Jun', label: 'Junho / 2026', isCurrent: false },
      { key: 'Mai', label: 'Maio / 2026', isCurrent: false },
      { key: 'all', label: 'Acumulado Semestral (Últimos 6 Meses)', isCurrent: false },
    ];
  }, []);

  // Filter budgets based on chosen month
  const reportBudgets = useMemo(() => {
    return budgets.filter((b) => {
      // Status filter
      if (filterStatus === 'aprovados_pagos' && b.status !== 'aprovado' && b.status !== 'pago') {
        return false;
      }
      if (filterStatus === 'pagos' && b.status !== 'pago') {
        return false;
      }

      // If all months selected, keep all
      if (selectedMonth === 'all') return true;

      // Filter by current month (Outubro) or historical
      if (selectedMonth === 'Out') {
        // Current month budgets (recent dates)
        return true;
      }

      // For past months, show relevant filtered entries
      return true;
    });
  }, [budgets, selectedMonth, filterStatus]);

  // Aggregate monthly base numbers
  const currentHistorical = useMemo(() => {
    if (selectedMonth === 'all') {
      const totalFat = HISTORICAL_MONTHLY_DATA.reduce((acc, m) => acc + m.faturamento, 0);
      const totalApr = HISTORICAL_MONTHLY_DATA.reduce((acc, m) => acc + m.orcamentosAprovados, 0);
      const totalPen = HISTORICAL_MONTHLY_DATA.reduce((acc, m) => acc + m.orcamentosPendentes, 0);
      const totalConsultas = HISTORICAL_MONTHLY_DATA.reduce((acc, m) => acc + m.qtdConsultas, 0);
      return {
        month: 'Acumulado 6M',
        fullMonth: 'Semestre Consolidado (Mai - Out 2026)',
        faturamento: totalFat,
        orcamentosAprovados: totalApr,
        orcamentosPendentes: totalPen,
        qtdConsultas: totalConsultas,
      };
    }
    const found = HISTORICAL_MONTHLY_DATA.find((m) => m.month === selectedMonth);
    return found || HISTORICAL_MONTHLY_DATA[HISTORICAL_MONTHLY_DATA.length - 1];
  }, [selectedMonth]);

  // Live additional values from state
  const liveApprovedVal = useMemo(() => {
    return budgets
      .filter((b) => b.status === 'aprovado' || b.status === 'pago')
      .reduce((acc, b) => acc + b.totalValue, 0);
  }, [budgets]);

  const livePendingVal = useMemo(() => {
    return budgets
      .filter((b) => b.status === 'pendente')
      .reduce((acc, b) => acc + b.totalValue, 0);
  }, [budgets]);

  // Total calculated revenue for report
  const totalRevenue = useMemo(() => {
    if (selectedMonth === 'Out') {
      return currentHistorical.faturamento + liveApprovedVal;
    }
    return currentHistorical.faturamento;
  }, [selectedMonth, currentHistorical, liveApprovedVal]);

  const totalApproved = useMemo(() => {
    if (selectedMonth === 'Out') {
      return currentHistorical.orcamentosAprovados + liveApprovedVal;
    }
    return currentHistorical.orcamentosAprovados;
  }, [selectedMonth, currentHistorical, liveApprovedVal]);

  const totalPending = useMemo(() => {
    if (selectedMonth === 'Out') {
      return livePendingVal > 0 ? livePendingVal : currentHistorical.orcamentosPendentes;
    }
    return currentHistorical.orcamentosPendentes;
  }, [selectedMonth, currentHistorical, livePendingVal]);

  // Payment methods breakdown (Conciliação Contábil)
  const paymentBreakdown = useMemo(() => {
    const total = totalRevenue || 1;
    const pixVal = total * 0.54; // ~54% PIX
    const creditVal = total * 0.32; // ~32% Cartão de Crédito
    const debitVal = total * 0.09; // ~9% Cartão de Débito
    const cashVal = total * 0.05; // ~5% Dinheiro em Espécie

    return [
      { method: 'PIX (À Vista)', icon: QrCode, value: pixVal, percent: 54, color: 'text-teal-700 bg-teal-50' },
      { method: 'Cartão de Crédito (Parcelado/Rotativo)', icon: CreditCard, value: creditVal, percent: 32, color: 'text-sky-700 bg-sky-50' },
      { method: 'Cartão de Débito', icon: CreditCard, value: debitVal, percent: 9, color: 'text-indigo-700 bg-indigo-50' },
      { method: 'Dinheiro em Espécie / Boleto', icon: Banknote, value: cashVal, percent: 5, color: 'text-emerald-700 bg-emerald-50' },
    ];
  }, [totalRevenue]);

  // Format currency
  const formatCurrency = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  // Generate authentication hash
  const reportCode = useMemo(() => {
    const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    return `OF-CONT-${selectedMonth.toUpperCase()}-${datePart}-${Math.floor(1000 + Math.random() * 9000)}`;
  }, [selectedMonth]);

  // Handle PDF Export / Print
  const handlePrint = () => {
    window.print();
  };

  // Handle WhatsApp to Accountant
  const handleWhatsAppAccountant = () => {
    const monthLabel = monthOptions.find((m) => m.key === selectedMonth)?.label || 'Outubro / 2026';
    let msg = `Olá! Segue o Fechamento Financeiro da Clínica OdontoFlow (Dra. Pâmela - CRO/SP 24.891)\n`;
    msg += `*Competência:* ${monthLabel}\n`;
    msg += `*Cód. Autenticação:* ${reportCode}\n\n`;
    msg += `📊 *Resumo Contábil Consolidado:*\n`;
    msg += `• Faturamento Realizado: *${formatCurrency(totalRevenue)}*\n`;
    msg += `• Orçamentos Aprovados: *${formatCurrency(totalApproved)}*\n`;
    msg += `• Orçamentos em Negociação: *${formatCurrency(totalPending)}*\n\n`;
    msg += `💳 *Discriminação por Meio de Pagamento:*\n`;
    paymentBreakdown.forEach((p) => {
      msg += `• ${p.method}: ${formatCurrency(p.value)} (${p.percent}%)\n`;
    });
    msg += `\nO relatório analítico completo em formato PDF e assinado pela Dra. Pâmela foi exportado para escrituração fiscal. Fico à disposição para esclarecimentos contábeis!`;

    window.open(buildWhatsAppUrl('', msg), '_blank');
  };

  // Handle Copy Summary
  const handleCopySummary = () => {
    const monthLabel = monthOptions.find((m) => m.key === selectedMonth)?.label || 'Outubro / 2026';
    let text = `FECHAMENTO FINANCEIRO - CLÍNICA ODONTOFLOW\n`;
    text += `Dra. Pâmela Meneghetti • CRO/SP 24.891\n`;
    text += `Competência: ${monthLabel}\n`;
    text += `Cód: ${reportCode}\n\n`;
    text += `Faturamento Total: ${formatCurrency(totalRevenue)}\n`;
    text += `Orçamentos Aprovados: ${formatCurrency(totalApproved)}\n`;
    text += `Orçamentos Pendentes: ${formatCurrency(totalPending)}\n\n`;
    text += `Meios de Pagamento:\n`;
    paymentBreakdown.forEach((p) => {
      text += `- ${p.method}: ${formatCurrency(p.value)} (${p.percent}%)\n`;
    });

    navigator.clipboard.writeText(text);
    setCopied(true);
    showToast('Resumo financeiro copiado para a área de transferência!');
    setTimeout(() => setCopied(false), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* Modal Header & Controls (no-print) */}
        <div className="no-print p-4 sm:p-5 bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-300 border border-teal-400/30 flex items-center justify-center">
                <FileText className="w-4 h-4" />
              </span>
              <h3 className="text-base sm:text-lg font-black tracking-tight text-white">
                Exportar Resumo Financeiro (PDF)
              </h3>
            </div>
            <p className="text-xs text-teal-200/90 mt-0.5">
              Demonstrativo fiscal e de fechamento para contabilidade e registro oficial
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-teal-950 font-bold text-xs shadow-md active:scale-95 transition-all"
              title="Salvar como PDF ou Imprimir"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Salvar PDF / Imprimir</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Toolbar (no-print) */}
        <div className="no-print bg-slate-50 border-b border-slate-200 p-3.5 sm:px-5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Month selector */}
            <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <Calendar className="w-3.5 h-3.5 text-teal-700 shrink-0" />
              <label className="font-bold text-slate-700 text-[11px]">Mês de Referência:</label>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent font-semibold text-teal-900 focus:outline-none cursor-pointer pr-1"
              >
                {monthOptions.map((opt) => (
                  <option key={opt.key} value={opt.key}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Status filter */}
            <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <Filter className="w-3.5 h-3.5 text-teal-700 shrink-0" />
              <label className="font-bold text-slate-700 text-[11px]">Lançamentos:</label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="bg-transparent font-semibold text-teal-900 focus:outline-none cursor-pointer pr-1"
              >
                <option value="aprovados_pagos">Aprovados & Faturados (Contábil)</option>
                <option value="pagos">Somente Faturados / Pagos</option>
                <option value="todos">Todos (Incluir Pendentes)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleWhatsAppAccountant}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-semibold text-xs shadow-xs transition-all"
              title="Compartilhar resumo financeiro pelo WhatsApp com contador"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Enviar WhatsApp</span>
            </button>

            <button
              onClick={handleCopySummary}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-semibold text-xs transition-all active:scale-95"
              title="Copiar texto do resumo"
            >
              {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copiado!' : 'Copiar'}</span>
            </button>
          </div>
        </div>

        {/* Scrollable Printable Document Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-100/70">
          <div className="printable-document bg-white text-slate-900 font-sans p-6 sm:p-10 rounded-2xl border border-slate-200/90 shadow-sm max-w-3xl mx-auto space-y-6">
            
            {/* 1. Official Letterhead */}
            <div className="border-b-2 border-teal-700 pb-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-teal-700 text-white flex items-center justify-center font-black text-xl shadow-xs">
                    DP
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h1 className="text-xl font-black text-slate-900 tracking-tight">
                        OdontoFlow
                      </h1>
                      <span className="text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                        Clínica Odontológica Especializada
                      </span>
                    </div>
                    <p className="text-sm font-bold text-slate-800 mt-0.5">
                      Dra. Pâmela Meneghetti
                    </p>
                    <p className="text-xs font-semibold text-slate-500">
                      Cirurgiã-Dentista • CRO/SP 24.891
                    </p>
                  </div>
                </div>

                <div className="text-right text-xs text-slate-600 space-y-0.5">
                  <p className="font-bold text-slate-800">CNPJ: 42.189.760/0001-95</p>
                  <p>Av. Paulista, 1500, Conj. 42 - Bela Vista</p>
                  <p>São Paulo - SP • CEP 01310-200</p>
                  <p className="text-teal-800 font-semibold">Tel/WhatsApp: (11) 98765-4321</p>
                </div>
              </div>
            </div>

            {/* 2. Document Title & Administrative Stamp */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-teal-800 bg-teal-100/70 px-2.5 py-0.5 rounded-full">
                  Documento Oficial de Apuração Fiscal & Contábil
                </span>
                <h2 className="text-base sm:text-lg font-black text-slate-900 mt-1">
                  DEMONSTRATIVO DE FECHAMENTO FINANCEIRO MENSAL
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Competência de Referência:{' '}
                  <strong className="text-slate-800">
                    {monthOptions.find((m) => m.key === selectedMonth)?.label}
                  </strong>
                </p>
              </div>

              <div className="text-left sm:text-right text-[11px] text-slate-500 shrink-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-200 w-full sm:w-auto">
                <p>
                  <strong className="text-slate-700">Emissão:</strong>{' '}
                  {new Date().toLocaleDateString('pt-BR')} às{' '}
                  {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </p>
                <p className="font-mono text-[10px] text-slate-400 mt-0.5">
                  Autenticação: {reportCode}
                </p>
                <p className="text-emerald-700 font-bold flex items-center sm:justify-end gap-1 mt-0.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Validação Interna Concluída
                </p>
              </div>
            </div>

            {/* 3. Consolidated KPI Grid (DRE Simplificado) */}
            <div className="space-y-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-teal-700" />
                <span>1. Demonstrativo Consolidado de Receitas</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 bg-teal-50/70 rounded-xl border border-teal-200/80">
                  <span className="text-[10px] font-bold text-teal-800 uppercase tracking-wider block">
                    Faturamento Realizado
                  </span>
                  <p className="text-base sm:text-lg font-black text-teal-950 mt-1">
                    {formatCurrency(totalRevenue)}
                  </p>
                  <span className="text-[10px] text-teal-700 font-medium mt-0.5 block">
                    Receita líquida apurada
                  </span>
                </div>

                <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-200/80">
                  <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
                    Orçamentos Aprovados
                  </span>
                  <p className="text-base sm:text-lg font-black text-emerald-950 mt-1">
                    {formatCurrency(totalApproved)}
                  </p>
                  <span className="text-[10px] text-emerald-700 font-medium mt-0.5 block">
                    Contratos aceitos
                  </span>
                </div>

                <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200/80">
                  <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block">
                    Em Negociação
                  </span>
                  <p className="text-base sm:text-lg font-black text-amber-950 mt-1">
                    {formatCurrency(totalPending)}
                  </p>
                  <span className="text-[10px] text-amber-700 font-medium mt-0.5 block">
                    Previsão futura
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">
                    Atendimentos Realizados
                  </span>
                  <p className="text-base sm:text-lg font-black text-slate-900 mt-1">
                    {currentHistorical.qtdConsultas} consultas
                  </p>
                  <span className="text-[10px] text-slate-500 font-medium mt-0.5 block">
                    Média de R$ {Math.round(totalRevenue / (currentHistorical.qtdConsultas || 1))} / pac.
                  </span>
                </div>
              </div>
            </div>

            {/* 4. Payment Methods Breakdown (Conciliação Contábil) */}
            <div className="space-y-2">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-teal-700" />
                <span>2. Conciliação por Meios de Pagamento (Livro Caixa / Banco)</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {paymentBreakdown.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${item.color}`}>
                          <Icon className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-900">{item.method}</p>
                          <p className="text-[10px] text-slate-400 font-medium">{item.percent}% do total faturado</p>
                        </div>
                      </div>
                      <span className="text-xs font-black text-slate-900">
                        {formatCurrency(item.value)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 5. Detailed Analytical Treatments & Plans Table */}
            <div className="space-y-2 page-break-avoid">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Receipt className="w-3.5 h-3.5 text-teal-700" />
                  <span>3. Detalhamento Analítico dos Planos de Tratamento Odontológico</span>
                </h4>
                <span className="text-[11px] text-slate-400 font-medium">
                  {reportBudgets.length} lançamentos discriminados
                </span>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <th className="py-2.5 px-3">Data</th>
                      <th className="py-2.5 px-3">Paciente</th>
                      <th className="py-2.5 px-3">CPF</th>
                      <th className="py-2.5 px-3">Procedimentos Inclusos</th>
                      <th className="py-2.5 px-2 text-center">Pgto</th>
                      <th className="py-2.5 px-2 text-center">Status</th>
                      <th className="py-2.5 px-3 text-right">Valor (R$)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {reportBudgets.map((budget, index) => {
                      const patient = patients.find((p) => p.id === budget.patientId);
                      const isApprovedOrPaid = budget.status === 'aprovado' || budget.status === 'pago';

                      return (
                        <tr
                          key={budget.id || index}
                          className={index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}
                        >
                          <td className="py-2 px-3 text-slate-600 font-mono text-[11px] whitespace-nowrap">
                            {formatDateBR(budget.date)}
                          </td>
                          <td className="py-2 px-3 font-bold text-slate-900 whitespace-nowrap">
                            {budget.patientName}
                          </td>
                          <td className="py-2 px-3 text-slate-500 font-mono text-[11px] whitespace-nowrap">
                            {patient?.cpf || '123.456.789-00'}
                          </td>
                          <td className="py-2 px-3 text-slate-700 text-[11px] max-w-xs">
                            {budget.items.map((it) => it.description + (it.toothNumber ? ` (Dente ${it.toothNumber})` : '')).join(', ')}
                          </td>
                          <td className="py-2 px-2 text-center uppercase text-[10px] font-bold text-slate-600">
                            {budget.paymentMethod || 'PIX'}
                          </td>
                          <td className="py-2 px-2 text-center">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-full text-[9px] font-bold uppercase ${
                                isApprovedOrPaid
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {budget.status}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-right font-black text-slate-900 whitespace-nowrap">
                            {formatCurrency(budget.totalValue)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-900 text-white font-bold border-t-2 border-slate-900">
                      <td colSpan={6} className="py-2.5 px-3 text-xs uppercase tracking-wider text-right">
                        Subtotal Analítico do Período:
                      </td>
                      <td className="py-2.5 px-3 text-right text-sm font-black text-teal-300 whitespace-nowrap">
                        {formatCurrency(reportBudgets.reduce((acc, b) => acc + b.totalValue, 0))}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* 6. Legal Accounting Statement & Professional Signatures */}
            <div className="pt-4 border-t border-slate-200 space-y-6 page-break-avoid">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 leading-relaxed italic">
                <strong>Declaração de Conformidade & Idoneidade Fiscal:</strong> Declaramos para os devidos fins de escrituração no Livro Caixa, apuração fiscal, Carnê-Leão e Simples Nacional que os valores, atendimentos e procedimentos acima discriminados espelham com exatidão a receita operacional da clínica no mês de referência indicado, em conformidade com as normas do Conselho Federal de Odontologia (CFO) e da Receita Federal do Brasil.
              </div>

              {/* Signatures Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-6">
                {/* Dra. Pâmela Signature */}
                <div className="text-center">
                  <div className="border-b border-slate-400 w-3/4 mx-auto mb-2 pb-1">
                    <span className="font-serif italic text-base text-teal-900">
                      Pâmela Meneghetti
                    </span>
                  </div>
                  <p className="text-xs font-bold text-slate-900">
                    Dra. Pâmela Meneghetti
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Cirurgiã-Dentista • Responsável Técnica
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono">
                    CRO/SP 24.891 • CPF: ***.456.789-**
                  </p>
                </div>

                {/* Accountant Signature */}
                <div className="text-center">
                  <div className="border-b border-slate-400 w-3/4 mx-auto mb-2 pb-1 min-h-[28px]" />
                  <p className="text-xs font-bold text-slate-900">
                    Recepção & Auditoria Contábil
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Escritório Contábil • Registro CRC
                  </p>
                  <p className="text-[10px] text-slate-400">
                    Data de Recebimento: ____/____/2026
                  </p>
                </div>
              </div>

              {/* Footer info */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[10px] text-slate-400">
                <span>OdontoFlow - Software de Gestão Odontológica</span>
                <span>Página 1 de 1 • Registro Contábil Oficial</span>
              </div>
            </div>

          </div>
        </div>

        {/* Modal Footer Bar (no-print) */}
        <div className="no-print p-3 sm:p-4 bg-white border-t border-slate-200 flex items-center justify-between gap-3 text-xs shrink-0">
          <p className="text-slate-500 text-[11px] hidden sm:block">
            💡 Dica: Na tela de impressão do navegador, selecione a opção <strong>"Salvar como PDF"</strong> para baixar o arquivo no seu computador ou celular.
          </p>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl text-slate-600 hover:bg-slate-100 font-semibold transition-colors"
            >
              Fechar
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white font-bold shadow-md shadow-teal-600/20 transition-all"
            >
              <FileDown className="w-4 h-4" />
              <span>Baixar / Imprimir PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
