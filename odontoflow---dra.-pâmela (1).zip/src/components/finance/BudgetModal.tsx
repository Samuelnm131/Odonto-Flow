import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, DollarSign, User, FileText, CheckCircle2 } from 'lucide-react';
import { Budget, BudgetItem, BudgetStatus } from '../../types';
import { useApp } from '../../context/AppContext';
import { COMMON_PROCEDURES, FDI_TEETH_NAMES } from '../../utils/masks';
import { getTodayString } from '../../data/mockData';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Budget, 'id'>) => void;
  initialData?: Budget | null;
  defaultPatientId?: string;
}

export const BudgetModal: React.FC<BudgetModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
  defaultPatientId,
}) => {
  const { patients, setIsNewPatientOpen } = useApp();

  const [patientId, setPatientId] = useState('');
  const [date, setDate] = useState(getTodayString());
  const [status, setStatus] = useState<BudgetStatus>('pendente');
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'cartao_credito' | 'cartao_debito' | 'dinheiro' | 'boleto'>('pix');
  const [notes, setNotes] = useState('');
  const [items, setItems] = useState<BudgetItem[]>([
    { id: '1', description: 'Restauração em Resina Composta', toothNumber: 16, value: 320 },
  ]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (initialData) {
      setPatientId(initialData.patientId);
      setDate(initialData.date);
      setStatus(initialData.status);
      setPaymentMethod(initialData.paymentMethod || 'pix');
      setNotes(initialData.notes || '');
      setItems(initialData.items.length > 0 ? initialData.items : [
        { id: '1', description: 'Procedimento Clínico', value: 200 }
      ]);
    } else {
      setPatientId(defaultPatientId || (patients[0]?.id ?? ''));
      setDate(getTodayString());
      setStatus('pendente');
      setPaymentMethod('pix');
      setNotes('');
      setItems([
        { id: Date.now().toString(), description: 'Restauração em Resina Composta', toothNumber: 16, value: 320 },
      ]);
    }
    setError('');
  }, [initialData, defaultPatientId, isOpen, patients]);

  if (!isOpen) return null;

  const totalValue = items.reduce((acc, item) => acc + (Number(item.value) || 0), 0);

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        description: COMMON_PROCEDURES[0],
        value: 250,
      },
    ]);
  };

  const handleRemoveItem = (id: string) => {
    if (items.length <= 1) {
      setError('O orçamento deve ter pelo menos um procedimento.');
      return;
    }
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleUpdateItem = (id: string, updates: Partial<BudgetItem>) => {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientId) {
      setError('Por favor, selecione um paciente.');
      return;
    }

    const patient = patients.find((p) => p.id === patientId);
    if (!patient) {
      setError('Paciente não encontrado.');
      return;
    }

    if (items.length === 0 || totalValue <= 0) {
      setError('Adicione pelo menos um item com valor válido ao orçamento.');
      return;
    }

    onSave({
      patientId,
      patientName: patient.name,
      patientPhone: patient.phone,
      date,
      items,
      totalValue,
      status,
      paymentMethod,
      notes: notes.trim(),
      approvedDate: status === 'aprovado' || status === 'pago' ? getTodayString() : undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-xl max-h-[92vh] sm:max-h-[88vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                {initialData ? 'Editar Orçamento' : 'Novo Orçamento Odontológico'}
              </h3>
              <p className="text-xs text-slate-500">Dra. Pâmela • Gestão Financeira</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-700">
              {error}
            </div>
          )}

          {/* Paciente e Data */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Paciente *
                </label>
                <button
                  type="button"
                  onClick={() => setIsNewPatientOpen(true)}
                  className="text-xs text-teal-700 font-semibold hover:underline"
                >
                  + Novo
                </button>
              </div>
              <select
                value={patientId}
                onChange={(e) => setPatientId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="" disabled>Selecione um paciente...</option>
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Data do Orçamento
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                required
              />
            </div>
          </div>

          {/* Lista de Procedimentos / Itens */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Itens & Procedimentos do Plano de Tratamento
              </label>
              <button
                type="button"
                onClick={handleAddItem}
                className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 hover:text-teal-800"
              >
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                Adicionar Procedimento
              </button>
            </div>

            <div className="space-y-2.5">
              {items.map((item, index) => (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-600">Item #{index + 1}</span>
                    {items.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(item.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                        title="Remover Item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                    <div className="sm:col-span-6">
                      <input
                        type="text"
                        value={item.description}
                        onChange={(e) => handleUpdateItem(item.id, { description: e.target.value })}
                        placeholder="Descrição do procedimento"
                        list={`proc-list-${item.id}`}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                        required
                      />
                      <datalist id={`proc-list-${item.id}`}>
                        {COMMON_PROCEDURES.map((p) => (
                          <option key={p} value={p} />
                        ))}
                      </datalist>
                    </div>

                    <div className="sm:col-span-3">
                      <select
                        value={item.toothNumber || ''}
                        onChange={(e) =>
                          handleUpdateItem(item.id, {
                            toothNumber: e.target.value ? Number(e.target.value) : undefined,
                          })
                        }
                        className="w-full px-2 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                      >
                        <option value="">Geral / Arcada</option>
                        {Object.entries(FDI_TEETH_NAMES).map(([num, name]) => (
                          <option key={num} value={num}>
                            Dente {num} ({name.slice(0, 16)}...)
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-3">
                      <div className="relative">
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                          R$
                        </span>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          value={item.value || ''}
                          onChange={(e) =>
                            handleUpdateItem(item.id, { value: parseFloat(e.target.value) || 0 })
                          }
                          placeholder="0,00"
                          className="w-full pl-8 pr-2.5 py-2 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500 text-right"
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Totalizador */}
            <div className="p-3 rounded-2xl bg-teal-50/90 border border-teal-200/90 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <span className="text-xs font-bold text-teal-900 block truncate">Total do Orçamento:</span>
                <span className="text-[11px] text-teal-700">
                  {items.length} {items.length === 1 ? 'procedimento' : 'procedimentos'}
                </span>
              </div>
              <span className="text-base sm:text-lg font-black text-teal-950 whitespace-nowrap shrink-0">
                {totalValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
          </div>

          {/* Status do Orçamento e Forma de Pagamento */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Status do Orçamento
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as BudgetStatus)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="pendente">⏳ Pendente de Aprovação</option>
                <option value="aprovado">✅ Aprovado pelo Paciente</option>
                <option value="pago">💰 Pago / Faturado</option>
                <option value="recusado">❌ Recusado</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Forma de Pagamento
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="pix">PIX (À Vista)</option>
                <option value="cartao_credito">Cartão de Crédito</option>
                <option value="cartao_debito">Cartão de Débito</option>
                <option value="dinheiro">Dinheiro em Espécie</option>
                <option value="boleto">Boleto Bancário</option>
              </select>
            </div>
          </div>

          {/* Observações / Condições */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Condições & Observações
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Ex: Condição especial com 5% de desconto para pagamento via PIX, parcelamento em até 6x..."
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
            />
          </div>

          {/* Actions (pb-safe for iPhone) */}
          <div className="pt-2 pb-safe sm:pb-0 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 active:scale-95 transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 shadow-md shadow-teal-600/20 transition-all"
            >
              {initialData ? 'Salvar Alterações' : 'Gerar Orçamento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
