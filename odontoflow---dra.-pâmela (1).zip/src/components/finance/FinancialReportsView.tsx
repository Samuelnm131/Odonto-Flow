import React, { useState, useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  TrendingUp,
  DollarSign,
  CheckCircle2,
  Clock,
  Plus,
  MessageCircle,
  FileText,
  Filter,
  ArrowUpRight,
  Sparkles,
  PieChart as PieIcon,
  Trash2,
  Edit2,
  Calendar,
  FileDown,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Budget, BudgetStatus } from '../../types';
import { HISTORICAL_MONTHLY_DATA, REVENUE_BY_PROCEDURE } from '../../data/mockData';
import { buildWhatsAppUrl, formatDateBR } from '../../utils/masks';
import { BudgetModal } from './BudgetModal';
import { FinancialPdfReportModal } from './FinancialPdfReportModal';

export const FinancialReportsView: React.FC = () => {
  const {
    budgets,
    appointments,
    addBudget,
    updateBudget,
    updateBudgetStatus,
    deleteBudget,
    isNewBudgetOpen,
    setIsNewBudgetOpen,
  } = useApp();

  const [timeRange, setTimeRange] = useState<'6m' | 'ano'>('6m');
  const [activeChartTab, setActiveChartTab] = useState<'faturamento' | 'aprovacao' | 'procedimentos'>('faturamento');
  const [budgetFilter, setBudgetFilter] = useState<'todos' | 'pendente' | 'aprovado' | 'pago' | 'recusado'>('todos');
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);

  // Compute live metrics from actual budgets + historical data
  const metrics = useMemo(() => {
    const totalApprovedBudgetVal = budgets
      .filter((b) => b.status === 'aprovado' || b.status === 'pago')
      .reduce((acc, b) => acc + b.totalValue, 0);

    const totalPendingBudgetVal = budgets
      .filter((b) => b.status === 'pendente')
      .reduce((acc, b) => acc + b.totalValue, 0);

    const approvedCount = budgets.filter((b) => b.status === 'aprovado' || b.status === 'pago').length;
    const totalBudgetsCount = budgets.length;
    const approvalRate = totalBudgetsCount > 0 ? Math.round((approvedCount / totalBudgetsCount) * 100) : 0;

    // Completed appointments revenue this month
    const completedAptsRevenue = appointments
      .filter((a) => a.status === 'concluido' && a.estimatedPrice)
      .reduce((acc, a) => acc + (a.estimatedPrice || 0), 0);

    const currentMonthRevenue = 18750 + totalApprovedBudgetVal;
    const totalAccumulatedRevenue = HISTORICAL_MONTHLY_DATA.reduce((acc, m) => acc + m.faturamento, 0) + totalApprovedBudgetVal;

    return {
      currentMonthRevenue,
      totalAccumulatedRevenue,
      totalApprovedBudgetVal,
      totalPendingBudgetVal,
      approvedCount,
      totalBudgetsCount,
      approvalRate,
    };
  }, [budgets, appointments]);

  // Combine historical data with dynamic live updates for current month
  const chartData = useMemo(() => {
    return HISTORICAL_MONTHLY_DATA.map((item, idx) => {
      // For the current month (last item), merge real-time added budgets
      if (idx === HISTORICAL_MONTHLY_DATA.length - 1) {
        const liveApproved = budgets
          .filter((b) => b.status === 'aprovado' || b.status === 'pago')
          .reduce((acc, b) => acc + b.totalValue, 0);

        const livePending = budgets
          .filter((b) => b.status === 'pendente')
          .reduce((acc, b) => acc + b.totalValue, 0);

        return {
          ...item,
          faturamento: item.faturamento + liveApproved,
          orcamentosAprovados: item.orcamentosAprovados + liveApproved,
          orcamentosPendentes: livePending > 0 ? livePending : item.orcamentosPendentes,
        };
      }
      return item;
    });
  }, [budgets]);

  // Format currency tooltip
  const formatCurrency = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  // Proportional and responsive currency renderer for cards to prevent overflow
  const renderCardCurrency = (val: number) => {
    const formatted = val.toLocaleString('pt-BR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    const [integerPart, decimalPart] = formatted.split(',');

    return (
      <div
        className="flex items-baseline min-w-0 max-w-full overflow-hidden"
        title={`R$ ${formatted}`}
      >
        <span className="text-[10px] sm:text-xs font-bold text-slate-400 shrink-0 mr-1 select-none">
          R$
        </span>
        <span className="text-base sm:text-lg lg:text-xl font-black text-slate-900 tracking-tight truncate leading-tight">
          {integerPart}
        </span>
        <span className="text-[10px] sm:text-xs font-bold text-slate-400 shrink-0">
          ,{decimalPart}
        </span>
      </div>
    );
  };

  const filteredBudgets = useMemo(() => {
    if (budgetFilter === 'todos') return budgets;
    return budgets.filter((b) => b.status === budgetFilter);
  }, [budgets, budgetFilter]);

  const handleOpenWhatsAppBudget = (budget: Budget) => {
    const phone = budget.patientPhone || '(11) 98765-4321';
    let text = `Olá ${budget.patientName}, tudo bem? Aqui é da clínica da Dra. Pâmela.\n`;
    text += `Segue o detalhamento do seu Plano de Tratamento Odontológico:\n\n`;

    budget.items.forEach((item, idx) => {
      text += `${idx + 1}. ${item.description}${item.toothNumber ? ` (Dente ${item.toothNumber})` : ''} - ${formatCurrency(item.value)}\n`;
    });

    text += `\n*Valor Total:* ${formatCurrency(budget.totalValue)}\n`;
    text += `*Condição:* ${budget.paymentMethod ? budget.paymentMethod.toUpperCase() : 'À Vista / Parcelado'}\n`;
    if (budget.notes) text += `*Obs:* ${budget.notes}\n`;
    text += `\nFicamos à disposição para agendarmos sua próxima etapa!`;

    window.open(buildWhatsAppUrl(phone, text), '_blank');
  };

  const handleSaveBudget = (data: Omit<Budget, 'id'>) => {
    if (editingBudget) {
      updateBudget(editingBudget.id, data);
      setEditingBudget(null);
    } else {
      addBudget(data);
    }
  };

  const getStatusBadge = (status: BudgetStatus) => {
    switch (status) {
      case 'aprovado':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Aprovado
          </span>
        );
      case 'pago':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal-100 text-teal-800 border border-teal-200">
            <DollarSign className="w-3 h-3 text-teal-600" />
            Faturado / Pago
          </span>
        );
      case 'recusado':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
            Recusado
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" />
            Pendente
          </span>
        );
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
            Relatórios Financeiros
          </h2>
          <p className="text-xs text-slate-500">
            Faturamento mensal e gestão de orçamentos da Dra. Pâmela
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPdfModalOpen(true)}
            className="flex items-center gap-1.5 px-3 sm:px-3.5 py-2 rounded-2xl bg-white hover:bg-teal-50/70 text-teal-800 border border-teal-200 active:scale-95 text-xs font-bold shadow-xs transition-all shrink-0"
            title="Exportar Resumo Financeiro Oficial em PDF para Contador ou Registro Fiscal"
          >
            <FileDown className="w-4 h-4 text-teal-600" />
            <span className="hidden xs:inline">Exportar</span> PDF Contábil
          </button>

          <button
            onClick={() => setIsNewBudgetOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold shadow-md shadow-teal-600/20 transition-all shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[2.3]" />
            <span>Novo Orçamento</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
        {/* Card 1: Faturamento Mês Atual */}
        <div className="bg-white p-3 sm:p-3.5 rounded-2xl border border-slate-200/90 shadow-xs min-w-0 overflow-hidden flex flex-col justify-between hover:border-teal-300 transition-colors">
          <div className="flex items-center justify-between gap-1 mb-2">
            <div className="w-7 h-7 rounded-xl bg-teal-50 flex items-center justify-center text-teal-700 shrink-0">
              <TrendingUp className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded-md shrink-0">
              +14%
            </span>
          </div>
          <div className="min-w-0">
            {renderCardCurrency(metrics.currentMonthRevenue)}
            <p className="text-[11px] font-medium text-slate-500 mt-1 truncate" title="Faturamento no Mês">
              Faturamento no Mês
            </p>
          </div>
        </div>

        {/* Card 2: Orçamentos Aprovados */}
        <div className="bg-white p-3 sm:p-3.5 rounded-2xl border border-slate-200/90 shadow-xs min-w-0 overflow-hidden flex flex-col justify-between hover:border-emerald-300 transition-colors">
          <div className="flex items-center justify-between gap-1 mb-2">
            <div className="w-7 h-7 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700 shrink-0">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-md shrink-0 truncate max-w-[85px] sm:max-w-none">
              {metrics.approvedCount} aprovados
            </span>
          </div>
          <div className="min-w-0">
            {renderCardCurrency(metrics.totalApprovedBudgetVal)}
            <p className="text-[11px] font-medium text-slate-500 mt-1 truncate" title="Orçamentos Aprovados">
              Orçamentos Aprovados
            </p>
          </div>
        </div>

        {/* Card 3: Orçamentos Pendentes */}
        <div className="bg-white p-3 sm:p-3.5 rounded-2xl border border-slate-200/90 shadow-xs min-w-0 overflow-hidden flex flex-col justify-between hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between gap-1 mb-2">
            <div className="w-7 h-7 rounded-xl bg-amber-50 flex items-center justify-center text-amber-700 shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <span className="flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded-md shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
              Pendente
            </span>
          </div>
          <div className="min-w-0">
            {renderCardCurrency(metrics.totalPendingBudgetVal)}
            <p className="text-[11px] font-medium text-slate-500 mt-1 truncate" title="Em Negociação">
              Em Negociação
            </p>
          </div>
        </div>

        {/* Card 4: Taxa de Conversão */}
        <div className="bg-white p-3 sm:p-3.5 rounded-2xl border border-slate-200/90 shadow-xs min-w-0 overflow-hidden flex flex-col justify-between hover:border-sky-300 transition-colors">
          <div className="flex items-center justify-between gap-1 mb-2">
            <div className="w-7 h-7 rounded-xl bg-sky-50 flex items-center justify-center text-sky-700 shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-sky-700 bg-sky-50 px-1.5 py-0.5 rounded-md shrink-0 truncate">
              Conversão
            </span>
          </div>
          <div className="min-w-0">
            <div className="flex items-baseline min-w-0 max-w-full overflow-hidden">
              <span className="text-base sm:text-lg lg:text-xl font-black text-slate-900 tracking-tight">
                {metrics.approvalRate}
              </span>
              <span className="text-xs sm:text-sm font-black text-slate-500 ml-0.5">
                %
              </span>
            </div>
            <p className="text-[11px] font-medium text-slate-500 mt-1 truncate" title="Taxa de Aprovação">
              Taxa de Aprovação
            </p>
          </div>
        </div>
      </div>

      {/* Main Charts Section */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs space-y-3">
        {/* Chart View Switcher */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-teal-600" />
              {activeChartTab === 'faturamento' && 'Evolução do Faturamento Mensal (R$)'}
              {activeChartTab === 'aprovacao' && 'Orçamentos Aprovados vs Pendentes por Mês'}
              {activeChartTab === 'procedimentos' && 'Faturamento por Procedimento Odontológico'}
            </h3>
            <p className="text-[11px] text-slate-500">
              {activeChartTab === 'faturamento' && 'Comparativo de receitas e orçamentos aprovados'}
              {activeChartTab === 'aprovacao' && 'Volume financeiro de planos aceitos pela clínica'}
              {activeChartTab === 'procedimentos' && 'Procedimentos mais rentáveis da Dra. Pâmela'}
            </p>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl text-xs font-semibold self-stretch sm:self-auto justify-between">
            <button
              onClick={() => setActiveChartTab('faturamento')}
              className={`px-2.5 py-1 rounded-xl transition-all ${
                activeChartTab === 'faturamento'
                  ? 'bg-white text-teal-800 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Faturamento
            </button>
            <button
              onClick={() => setActiveChartTab('aprovacao')}
              className={`px-2.5 py-1 rounded-xl transition-all ${
                activeChartTab === 'aprovacao'
                  ? 'bg-white text-teal-800 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Orçamentos
            </button>
            <button
              onClick={() => setActiveChartTab('procedimentos')}
              className={`px-2.5 py-1 rounded-xl transition-all ${
                activeChartTab === 'procedimentos'
                  ? 'bg-white text-teal-800 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Procedimentos
            </button>
          </div>
        </div>

        {/* 1. Bar Chart: Faturamento Mensal */}
        {activeChartTab === 'faturamento' && (
          <div className="h-68 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -5, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="month"
                  tickLine={false}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }}
                />
                <YAxis
                  width={45}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 10, fill: '#94a3b8' }}
                  tickFormatter={(val) => `R$${val >= 1000 ? Math.round(val / 1000) : val}k`}
                />
                <Tooltip
                  formatter={(value: any) => [formatCurrency(Number(value)), '']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderRadius: '16px',
                    border: 'none',
                    color: '#ffffff',
                    fontSize: '12px',
                    fontWeight: 600,
                    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)',
                  }}
                  itemStyle={{ color: '#5eead4' }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                  iconType="circle"
                />
                <Bar
                  dataKey="faturamento"
                  name="Faturamento Realizado"
                  fill="#0d9488"
                  radius={[6, 6, 0, 0]}
                />
                <Bar
                  dataKey="orcamentosAprovados"
                  name="Orçamentos Aprovados"
                  fill="#14b8a6"
                  radius={[6, 6, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* 2. Bar Chart: Orçamentos Aprovados vs Pendentes */}
        {activeChartTab === 'aprovacao' && (
          <div className="h-68 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 10, right: 10, left: -5, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="month"
                  tickLine={false}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }}
                />
                <YAxis
                  width={45}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 10, fill: '#94a3b8' }}
                  tickFormatter={(val) => `R$${val >= 1000 ? Math.round(val / 1000) : val}k`}
                />
                <Tooltip
                  formatter={(value: any) => [formatCurrency(Number(value)), '']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderRadius: '16px',
                    border: 'none',
                    color: '#ffffff',
                    fontSize: '12px',
                    fontWeight: 600,
                  }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                  iconType="circle"
                />
                <Bar
                  dataKey="orcamentosAprovados"
                  name="Aprovados (R$)"
                  fill="#10b981"
                  radius={[6, 6, 0, 0]}
                />
                <Bar
                  dataKey="orcamentosPendentes"
                  name="Em Negociação (R$)"
                  fill="#f59e0b"
                  radius={[6, 6, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* 3. Bar Chart: Procedimentos Mais Rentáveis */}
        {activeChartTab === 'procedimentos' && (
          <div className="h-68 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={REVENUE_BY_PROCEDURE}
                layout="vertical"
                margin={{ top: 5, right: 15, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  tickLine={false}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tick={{ fontSize: 10, fill: '#94a3b8' }}
                  tickFormatter={(val) => `R$${(val / 1000).toFixed(0)}k`}
                />
                <YAxis
                  type="category"
                  dataKey="procedure"
                  width={110}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 9.5, fill: '#334155', fontWeight: 600 }}
                />
                <Tooltip
                  formatter={(value: any) => [formatCurrency(Number(value)), 'Receita Total']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderRadius: '16px',
                    border: 'none',
                    color: '#ffffff',
                    fontSize: '12px',
                    fontWeight: 600,
                  }}
                />
                <Bar
                  dataKey="valor"
                  name="Faturamento Acumulado"
                  fill="#0d9488"
                  radius={[0, 6, 6, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Section: Gestão de Orçamentos da Clínica */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Orçamentos Clínicos
            </h3>
            <p className="text-xs text-slate-500">
              {filteredBudgets.length} orçamentos encontrados
            </p>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl text-xs font-semibold overflow-x-auto no-scrollbar">
            {(['todos', 'pendente', 'aprovado', 'pago'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setBudgetFilter(st)}
                className={`px-2.5 py-1 rounded-xl capitalize transition-all ${
                  budgetFilter === st
                    ? 'bg-white text-teal-800 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st === 'todos' ? 'Todos' : st === 'pendente' ? 'Pendentes' : st === 'aprovado' ? 'Aprovados' : 'Pagos'}
              </button>
            ))}
          </div>
        </div>

        {filteredBudgets.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <FileText className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Nenhum orçamento com este filtro</h4>
            <p className="text-xs text-slate-500 mt-1">
              Adicione um novo orçamento para o paciente ou altere os filtros acima.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredBudgets.map((budget) => (
              <div
                key={budget.id}
                className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-2xl bg-teal-50 border border-teal-100 text-teal-800 font-bold flex items-center justify-center shrink-0">
                      <DollarSign className="w-5 h-5 text-teal-600" />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-bold text-slate-900 truncate">{budget.patientName}</h4>
                        <span className="text-[10px] text-slate-400 font-medium shrink-0">
                          {formatDateBR(budget.date)}
                        </span>
                      </div>

                      <div className="mt-1 space-y-0.5">
                        {budget.items.slice(0, 2).map((item, i) => (
                          <p key={i} className="text-xs text-slate-600 truncate">
                            • {item.description} {item.toothNumber && `(Dente ${item.toothNumber})`}
                          </p>
                        ))}
                        {budget.items.length > 2 && (
                          <p className="text-[11px] text-teal-700 font-medium">
                            + {budget.items.length - 2} outros procedimentos
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1 shrink-0 text-right">
                    <span className="text-sm sm:text-base font-black text-slate-900 whitespace-nowrap">
                      {formatCurrency(budget.totalValue)}
                    </span>
                    {getStatusBadge(budget.status)}
                  </div>
                </div>

                {/* Bottom Action Bar */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                  {/* WhatsApp send button */}
                  <button
                    onClick={() => handleOpenWhatsAppBudget(budget)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold active:scale-95 transition-all"
                    title="Enviar orçamento formatado no WhatsApp do paciente"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" />
                    <span>Enviar Orçamento</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {budget.status === 'pendente' && (
                      <button
                        onClick={() => updateBudgetStatus(budget.id, 'aprovado')}
                        className="px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all"
                        title="Marcar como Aprovado pelo Paciente"
                      >
                        Aprovar
                      </button>
                    )}

                    {budget.status === 'aprovado' && (
                      <button
                        onClick={() => updateBudgetStatus(budget.id, 'pago')}
                        className="px-2.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all"
                        title="Marcar como Pago"
                      >
                        Faturar / Pago
                      </button>
                    )}

                    <button
                      onClick={() => setEditingBudget(budget)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                      title="Editar Orçamento"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(`Deseja excluir o orçamento de ${budget.patientName}?`)) {
                          deleteBudget(budget.id);
                        }
                      }}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                      title="Excluir Orçamento"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Budget Creation / Edit Modal */}
      <BudgetModal
        isOpen={isNewBudgetOpen || !!editingBudget}
        onClose={() => {
          setIsNewBudgetOpen(false);
          setEditingBudget(null);
        }}
        onSave={handleSaveBudget}
        initialData={editingBudget}
      />

      {/* Official Financial PDF Report Modal */}
      <FinancialPdfReportModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
      />
    </div>
  );
};
