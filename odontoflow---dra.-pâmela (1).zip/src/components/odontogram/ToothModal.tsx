import React, { useState, useEffect } from 'react';
import { X, Check, AlertTriangle, ShieldCheck, Clock, Ban, DollarSign, FileText } from 'lucide-react';
import { ToothRecord, ToothStatus, ToothFace } from '../../types';
import { FDI_TEETH_NAMES } from '../../utils/masks';

interface ToothModalProps {
  isOpen: boolean;
  onClose: () => void;
  toothNumber: number | null;
  currentRecord?: ToothRecord;
  patientName: string;
  onSave: (toothNumber: number, record: Partial<ToothRecord>, addToBudget?: boolean) => void;
}

const FACES: { id: ToothFace; name: string }[] = [
  { id: 'O', name: 'Oclusal / Incisal' },
  { id: 'M', name: 'Mesial' },
  { id: 'D', name: 'Distal' },
  { id: 'V', name: 'Vestibular' },
  { id: 'L', name: 'Lingual / Palatina' },
];

export const ToothModal: React.FC<ToothModalProps> = ({
  isOpen,
  onClose,
  toothNumber,
  currentRecord,
  patientName,
  onSave,
}) => {
  const [status, setStatus] = useState<ToothStatus>('higido');
  const [conditionTitle, setConditionTitle] = useState('');
  const [selectedFaces, setSelectedFaces] = useState<ToothFace[]>([]);
  const [notes, setNotes] = useState('');
  const [estimatedPrice, setEstimatedPrice] = useState<string>('');
  const [addToBudget, setAddToBudget] = useState<boolean>(true);

  useEffect(() => {
    if (currentRecord) {
      setStatus(currentRecord.status || 'higido');
      setConditionTitle(currentRecord.conditionTitle || '');
      setSelectedFaces(currentRecord.facesAffected || []);
      setNotes(currentRecord.notes || '');
      setEstimatedPrice(
        currentRecord.estimatedPrice !== undefined
          ? String(currentRecord.estimatedPrice)
          : currentRecord.status === 'tratamento_necessario'
          ? '280'
          : ''
      );
      setAddToBudget(true);
    } else {
      setStatus('higido');
      setConditionTitle('');
      setSelectedFaces([]);
      setNotes('');
      setEstimatedPrice('');
      setAddToBudget(true);
    }
  }, [currentRecord, isOpen]);

  // When doctor selects 'tratamento_necessario', auto-suggest price if empty
  const handleStatusChange = (newStatus: ToothStatus) => {
    setStatus(newStatus);
    if (newStatus === 'tratamento_necessario') {
      if (!estimatedPrice) {
        setEstimatedPrice('280');
      }
      setAddToBudget(true);
    }
  };

  if (!isOpen || toothNumber === null) return null;

  const toothName = FDI_TEETH_NAMES[toothNumber] || `Dente ${toothNumber}`;

  const toggleFace = (face: ToothFace) => {
    setSelectedFaces((prev) =>
      prev.includes(face) ? prev.filter((f) => f !== face) : [...prev, face]
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedPrice = estimatedPrice.trim() ? parseFloat(estimatedPrice.replace(',', '.')) : undefined;

    onSave(
      toothNumber,
      {
        status,
        conditionTitle: conditionTitle.trim(),
        facesAffected: selectedFaces,
        notes: notes.trim(),
        estimatedPrice: !isNaN(Number(parsedPrice)) ? Number(parsedPrice) : undefined,
      },
      status === 'tratamento_necessario' ? addToBudget : false
    );
    onClose();
  };

  const statusOptions: {
    id: ToothStatus;
    title: string;
    desc: string;
    icon: React.ElementType;
    activeClasses: string;
  }[] = [
    {
      id: 'higido',
      title: 'Hígido (Saudável)',
      desc: 'Dente sem lesões de cárie ou restaurações necessárias',
      icon: ShieldCheck,
      activeClasses: 'border-emerald-500 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500/20',
    },
    {
      id: 'tratamento_necessario',
      title: 'Tratamento Necessário',
      desc: 'Cárie ativa, canal, fratura ou indicação clínica',
      icon: AlertTriangle,
      activeClasses: 'border-rose-500 bg-rose-50 text-rose-900 ring-2 ring-rose-500/20',
    },
    {
      id: 'tratamento_concluido',
      title: 'Tratamento Concluído',
      desc: 'Restauração realizada, coroa ou canal finalizado',
      icon: Check,
      activeClasses: 'border-teal-500 bg-teal-50 text-teal-900 ring-2 ring-teal-500/20',
    },
    {
      id: 'em_andamento',
      title: 'Em Andamento',
      desc: 'Tratamento iniciado / Curativo provisório',
      icon: Clock,
      activeClasses: 'border-amber-500 bg-amber-50 text-amber-900 ring-2 ring-amber-500/20',
    },
    {
      id: 'ausente_extraido',
      title: 'Ausente / Extraído',
      desc: 'Dente não erupcionado, agenesia ou exodontia',
      icon: Ban,
      activeClasses: 'border-slate-500 bg-slate-100 text-slate-800 ring-2 ring-slate-500/20',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-lg max-h-[92vh] sm:max-h-[88vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white font-extrabold flex items-center justify-center text-sm shadow-sm">
              {toothNumber}
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                {toothName}
              </h3>
              <p className="text-xs text-slate-500">
                Paciente: <strong className="text-slate-700">{patientName}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Status Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              Status Clínico do Dente *
            </label>
            <div className="space-y-2">
              {statusOptions.map((opt) => {
                const Icon = opt.icon;
                const isSelected = status === opt.id;
                return (
                  <button
                    type="button"
                    key={opt.id}
                    onClick={() => handleStatusChange(opt.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-2xl border text-left transition-all ${
                      isSelected
                        ? opt.activeClasses
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-white shadow-xs'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xs font-bold text-slate-900 leading-tight">
                        {opt.title}
                      </h4>
                      <p className="text-[11px] text-slate-500">{opt.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Integration: Orçamento e Valor Estimado */}
          {status === 'tratamento_necessario' && (
            <div className="p-3.5 rounded-2xl bg-rose-50/70 border border-rose-200/80 space-y-3 animate-in fade-in">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-900">
                <DollarSign className="w-4 h-4 text-rose-600" />
                <span>Integração com Orçamentos</span>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  Valor Estimado do Procedimento (R$)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">
                    R$
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={estimatedPrice}
                    onChange={(e) => setEstimatedPrice(e.target.value)}
                    placeholder="Ex: 280,00"
                    className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-rose-200 bg-white text-sm text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <label className="flex items-start gap-2.5 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={addToBudget}
                  onChange={(e) => setAddToBudget(e.target.checked)}
                  className="mt-0.5 rounded text-rose-600 focus:ring-rose-500"
                />
                <span className="text-xs text-rose-950 font-medium">
                  <strong>Gerar item de orçamento para este paciente</strong> (adiciona à lista de orçamentos pendentes automaticamente ao salvar).
                </span>
              </label>
            </div>
          )}

          {/* Faces / Superfícies Afetadas */}
          {status !== 'ausente_extraido' && (
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Superfícies / Faces do Dente (Opcional)
              </label>
              <div className="flex flex-wrap gap-1.5">
                {FACES.map((face) => {
                  const isSelected = selectedFaces.includes(face.id);
                  return (
                    <button
                      type="button"
                      key={face.id}
                      onClick={() => toggleFace(face.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                        isSelected
                          ? 'bg-teal-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {face.id} - {face.name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Diagnóstico / Procedimento */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Diagnóstico / Procedimento
            </label>
            <input
              type="text"
              value={conditionTitle}
              onChange={(e) => setConditionTitle(e.target.value)}
              placeholder="Ex: Restauração em Resina Composta, Profilaxia, Canal..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          {/* Observações Clínicas da Dra. Pâmela */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Observações Clínicas da Dra. Pâmela
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Anotações técnicas, resina utilizada, testes de sensibilidade ou orientações para a próxima sessão..."
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
            />
          </div>

          {/* Action buttons (respecting iOS safe area) */}
          <div className="pt-2 pb-safe sm:pb-0 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 active:scale-95 transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 shadow-md shadow-teal-600/20 transition-all"
            >
              Salvar no Prontuário
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
