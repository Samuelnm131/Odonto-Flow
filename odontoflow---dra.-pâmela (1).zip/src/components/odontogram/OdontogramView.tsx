import React, { useState, useMemo } from 'react';
import {
  Stethoscope,
  User,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Ban,
  Share2,
  Copy,
  Info,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { ToothRecord, ToothStatus } from '../../types';
import { ToothModal } from './ToothModal';
import { FDI_TEETH_NAMES, buildWhatsAppUrl } from '../../utils/masks';

export const OdontogramView: React.FC = () => {
  const {
    patients,
    selectedPatientIdForOdontogram,
    setSelectedPatientIdForOdontogram,
    getPatientChart,
    updateToothRecord,
    showToast,
  } = useApp();

  const [selectedToothForModal, setSelectedToothForModal] = useState<number | null>(null);
  const [archFilter, setArchFilter] = useState<'ambas' | 'superior' | 'inferior'>('ambas');
  const [dentitionType, setDentitionType] = useState<'permanente' | 'deciduo'>('permanente');

  const selectedPatient = useMemo(() => {
    return patients.find((p) => p.id === selectedPatientIdForOdontogram) || patients[0];
  }, [patients, selectedPatientIdForOdontogram]);

  const chart = useMemo(() => {
    if (!selectedPatient) return {};
    return getPatientChart(selectedPatient.id);
  }, [selectedPatient, getPatientChart]);

  // Quadrants definition - Permanente (Adulto)
  const Q1 = [18, 17, 16, 15, 14, 13, 12, 11]; // Superior Direito
  const Q2 = [21, 22, 23, 24, 25, 26, 27, 28]; // Superior Esquerdo
  const Q4 = [48, 47, 46, 45, 44, 43, 42, 41]; // Inferior Direito
  const Q3 = [31, 32, 33, 34, 35, 36, 37, 38]; // Inferior Esquerdo

  // Quadrants definition - Decíduo (Infantil / Odontopediatria)
  const Q5 = [55, 54, 53, 52, 51]; // Superior Direito
  const Q6 = [61, 62, 63, 64, 65]; // Superior Esquerdo
  const Q8 = [85, 84, 83, 82, 81]; // Inferior Direito
  const Q7 = [71, 72, 73, 74, 75]; // Inferior Esquerdo

  const upperRight = dentitionType === 'permanente' ? Q1 : Q5;
  const upperLeft = dentitionType === 'permanente' ? Q2 : Q6;
  const lowerRight = dentitionType === 'permanente' ? Q4 : Q8;
  const lowerLeft = dentitionType === 'permanente' ? Q3 : Q7;

  // Stats calculation
  const stats = useMemo(() => {
    let higido = 0;
    let tratar = 0;
    let concluido = 0;
    let andamento = 0;
    let ausente = 0;

    const allTeeth = [...upperRight, ...upperLeft, ...lowerRight, ...lowerLeft];
    allTeeth.forEach((num) => {
      const record = chart[num];
      const st = record?.status || 'higido';
      if (st === 'higido') higido++;
      else if (st === 'tratamento_necessario') tratar++;
      else if (st === 'tratamento_concluido') concluido++;
      else if (st === 'em_andamento') andamento++;
      else if (st === 'ausente_extraido') ausente++;
    });

    return { higido, tratar, concluido, andamento, ausente, total: allTeeth.length };
  }, [chart, upperRight, upperLeft, lowerRight, lowerLeft]);

  const handleToothClick = (toothNumber: number) => {
    setSelectedToothForModal(toothNumber);
  };

  const handleSaveTooth = (
    toothNumber: number,
    record: Partial<ToothRecord>,
    addToBudget?: boolean
  ) => {
    if (selectedPatient) {
      updateToothRecord(selectedPatient.id, toothNumber, record, addToBudget);
    }
  };

  // WhatsApp share summary of dental status
  const handleShareSummary = () => {
    if (!selectedPatient) return;
    const treatments = Object.values(chart).filter(
      (t) => t.status === 'tratamento_necessario' || t.status === 'tratamento_concluido'
    );

    let text = `🦷 *Odontograma OdontoFlow - Dra. Pâmela*\n`;
    text += `*Paciente:* ${selectedPatient.name}\n`;
    text += `*Resumo:* ${stats.higido} Hígidos, ${stats.tratar} com Tratamento Necessário, ${stats.concluido} Tratados, ${stats.ausente} Ausentes.\n\n`;

    if (treatments.length > 0) {
      text += `*Detalhes dos Dentes:*\n`;
      treatments.forEach((t) => {
        const name = FDI_TEETH_NAMES[t.toothNumber] || `Dente ${t.toothNumber}`;
        const stLabel = t.status === 'tratamento_necessario' ? '⚠️ A Tratar' : '✅ Tratado';
        text += `• ${name} (${stLabel}): ${t.conditionTitle || 'Observação registrada'}\n`;
      });
    }

    window.open(buildWhatsAppUrl(selectedPatient.phone, text), '_blank');
  };

  const renderToothCard = (toothNumber: number) => {
    const record = chart[toothNumber];
    const status: ToothStatus = record?.status || 'higido';

    let bgStyle = 'bg-white border-slate-200 text-slate-800 hover:border-teal-400';
    let badgeColor = 'bg-slate-100 text-slate-600';
    let statusDot = 'bg-emerald-400';

    if (status === 'tratamento_necessario') {
      bgStyle = 'bg-rose-50/90 border-rose-300 text-rose-950 ring-1 ring-rose-400/30';
      badgeColor = 'bg-rose-600 text-white font-bold';
      statusDot = 'bg-rose-500';
    } else if (status === 'tratamento_concluido') {
      bgStyle = 'bg-teal-50/90 border-teal-300 text-teal-950 ring-1 ring-teal-400/30';
      badgeColor = 'bg-teal-600 text-white font-bold';
      statusDot = 'bg-teal-500';
    } else if (status === 'em_andamento') {
      bgStyle = 'bg-amber-50/90 border-amber-300 text-amber-950 ring-1 ring-amber-400/30';
      badgeColor = 'bg-amber-500 text-white font-bold';
      statusDot = 'bg-amber-500';
    } else if (status === 'ausente_extraido') {
      bgStyle = 'bg-slate-100 border-slate-300 text-slate-400 opacity-60 line-through';
      badgeColor = 'bg-slate-300 text-slate-700';
      statusDot = 'bg-slate-400';
    }

    return (
      <button
        key={toothNumber}
        type="button"
        onClick={() => handleToothClick(toothNumber)}
        className={`relative flex flex-col items-center justify-between p-2 rounded-2xl border transition-all duration-150 active:scale-95 text-center shadow-xs ${bgStyle}`}
      >
        {/* Status indicator dot */}
        <span className={`w-2 h-2 rounded-full absolute top-1.5 right-1.5 ${statusDot}`} />

        {/* FDI Tooth Number */}
        <span className="text-xs font-black tracking-tight">{toothNumber}</span>

        {/* Simplified Anatomical Tooth Graphic */}
        <div className="my-1 w-6 h-6 flex items-center justify-center">
          {status === 'ausente_extraido' ? (
            <Ban className="w-4 h-4 text-slate-400" />
          ) : status === 'tratamento_necessario' ? (
            <AlertTriangle className="w-4 h-4 text-rose-600 animate-pulse" />
          ) : status === 'tratamento_concluido' ? (
            <CheckCircle2 className="w-4 h-4 text-teal-600" />
          ) : status === 'em_andamento' ? (
            <Clock className="w-4 h-4 text-amber-600" />
          ) : (
            <ShieldCheck className="w-4 h-4 text-emerald-500/70" />
          )}
        </div>

        {/* Faces affected or condition tag */}
        {record?.facesAffected && record.facesAffected.length > 0 ? (
          <span className="text-[9px] font-black tracking-tighter text-teal-900 bg-teal-100/90 px-1 rounded">
            {record.facesAffected.join('')}
          </span>
        ) : (
          <span className="text-[9px] font-medium text-slate-400 truncate max-w-10">
            {status === 'higido' ? 'Hígido' : record?.conditionTitle ? record.conditionTitle.slice(0, 5) : 'Info'}
          </span>
        )}
      </button>
    );
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Top Bar with Patient Selector */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center">
              <Stethoscope className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 leading-tight">
                Odontograma FDI
              </h2>
              <p className="text-xs text-slate-500">Mapeamento da Arcada Dentária (11 a 48)</p>
            </div>
          </div>

          {selectedPatient && (
            <button
              onClick={handleShareSummary}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold active:scale-95 transition-all"
              title="Compartilhar resumo odontológico no WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">WhatsApp</span>
            </button>
          )}
        </div>

        {/* Patient Selection Dropdown & Dentition Switcher */}
        <div className="pt-1 space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Selecione o Paciente para Exame:
            </label>
            {/* Dentition Switcher */}
            <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-xl border border-slate-200 self-start sm:self-auto">
              <button
                type="button"
                onClick={() => setDentitionType('permanente')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  dentitionType === 'permanente'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Permanente (32)
              </button>
              <button
                type="button"
                onClick={() => setDentitionType('deciduo')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  dentitionType === 'deciduo'
                    ? 'bg-teal-700 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Decíduo Infantil (20)
              </button>
            </div>
          </div>

          <div className="relative">
            <select
              value={selectedPatient?.id || ''}
              onChange={(e) => setSelectedPatientIdForOdontogram(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-2xl border border-slate-300 bg-slate-50 text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.cpf ? `CPF: ${p.cpf}` : p.phone})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Stats Pill Indicators */}
        <div className="grid grid-cols-4 gap-2 pt-1 border-t border-slate-100">
          <div className="bg-emerald-50/80 p-2 rounded-xl text-center border border-emerald-100">
            <span className="text-xs font-black text-emerald-800 block">{stats.higido}</span>
            <span className="text-[10px] font-medium text-emerald-600">Hígidos</span>
          </div>

          <div className="bg-rose-50/80 p-2 rounded-xl text-center border border-rose-100">
            <span className="text-xs font-black text-rose-800 block">{stats.tratar}</span>
            <span className="text-[10px] font-medium text-rose-600">A Tratar</span>
          </div>

          <div className="bg-teal-50/80 p-2 rounded-xl text-center border border-teal-100">
            <span className="text-xs font-black text-teal-800 block">{stats.concluido}</span>
            <span className="text-[10px] font-medium text-teal-600">Tratados</span>
          </div>

          <div className="bg-slate-100 p-2 rounded-xl text-center border border-slate-200">
            <span className="text-xs font-black text-slate-700 block">{stats.ausente}</span>
            <span className="text-[10px] font-medium text-slate-500">Ausentes</span>
          </div>
        </div>
      </div>

      {/* View Mode Toggle: Ambas / Superior / Inferior */}
      <div className="flex items-center justify-between px-1">
        <span className="text-xs font-bold text-slate-700">Toque em qualquer dente para editar:</span>
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setArchFilter('ambas')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              archFilter === 'ambas' ? 'bg-white text-teal-800 shadow-xs' : 'text-slate-600'
            }`}
          >
            Todas
          </button>
          <button
            onClick={() => setArchFilter('superior')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              archFilter === 'superior' ? 'bg-white text-teal-800 shadow-xs' : 'text-slate-600'
            }`}
          >
            Superior
          </button>
          <button
            onClick={() => setArchFilter('inferior')}
            className={`px-2.5 py-1 rounded-lg transition-all ${
              archFilter === 'inferior' ? 'bg-white text-teal-800 shadow-xs' : 'text-slate-600'
            }`}
          >
            Inferior
          </button>
        </div>
      </div>

      {/* Interactive Dental Arches Container */}
      <div className="space-y-4">
        {/* ARCADA SUPERIOR */}
        {(archFilter === 'ambas' || archFilter === 'superior') && (
          <div className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-teal-600" />
                Arcada Superior {dentitionType === 'deciduo' ? '(Decídua / Infantil)' : ''}
              </span>
              <span className="text-[11px] text-slate-400">
                {dentitionType === 'permanente' ? 'Dentes 18 a 28' : 'Dentes 55 a 65'}
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase px-1">
                <span>{dentitionType === 'permanente' ? 'Direito (Q1)' : 'Direito (Q5)'}</span>
                <span>{dentitionType === 'permanente' ? 'Esquerdo (Q2)' : 'Esquerdo (Q6)'}</span>
              </div>

              {/* Grid of upper teeth */}
              <div
                className={`grid gap-1.5 ${
                  dentitionType === 'permanente'
                    ? 'grid-cols-8 sm:grid-cols-16'
                    : 'grid-cols-5 sm:grid-cols-10'
                }`}
              >
                {upperRight.map((num) => renderToothCard(num))}
                {upperLeft.map((num) => renderToothCard(num))}
              </div>
            </div>
          </div>
        )}

        {/* ARCADA INFERIOR */}
        {(archFilter === 'ambas' || archFilter === 'inferior') && (
          <div className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-teal-600" />
                Arcada Inferior {dentitionType === 'deciduo' ? '(Decídua / Infantil)' : ''}
              </span>
              <span className="text-[11px] text-slate-400">
                {dentitionType === 'permanente' ? 'Dentes 48 a 38' : 'Dentes 85 a 75'}
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase px-1">
                <span>{dentitionType === 'permanente' ? 'Direito (Q4)' : 'Direito (Q8)'}</span>
                <span>{dentitionType === 'permanente' ? 'Esquerdo (Q3)' : 'Esquerdo (Q7)'}</span>
              </div>

              {/* Grid of lower teeth */}
              <div
                className={`grid gap-1.5 ${
                  dentitionType === 'permanente'
                    ? 'grid-cols-8 sm:grid-cols-16'
                    : 'grid-cols-5 sm:grid-cols-10'
                }`}
              >
                {lowerRight.map((num) => renderToothCard(num))}
                {lowerLeft.map((num) => renderToothCard(num))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Clinical Notes & Legend of Odontogram */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-2 text-xs">
        <h4 className="font-bold text-slate-700 flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-teal-600" />
          Legenda de Cores do Odontograma:
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-slate-600">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500 shrink-0" />
            <span>Hígido (Saudável)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-rose-500 shrink-0" />
            <span>Tratamento Necessário</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-teal-500 shrink-0" />
            <span>Tratamento Concluído</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-slate-400 shrink-0" />
            <span>Ausente / Extraído</span>
          </div>
        </div>
      </div>

      {/* Tooth Modal */}
      <ToothModal
        isOpen={selectedToothForModal !== null}
        onClose={() => setSelectedToothForModal(null)}
        toothNumber={selectedToothForModal}
        currentRecord={selectedToothForModal ? chart[selectedToothForModal] : undefined}
        patientName={selectedPatient?.name || ''}
        onSave={handleSaveTooth}
      />
    </div>
  );
};
