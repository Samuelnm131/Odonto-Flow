import React, { useState, useEffect } from 'react';
import {
  X,
  FileText,
  FileCheck,
  Send,
  Printer,
  Copy,
  Plus,
  Trash2,
  AlertTriangle,
  Clock,
  Calendar,
  Sparkles,
  Search,
  CheckCircle2,
  ChevronRight,
  User,
  ShieldAlert,
  Eye,
  History,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  ClinicalDocument,
  PrescriptionDocument,
  CertificateDocument,
  PrescriptionMedicine,
  CertificateType,
} from '../../types';
import {
  MEDICATION_PRESETS,
  DENTAL_CID_LIST,
  MedicationPreset,
  getTodayString,
} from '../../data/mockData';
import {
  formatDateBR,
  buildWhatsAppUrl,
  formatPrescriptionWhatsAppMessage,
  formatCertificateWhatsAppMessage,
  hasCriticalClinicalAlert,
} from '../../utils/masks';
import { DocumentLetterhead } from './DocumentLetterhead';

export const DocumentsModal: React.FC = () => {
  const {
    patients,
    documents,
    isDocumentModalOpen,
    documentModalConfig,
    closeDocumentModal,
    addDocument,
    deleteDocument,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'receita' | 'atestado' | 'historico'>('receita');
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [showLetterheadPreview, setShowLetterheadPreview] = useState(false);
  const [previewDocument, setPreviewDocument] = useState<ClinicalDocument | null>(null);

  // Search filter for history tab
  const [historySearch, setHistorySearch] = useState('');
  const [historyTypeFilter, setHistoryTypeFilter] = useState<'todos' | 'receita' | 'atestado'>('todos');

  // RECEITA STATE
  const [medicines, setMedicines] = useState<PrescriptionMedicine[]>([]);
  const [customMedName, setCustomMedName] = useState('');
  const [customMedQty, setCustomMedQty] = useState('');
  const [customMedPosology, setCustomMedPosology] = useState('');
  const [customMedNotes, setCustomMedNotes] = useState('');
  const [generalInstructions, setGeneralInstructions] = useState(
    'Em caso de dor aguda persistente, hemorragia ou qualquer reação alérgica adversa, suspenda as medicações e faça contato imediato com a Dra. Pâmela.'
  );

  // ATESTADO STATE
  const [certificateType, setCertificateType] = useState<CertificateType>('comparecimento');
  const [certDate, setCertDate] = useState(getTodayString());
  const [certStartTime, setCertStartTime] = useState('09:00');
  const [certEndTime, setCertEndTime] = useState('10:30');
  const [certRestDays, setCertRestDays] = useState<number>(2);
  const [certStartDate, setCertStartDate] = useState(getTodayString());
  const [certCid, setCertCid] = useState('');
  const [certReason, setCertReason] = useState('Consulta e procedimento odontológico clínico.');
  const [certNotes, setCertNotes] = useState('');

  // Sync state whenever modal opens or documentModalConfig changes
  useEffect(() => {
    if (isDocumentModalOpen) {
      if (documentModalConfig.patientId) {
        setSelectedPatientId(documentModalConfig.patientId);
      } else if (!selectedPatientId && patients.length > 0) {
        setSelectedPatientId(patients[0].id);
      }

      if (documentModalConfig.initialType) {
        setActiveTab(documentModalConfig.initialType);
      }

      if (documentModalConfig.documentToView) {
        setPreviewDocument(documentModalConfig.documentToView);
        setShowLetterheadPreview(true);
      } else {
        setShowLetterheadPreview(false);
        setPreviewDocument(null);
      }
    }
  }, [isDocumentModalOpen, documentModalConfig]);

  if (!isDocumentModalOpen) return null;

  const currentPatient = patients.find((p) => p.id === selectedPatientId);
  const hasMedicalAlert = currentPatient ? hasCriticalClinicalAlert(currentPatient) : false;

  // Add medication from preset
  const handleAddPresetMedication = (preset: MedicationPreset) => {
    // Check if patient has allergy warning
    if (currentPatient && currentPatient.allergies.length > 0) {
      const allergyMatch = currentPatient.allergies.some((alg) =>
        preset.name.toLowerCase().includes(alg.toLowerCase())
      );
      if (allergyMatch) {
        showToast(
          `ALERTA: Paciente possui alergia registrada a ${preset.name}!`,
          'error'
        );
      }
    }

    const newMed: PrescriptionMedicine = {
      id: `med-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: preset.name,
      quantity: preset.quantity,
      posology: preset.posology,
      notes: preset.notes,
    };
    setMedicines((prev) => [...prev, newMed]);
  };

  // Add custom medication
  const handleAddCustomMedication = () => {
    if (!customMedName.trim() || !customMedPosology.trim()) {
      showToast('Informe o nome da medicação e a posologia.', 'error');
      return;
    }
    const newMed: PrescriptionMedicine = {
      id: `med-${Date.now()}`,
      name: customMedName.trim(),
      quantity: customMedQty.trim() || '1 unidade',
      posology: customMedPosology.trim(),
      notes: customMedNotes.trim() || undefined,
    };
    setMedicines((prev) => [...prev, newMed]);
    setCustomMedName('');
    setCustomMedQty('');
    setCustomMedPosology('');
    setCustomMedNotes('');
    showToast('Medicamento adicionado à prescrição!');
  };

  const handleRemoveMedicine = (id: string) => {
    setMedicines((prev) => prev.filter((m) => m.id !== id));
  };

  // Assemble current document object
  const buildCurrentPrescription = (): PrescriptionDocument | null => {
    if (!currentPatient) return null;
    return {
      id: `temp-${Date.now()}`,
      type: 'receita',
      patientId: currentPatient.id,
      patientName: currentPatient.name,
      patientCpf: currentPatient.cpf,
      patientPhone: currentPatient.phone,
      date: getTodayString(),
      medicines: medicines.length > 0 ? medicines : [
        {
          id: 'temp-1',
          name: 'Dipirona Sódica 500mg',
          quantity: '1 caixa (10 comprimidos)',
          posology: 'Tomar 1 comprimido via oral de 6 em 6 horas se houver dor.',
        },
      ],
      generalInstructions,
      createdAt: new Date().toISOString(),
    };
  };

  const buildCurrentCertificate = (): CertificateDocument | null => {
    if (!currentPatient) return null;
    return {
      id: `temp-${Date.now()}`,
      type: 'atestado',
      certificateType,
      patientId: currentPatient.id,
      patientName: currentPatient.name,
      patientCpf: currentPatient.cpf,
      patientPhone: currentPatient.phone,
      date: certDate,
      startTime: certificateType === 'comparecimento' ? certStartTime : undefined,
      endTime: certificateType === 'comparecimento' ? certEndTime : undefined,
      restDays: certificateType === 'repouso' ? certRestDays : undefined,
      startDate: certificateType === 'repouso' ? certStartDate : undefined,
      cid: certCid || undefined,
      reason: certReason || undefined,
      notes: certNotes || undefined,
      createdAt: new Date().toISOString(),
    };
  };

  // Save document to system
  const handleSaveDocument = () => {
    if (!currentPatient) {
      showToast('Selecione um paciente cadastrado.', 'error');
      return;
    }

    if (activeTab === 'receita') {
      if (medicines.length === 0) {
        showToast('Adicione ao menos um medicamento na prescrição.', 'error');
        return;
      }
      const saved = addDocument({
        type: 'receita',
        patientId: currentPatient.id,
        patientName: currentPatient.name,
        patientCpf: currentPatient.cpf,
        patientPhone: currentPatient.phone,
        date: getTodayString(),
        medicines,
        generalInstructions,
      });
      setPreviewDocument(saved);
      setShowLetterheadPreview(true);
    } else if (activeTab === 'atestado') {
      const saved = addDocument({
        type: 'atestado',
        certificateType,
        patientId: currentPatient.id,
        patientName: currentPatient.name,
        patientCpf: currentPatient.cpf,
        patientPhone: currentPatient.phone,
        date: certDate,
        startTime: certificateType === 'comparecimento' ? certStartTime : undefined,
        endTime: certificateType === 'comparecimento' ? certEndTime : undefined,
        restDays: certificateType === 'repouso' ? certRestDays : undefined,
        startDate: certificateType === 'repouso' ? certStartDate : undefined,
        cid: certCid || undefined,
        reason: certReason || undefined,
        notes: certNotes || undefined,
      });
      setPreviewDocument(saved);
      setShowLetterheadPreview(true);
    }
  };

  // WhatsApp share
  const handleShareWhatsApp = (targetDoc?: ClinicalDocument) => {
    const docToShare = targetDoc || previewDocument || (activeTab === 'receita' ? buildCurrentPrescription() : buildCurrentCertificate());
    if (!docToShare) {
      showToast('Nenhum documento disponível para envio.', 'error');
      return;
    }

    let text = '';
    if (docToShare.type === 'receita') {
      text = formatPrescriptionWhatsAppMessage(
        docToShare.patientName,
        docToShare.medicines,
        docToShare.date,
        docToShare.generalInstructions
      );
    } else {
      text = formatCertificateWhatsAppMessage({
        certificateType: docToShare.certificateType,
        patientName: docToShare.patientName,
        patientCpf: docToShare.patientCpf,
        date: docToShare.date,
        startTime: docToShare.startTime,
        endTime: docToShare.endTime,
        restDays: docToShare.restDays,
        startDate: docToShare.startDate,
        cid: docToShare.cid,
        reason: docToShare.reason,
        notes: docToShare.notes,
      });
    }

    const phone = docToShare.patientPhone || currentPatient?.phone || '';
    if (!phone) {
      showToast('Telefone do paciente não informado para envio.', 'error');
      return;
    }

    window.open(buildWhatsAppUrl(phone, text), '_blank');
    showToast('WhatsApp aberto com documento formatado!');
  };

  // Copy text to clipboard
  const handleCopyText = (targetDoc?: ClinicalDocument) => {
    const docToCopy = targetDoc || previewDocument || (activeTab === 'receita' ? buildCurrentPrescription() : buildCurrentCertificate());
    if (!docToCopy) return;

    let text = '';
    if (docToCopy.type === 'receita') {
      text = formatPrescriptionWhatsAppMessage(
        docToCopy.patientName,
        docToCopy.medicines,
        docToCopy.date,
        docToCopy.generalInstructions
      );
    } else {
      text = formatCertificateWhatsAppMessage({
        certificateType: docToCopy.certificateType,
        patientName: docToCopy.patientName,
        patientCpf: docToCopy.patientCpf,
        date: docToCopy.date,
        startTime: docToCopy.startTime,
        endTime: docToCopy.endTime,
        restDays: docToCopy.restDays,
        startDate: docToCopy.startDate,
        cid: docToCopy.cid,
        reason: docToCopy.reason,
        notes: docToCopy.notes,
      });
    }

    navigator.clipboard.writeText(text);
    showToast('Texto do documento copiado para a área de transferência!');
  };

  // Trigger browser print
  const handlePrint = (targetDoc?: ClinicalDocument) => {
    if (targetDoc) {
      setPreviewDocument(targetDoc);
    } else if (!previewDocument) {
      const current = activeTab === 'receita' ? buildCurrentPrescription() : buildCurrentCertificate();
      setPreviewDocument(current);
    }
    setShowLetterheadPreview(true);
    setTimeout(() => {
      window.print();
    }, 200);
  };

  // Filtered documents for history
  const filteredHistory = documents.filter((doc) => {
    if (historyTypeFilter !== 'todos' && doc.type !== historyTypeFilter) return false;
    if (historySearch.trim()) {
      const q = historySearch.toLowerCase();
      return (
        doc.patientName.toLowerCase().includes(q) ||
        (doc.patientCpf && doc.patientCpf.includes(q))
      );
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-3xl max-h-[96vh] sm:max-h-[90vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 bg-slate-50/90 flex items-center justify-between no-print">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-700 to-teal-500 text-white flex items-center justify-center shadow-sm">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-base font-bold text-slate-900 leading-tight">
                  Documentos Clínicos
                </h3>
                <span className="text-[10px] font-black uppercase tracking-wider text-teal-800 bg-teal-100 px-1.5 py-0.2 rounded-md">
                  Dra. Pâmela
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Receituários, prescrições e atestados com validade odontológica
              </p>
            </div>
          </div>

          <button
            onClick={closeDocumentModal}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher (Receita vs Atestado vs Histórico) */}
        <div className="px-5 pt-3 pb-2 border-b border-slate-100 bg-white no-print">
          <div className="grid grid-cols-3 p-1 bg-slate-100/90 rounded-2xl text-xs font-bold text-slate-600">
            <button
              onClick={() => {
                setActiveTab('receita');
                setShowLetterheadPreview(false);
              }}
              className={`py-2 px-2 rounded-xl text-center flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'receita'
                  ? 'bg-white text-teal-800 shadow-xs font-black'
                  : 'hover:text-slate-900'
              }`}
            >
              <FileText className="w-4 h-4 text-teal-600" />
              <span>Receituário</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('atestado');
                setShowLetterheadPreview(false);
              }}
              className={`py-2 px-2 rounded-xl text-center flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'atestado'
                  ? 'bg-white text-teal-800 shadow-xs font-black'
                  : 'hover:text-slate-900'
              }`}
            >
              <FileCheck className="w-4 h-4 text-teal-600" />
              <span>Atestado</span>
            </button>
            <button
              onClick={() => {
                setActiveTab('historico');
                setShowLetterheadPreview(false);
              }}
              className={`py-2 px-2 rounded-xl text-center flex items-center justify-center gap-1.5 transition-all ${
                activeTab === 'historico'
                  ? 'bg-white text-teal-800 shadow-xs font-black'
                  : 'hover:text-slate-900'
              }`}
            >
              <History className="w-4 h-4 text-teal-600" />
              <span>Histórico ({documents.length})</span>
            </button>
          </div>
        </div>

        {/* Patient Selection Bar (when in generation mode) */}
        {activeTab !== 'historico' && !showLetterheadPreview && (
          <div className="px-5 py-3 bg-teal-50/50 border-b border-teal-100/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 no-print">
            <div className="flex-1 flex items-center gap-2">
              <User className="w-4 h-4 text-teal-700 shrink-0" />
              <label className="text-xs font-bold text-teal-900 shrink-0">
                Paciente:
              </label>
              <select
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="w-full text-xs font-bold text-slate-800 bg-white border border-teal-200 rounded-xl px-2.5 py-1.5 focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} {p.cpf ? `(${p.cpf})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Medical Alert Warning Pill */}
            {hasMedicalAlert && currentPatient && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-rose-100 text-rose-800 text-[11px] font-bold border border-rose-200 animate-in fade-in">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                <span>
                  {currentPatient.allergies.length > 0
                    ? `Alergia: ${currentPatient.allergies.join(', ')}`
                    : 'Atenção: Risco sistêmico'}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">

          {/* LETTERHEAD PREVIEW SCREEN */}
          {showLetterheadPreview && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between bg-slate-100 p-2.5 rounded-2xl border border-slate-200 text-xs no-print">
                <span className="font-bold text-slate-700 flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-teal-600" />
                  Visualização do Documento Timbrado Oficial
                </span>
                <button
                  onClick={() => setShowLetterheadPreview(false)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 hover:bg-slate-50 font-bold text-slate-700 text-[11px] transition-all"
                >
                  Voltar à edição
                </button>
              </div>

              {/* Render Letterhead */}
              {previewDocument ? (
                <DocumentLetterhead document={previewDocument} />
              ) : activeTab === 'receita' ? (
                <DocumentLetterhead document={buildCurrentPrescription()!} />
              ) : (
                <DocumentLetterhead document={buildCurrentCertificate()!} />
              )}
            </div>
          )}

          {/* TAB 1: RECEITUÁRIO GENERATOR */}
          {activeTab === 'receita' && !showLetterheadPreview && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Presets Quick-Add Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                    Medicamentos Comuns (Toque para adicionar)
                  </span>
                  <span className="text-[10px] text-slate-400">Sugestões OdontoFlow</span>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {MEDICATION_PRESETS.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => handleAddPresetMedication(preset)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-teal-50 hover:text-teal-800 hover:border-teal-300 border border-slate-200/80 text-[11px] font-bold text-slate-700 active:scale-95 transition-all"
                    >
                      <Plus className="w-3 h-3 text-teal-600" />
                      <span>{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Prescribed Items List */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-800 uppercase tracking-wider">
                    Itens da Prescrição ({medicines.length})
                  </span>
                  {medicines.length > 0 && (
                    <button
                      onClick={() => setMedicines([])}
                      className="text-[10px] font-bold text-rose-600 hover:underline"
                    >
                      Limpar lista
                    </button>
                  )}
                </div>

                {medicines.length === 0 ? (
                  <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50/50">
                    <FileText className="w-8 h-8 text-slate-300 mx-auto mb-1.5" />
                    <p className="text-xs font-bold text-slate-600">
                      Nenhum medicamento adicionado ainda
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Selecione uma sugestão acima ou preencha os campos abaixo para prescrever.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {medicines.map((med, idx) => (
                      <div
                        key={med.id}
                        className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-start justify-between gap-2.5 group hover:border-teal-300 transition-all"
                      >
                        <div className="flex-1 space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-teal-600 text-white text-[11px] font-black flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <span className="text-xs font-extrabold text-slate-900">
                              {med.name}
                            </span>
                            <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.2 rounded-md border border-teal-200">
                              {med.quantity}
                            </span>
                          </div>
                          <p className="text-xs text-slate-700 font-medium pl-7">
                            <strong className="text-slate-800">Posologia: </strong>
                            {med.posology}
                          </p>
                          {med.notes && (
                            <p className="text-[11px] text-slate-500 italic pl-7">
                              Obs: {med.notes}
                            </p>
                          )}
                        </div>
                        <button
                          onClick={() => handleRemoveMedicine(med.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Remover medicamento"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Form to add custom medicine */}
              <div className="p-3.5 rounded-2xl bg-slate-50/80 border border-slate-200/90 space-y-2.5">
                <span className="text-xs font-bold text-slate-700 block">
                  + Adicionar Outro Medicamento
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div className="sm:col-span-2">
                    <input
                      type="text"
                      placeholder="Nome do medicamento e dosagem (Ex: Paracetamol 750mg)"
                      value={customMedName}
                      onChange={(e) => setCustomMedName(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 font-medium"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Quantidade (Ex: 1 caixa)"
                      value={customMedQty}
                      onChange={(e) => setCustomMedQty(e.target.value)}
                      className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 font-medium"
                    />
                  </div>
                </div>
                <div>
                  <textarea
                    rows={2}
                    placeholder="Posologia detalhada (Ex: Tomar 1 comprimido de 8 em 8 horas por 5 dias)"
                    value={customMedPosology}
                    onChange={(e) => setCustomMedPosology(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 font-medium"
                  />
                </div>
                <div className="flex items-center justify-between gap-2">
                  <input
                    type="text"
                    placeholder="Orientações adicionais (Opcional - Ex: Ingerir após as refeições)"
                    value={customMedNotes}
                    onChange={(e) => setCustomMedNotes(e.target.value)}
                    className="flex-1 text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 font-medium"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomMedication}
                    className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all shrink-0"
                  >
                    Adicionar
                  </button>
                </div>
              </div>

              {/* General Instructions Textarea */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">
                  Orientações Clínicas Gerais
                </label>
                <textarea
                  rows={2}
                  value={generalInstructions}
                  onChange={(e) => setGeneralInstructions(e.target.value)}
                  className="w-full text-xs p-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 font-medium leading-relaxed"
                />
              </div>
            </div>
          )}

          {/* TAB 2: ATESTADO GENERATOR */}
          {activeTab === 'atestado' && !showLetterheadPreview && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Type Toggle: Comparecimento vs Repouso */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">
                  Tipo de Atestado Odontológico
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCertificateType('comparecimento')}
                    className={`py-2.5 px-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                      certificateType === 'comparecimento'
                        ? 'bg-teal-50 border-teal-500 text-teal-800 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Clock className="w-4 h-4 text-teal-600" />
                    <span>Comparecimento (Horários)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCertificateType('repouso')}
                    className={`py-2.5 px-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all ${
                      certificateType === 'repouso'
                        ? 'bg-teal-50 border-teal-500 text-teal-800 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Calendar className="w-4 h-4 text-teal-600" />
                    <span>Repouso (X Dias)</span>
                  </button>
                </div>
              </div>

              {/* Specific fields depending on certificateType */}
              {certificateType === 'comparecimento' ? (
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                  <span className="text-xs font-black text-slate-800 uppercase tracking-wider block">
                    Horário da Consulta
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <div>
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Data do Atendimento
                      </label>
                      <input
                        type="date"
                        value={certDate}
                        onChange={(e) => setCertDate(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Horário de Início
                      </label>
                      <input
                        type="time"
                        value={certStartTime}
                        onChange={(e) => setCertStartTime(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Horário de Término
                      </label>
                      <input
                        type="time"
                        value={certEndTime}
                        onChange={(e) => setCertEndTime(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                  <span className="text-xs font-black text-slate-800 uppercase tracking-wider block">
                    Período de Afastamento / Repouso
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Data Inicial do Repouso
                      </label>
                      <input
                        type="date"
                        value={certStartDate}
                        onChange={(e) => setCertStartDate(e.target.value)}
                        className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-600 block mb-1">
                        Dias de Afastamento
                      </label>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min={1}
                          max={30}
                          value={certRestDays}
                          onChange={(e) => setCertRestDays(Number(e.target.value) || 1)}
                          className="w-20 text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-center"
                        />
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 5, 7].map((days) => (
                            <button
                              key={days}
                              type="button"
                              onClick={() => setCertRestDays(days)}
                              className={`px-2 py-1.5 rounded-lg text-[11px] font-bold border transition-all ${
                                certRestDays === days
                                  ? 'bg-teal-600 text-white border-teal-600'
                                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                              }`}
                            >
                              {days}d
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* CID-10 Quick Select & Input */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700">
                    Código CID-10 (Opcional)
                  </label>
                  <span className="text-[10px] text-slate-400">Padrão odontológico</span>
                </div>

                <select
                  value={certCid}
                  onChange={(e) => setCertCid(e.target.value)}
                  className="w-full text-xs font-medium text-slate-800 bg-white border border-slate-200 rounded-xl px-3 py-2 focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                >
                  <option value="">Selecione um CID-10 pré-cadastrado ou digite abaixo</option>
                  {DENTAL_CID_LIST.map((cid) => (
                    <option key={cid.code} value={`${cid.code} - ${cid.description}`}>
                      {cid.code} - {cid.description}
                    </option>
                  ))}
                </select>

                <div className="flex flex-wrap gap-1">
                  {DENTAL_CID_LIST.slice(0, 5).map((cid) => (
                    <button
                      key={cid.code}
                      type="button"
                      onClick={() => setCertCid(`${cid.code} - ${cid.description}`)}
                      className="px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-slate-100 hover:bg-teal-50 text-slate-700 border border-slate-200/80"
                    >
                      {cid.code}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reason / Procedimento */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">
                  Motivo / Procedimento Odontológico
                </label>
                <input
                  type="text"
                  value={certReason}
                  onChange={(e) => setCertReason(e.target.value)}
                  placeholder="Ex: Procedimento cirúrgico odontológico (Exodontia de 3º Molar)"
                  className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>

              {/* Observações Complementares */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">
                  Observações Complementares (Opcional)
                </label>
                <input
                  type="text"
                  value={certNotes}
                  onChange={(e) => setCertNotes(e.target.value)}
                  placeholder="Ex: Justificativa para período matutino ou restrição física temporária"
                  className="w-full text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                />
              </div>
            </div>
          )}

          {/* TAB 3: HISTÓRICO DE DOCUMENTOS EMITIDOS */}
          {activeTab === 'historico' && !showLetterheadPreview && (
            <div className="space-y-3 animate-in fade-in duration-150">
              {/* Search and filters */}
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Buscar histórico por paciente ou CPF..."
                    value={historySearch}
                    onChange={(e) => setHistorySearch(e.target.value)}
                    className="w-full text-xs pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:bg-white"
                  />
                </div>
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl shrink-0 text-xs font-bold">
                  {(['todos', 'receita', 'atestado'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setHistoryTypeFilter(filter)}
                      className={`px-2.5 py-1 rounded-lg capitalize transition-all ${
                        historyTypeFilter === filter
                          ? 'bg-white text-teal-800 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {filter === 'todos' ? 'Todos' : filter === 'receita' ? 'Receitas' : 'Atestados'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Documents List */}
              {filteredHistory.length === 0 ? (
                <div className="p-8 text-center border border-dashed border-slate-200 rounded-2xl bg-slate-50/50">
                  <History className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-600">
                    Nenhum documento encontrado no histórico
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Emita uma receita ou atestado nas abas anteriores para registrar.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredHistory.map((doc) => {
                    const isRx = doc.type === 'receita';
                    const rx = isRx ? (doc as PrescriptionDocument) : null;
                    const cert = !isRx ? (doc as CertificateDocument) : null;

                    return (
                      <div
                        key={doc.id}
                        className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs hover:border-teal-400 transition-all space-y-2"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span
                              className={`p-2 rounded-xl text-xs font-black ${
                                isRx
                                  ? 'bg-teal-50 text-teal-800 border border-teal-200'
                                  : 'bg-sky-50 text-sky-800 border border-sky-200'
                              }`}
                            >
                              {isRx ? <FileText className="w-4 h-4" /> : <FileCheck className="w-4 h-4" />}
                            </span>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <h4 className="text-xs font-black text-slate-900">
                                  {doc.patientName}
                                </h4>
                                <span
                                  className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded-md ${
                                    isRx ? 'bg-teal-100 text-teal-800' : 'bg-sky-100 text-sky-800'
                                  }`}
                                >
                                  {isRx ? 'Receituário' : 'Atestado'}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500">
                                {formatDateBR(doc.date)}
                                {doc.patientCpf ? ` • CPF: ${doc.patientCpf}` : ''}
                              </p>
                            </div>
                          </div>

                          {/* Quick Actions */}
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => {
                                setPreviewDocument(doc);
                                setShowLetterheadPreview(true);
                              }}
                              className="p-1.5 rounded-lg text-slate-600 hover:text-teal-700 hover:bg-teal-50"
                              title="Visualizar Timbrado"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handlePrint(doc)}
                              className="p-1.5 rounded-lg text-slate-600 hover:text-teal-700 hover:bg-teal-50"
                              title="Imprimir"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleShareWhatsApp(doc)}
                              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50"
                              title="Enviar no WhatsApp"
                            >
                              <Send className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => deleteDocument(doc.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                              title="Excluir do histórico"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {/* Summary details */}
                        <div className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-xl">
                          {isRx && rx && (
                            <p>
                              <strong>Medicamentos ({rx.medicines.length}): </strong>
                              {rx.medicines.map((m) => m.name).join(', ')}
                            </p>
                          )}
                          {!isRx && cert && (
                            <p>
                              <strong>
                                {cert.certificateType === 'comparecimento'
                                  ? 'Comparecimento:'
                                  : `Repouso (${cert.restDays || 1} dias):`}
                              </strong>{' '}
                              {cert.reason || cert.cid || 'Atendimento odontológico'}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Action Footer (Buttons bar) */}
        <div className="p-4 border-t border-slate-100 bg-white no-print pb-safe">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              {/* Quick WhatsApp Share */}
              <button
                type="button"
                onClick={() => handleShareWhatsApp()}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
                title="Formatar e disparar no WhatsApp"
              >
                <Send className="w-3.5 h-3.5 fill-white/20" />
                <span>WhatsApp</span>
              </button>

              {/* Copy Text */}
              <button
                type="button"
                onClick={() => handleCopyText()}
                className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold active:scale-95 transition-all"
                title="Copiar texto formatado"
              >
                <Copy className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Copiar</span>
              </button>

              {/* Print / PDF */}
              <button
                type="button"
                onClick={() => handlePrint()}
                className="inline-flex items-center gap-1 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold active:scale-95 transition-all"
                title="Imprimir documento em papel timbrado"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Imprimir</span>
              </button>
            </div>

            {/* Primary Action Button */}
            {activeTab !== 'historico' ? (
              <div className="flex items-center gap-2">
                {!showLetterheadPreview && (
                  <button
                    type="button"
                    onClick={() => {
                      const doc = activeTab === 'receita' ? buildCurrentPrescription() : buildCurrentCertificate();
                      setPreviewDocument(doc);
                      setShowLetterheadPreview(true);
                    }}
                    className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold active:scale-95 transition-all"
                  >
                    Visualizar
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleSaveDocument}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white text-xs font-black shadow-md shadow-teal-700/20 active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4 text-teal-200" />
                  <span>Salvar Documento</span>
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={closeDocumentModal}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold transition-all"
              >
                Fechar
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
