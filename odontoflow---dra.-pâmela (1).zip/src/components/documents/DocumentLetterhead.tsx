import React from 'react';
import { ClinicalDocument, PrescriptionDocument, CertificateDocument } from '../../types';
import { formatDateBR, formatDateFullBR } from '../../utils/masks';
import { Sparkles, ShieldCheck } from 'lucide-react';

interface DocumentLetterheadProps {
  document: ClinicalDocument;
  clinicAddress?: string;
  clinicPhone?: string;
  city?: string;
}

export const DocumentLetterhead: React.FC<DocumentLetterheadProps> = ({
  document,
  clinicAddress = 'Av. Paulista, 1500 - Bela Vista, São Paulo - SP',
  clinicPhone = '(11) 98765-4321',
  city = 'São Paulo - SP',
}) => {
  const isPrescription = document.type === 'receita';
  const prescription = isPrescription ? (document as PrescriptionDocument) : null;
  const certificate = !isPrescription ? (document as CertificateDocument) : null;

  return (
    <div className="printable-document bg-white text-slate-900 font-sans p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm max-w-2xl mx-auto flex flex-col justify-between min-h-[620px]">
      {/* Clinic Header / Timbrado */}
      <div className="border-b-2 border-teal-600 pb-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white flex items-center justify-center font-extrabold text-lg shadow-sm">
              DP
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">
                  OdontoFlow
                </h2>
                <span className="text-[11px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200">
                  Odontologia Especializada
                </span>
              </div>
              <p className="text-xs font-bold text-slate-800 mt-0.5">
                Dra. Pâmela Meneghetti
              </p>
              <p className="text-[11px] font-semibold text-slate-500">
                Cirurgiã-Dentista • CRO 24.891
              </p>
            </div>
          </div>

          <div className="text-right text-[11px] text-slate-500 hidden sm:block">
            <p className="font-semibold text-slate-700">{clinicAddress}</p>
            <p>WhatsApp / Tel: {clinicPhone}</p>
            <p className="text-teal-700 font-semibold">Atendimento com hora marcada</p>
          </div>
        </div>
      </div>

      {/* Document Subheader / Patient Information */}
      <div className="my-5 p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div>
          <span className="text-slate-400 font-medium">Paciente: </span>
          <span className="font-bold text-slate-900 text-sm">{document.patientName}</span>
          {document.patientCpf && (
            <span className="ml-2 text-slate-500">
              • CPF: <strong className="text-slate-700">{document.patientCpf}</strong>
            </span>
          )}
        </div>
        <div className="text-slate-500 font-medium">
          Emissão: <strong className="text-slate-800">{formatDateBR(document.date)}</strong>
        </div>
      </div>

      {/* DOCUMENT BODY CONTENT */}
      <div className="flex-1 space-y-5 my-2">
        {isPrescription && prescription && (
          <div className="space-y-4">
            <div className="text-center py-1 border-b border-dashed border-slate-200">
              <h3 className="text-sm font-black tracking-widest text-teal-900 uppercase">
                Receituário Odontológico
              </h3>
              <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mt-0.5">
                Uso Oral / Tópico
              </p>
            </div>

            {/* Medicines List */}
            <div className="space-y-3.5 divide-y divide-slate-100">
              {prescription.medicines.map((med, index) => (
                <div key={med.id || index} className="pt-2.5 first:pt-0">
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-sm font-bold text-slate-900">
                      {index + 1}. {med.name}
                    </span>
                    <span className="text-xs font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-100">
                      Qtd: {med.quantity}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 font-medium mt-1 pl-4 border-l-2 border-teal-500/40">
                    <span className="font-bold text-slate-800">Posologia: </span>
                    {med.posology}
                  </p>
                  {med.notes && (
                    <p className="text-[11px] text-slate-500 mt-1 pl-4 italic">
                      Observação: {med.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>

            {/* General Instructions */}
            {prescription.generalInstructions && (
              <div className="mt-4 p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 text-xs">
                <span className="font-bold text-amber-900 block mb-0.5">
                  Orientações Clínicas Importantes:
                </span>
                <p className="text-amber-800 font-medium leading-relaxed">
                  {prescription.generalInstructions}
                </p>
              </div>
            )}
          </div>
        )}

        {!isPrescription && certificate && (
          <div className="space-y-5">
            <div className="text-center py-1 border-b border-dashed border-slate-200">
              <h3 className="text-sm font-black tracking-widest text-teal-900 uppercase">
                {certificate.certificateType === 'comparecimento'
                  ? 'Atestado de Comparecimento Odontológico'
                  : 'Atestado Odontológico de Repouso'}
              </h3>
            </div>

            {/* Formal Certificate Text */}
            <div className="text-sm text-slate-800 font-medium leading-relaxed text-justify px-2 space-y-4">
              {certificate.certificateType === 'comparecimento' ? (
                <p>
                  Atesto para os devidos fins que o(a) Sr.(a){' '}
                  <strong className="text-slate-900 underline underline-offset-2">
                    {certificate.patientName}
                  </strong>
                  {certificate.patientCpf ? `, portador(a) do CPF ${certificate.patientCpf}` : ''},
                  esteve sob meus cuidados profissionais no dia{' '}
                  <strong className="text-slate-900">
                    {formatDateFullBR(certificate.date)}
                  </strong>
                  {certificate.startTime && certificate.endTime ? (
                    <>
                      , no período das{' '}
                      <strong className="text-slate-900">{certificate.startTime}</strong> às{' '}
                      <strong className="text-slate-900">{certificate.endTime}</strong>
                    </>
                  ) : (
                    ' em atendimento odontológico'
                  )}
                  , impossibilitando sua presença em suas atividades habituais durante este horário.
                </p>
              ) : (
                <p>
                  Atesto para os devidos fins de justificativa legal que o(a) Sr.(a){' '}
                  <strong className="text-slate-900 underline underline-offset-2">
                    {certificate.patientName}
                  </strong>
                  {certificate.patientCpf ? `, portador(a) do CPF ${certificate.patientCpf}` : ''},
                  foi submetido(a) a procedimento odontológico e necessita de{' '}
                  <strong className="text-slate-900 text-base">
                    {certificate.restDays || 1}{' '}
                    {(certificate.restDays || 1) === 1 ? 'dia' : 'dias'}
                  </strong>{' '}
                  de repouso e afastamento de suas atividades profissionais e rotineiras a contar do dia{' '}
                  <strong className="text-slate-900">
                    {formatDateFullBR(certificate.startDate || certificate.date)}
                  </strong>
                  , para recuperação clínica pós-operatória.
                </p>
              )}

              {certificate.reason && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-xs">
                  <span className="font-bold text-slate-700">Procedimento / Motivo: </span>
                  <span className="text-slate-900 font-semibold">{certificate.reason}</span>
                </div>
              )}

              {certificate.cid && (
                <div className="p-2.5 bg-slate-100/70 rounded-xl border border-slate-200 text-xs flex items-center justify-between">
                  <span className="font-bold text-slate-700">Código CID-10:</span>
                  <span className="font-bold text-slate-900">{certificate.cid}</span>
                </div>
              )}

              {certificate.notes && (
                <p className="text-xs text-slate-600 italic">
                  Observações complementares: {certificate.notes}
                </p>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Signature and Location Footer */}
      <div className="mt-8 pt-4 border-t border-slate-200">
        <div className="flex flex-col sm:flex-row items-center sm:items-end justify-between gap-6">
          <div className="text-center sm:text-left text-xs text-slate-500">
            <p>
              {city}, {formatDateFullBR(document.date)}.
            </p>
            <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 justify-center sm:justify-start">
              <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
              Documento emitido via OdontoFlow Cloud • Dra. Pâmela
            </p>
          </div>

          <div className="text-center">
            {/* Signature Graphic Line */}
            <div className="w-56 border-b-2 border-slate-700 pb-1 mx-auto flex flex-col items-center">
              <span className="font-serif italic text-teal-800 text-sm opacity-90 select-none">
                Dra. Pâmela Meneghetti
              </span>
            </div>
            <p className="text-xs font-bold text-slate-900 mt-1">
              Dra. Pâmela Meneghetti
            </p>
            <p className="text-[11px] font-semibold text-slate-600">
              Cirurgiã-Dentista • CRO 24.891
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
