import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Clock,
  Users,
  FileText,
  MessageCircle,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  Plus,
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  Stethoscope,
  DollarSign,
  Database,
  FileCheck,
  RotateCcw,
  Cake,
  Gift,
  CalendarHeart,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { getTodayString } from '../../data/mockData';
import { buildWhatsAppUrl, formatDateBR, hasCriticalClinicalAlert } from '../../utils/masks';
import { Appointment, AppointmentStatus } from '../../types';

export const DashboardView: React.FC = () => {
  const {
    patients,
    appointments,
    budgets,
    documents,
    setActiveTab,
    openPatientModal,
    openAppointmentModal,
    setIsNewBudgetOpen,
    setIsBackupModalOpen,
    openDocumentModal,
    updateAppointmentStatus,
    openOdontogramForPatient,
    openGeminiChat,
  } = useApp();

  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('todos');

  const todayStr = getTodayString();
  const todayAppointments = appointments.filter((apt) => apt.date === todayStr);

  // Calculate metrics
  const totalToday = todayAppointments.length;
  const waitingCount = todayAppointments.filter(
    (apt) => apt.status === 'agendado' || apt.status === 'confirmado'
  ).length;
  const completedTodayCount = todayAppointments.filter((apt) => apt.status === 'concluido').length;
  const pendingBudgetsCount = budgets.filter((b) => b.status === 'pendente').length;
  const approvedBudgetsTotal = budgets
    .filter((b) => b.status === 'aprovado' || b.status === 'pago')
    .reduce((acc, b) => acc + b.totalValue, 0);

  // Determine greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  // Find clinical health alerts for patients scheduled today
  const todayPatientIds = Array.from(new Set(todayAppointments.map((a) => a.patientId)));
  const todayAlerts = patients
    .filter(
      (p) =>
        todayPatientIds.includes(p.id) &&
        (p.allergies.length > 0 || p.medicalAlerts.length > 0)
    )
    .map((p) => ({
      patientName: p.name,
      patientId: p.id,
      allergies: p.allergies,
      alerts: p.medicalAlerts,
    }));

  const filteredTodayAppointments = todayAppointments.filter((apt) => {
    if (selectedStatusFilter === 'todos') return true;
    return apt.status === selectedStatusFilter;
  });

  const getStatusBadge = (status: AppointmentStatus) => {
    switch (status) {
      case 'confirmado':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Confirmado
          </span>
        );
      case 'concluido':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-teal-100 text-teal-800">
            <CheckCircle2 className="w-3 h-3 text-teal-600" />
            Concluído
          </span>
        );
      case 'cancelado':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-100 text-rose-800">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            Cancelado
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-sky-100 text-sky-800">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
            Agendado
          </span>
        );
    }
  };

  const [relationshipTab, setRelationshipTab] = useState<'recall' | 'aniversarios'>('recall');

  // Compute Recall Preventivo (Pacientes sem consulta há 180+ dias / 6 meses)
  const recallList = useMemo(() => {
    const todayTime = new Date().setHours(0, 0, 0, 0);

    return patients
      .map((patient) => {
        const patientApts = appointments.filter((a) => a.patientId === patient.id && a.status !== 'cancelado');

        // Se já tiver consulta agendada para hoje ou futuro, não precisa de recall
        const hasUpcomingAppointment = patientApts.some((a) => {
          const aptDate = new Date(`${a.date}T00:00:00`).getTime();
          return aptDate >= todayTime && (a.status === 'agendado' || a.status === 'confirmado');
        });

        if (hasUpcomingAppointment) return null;

        // Histórico de atendimentos passados
        const pastApts = patientApts
          .filter((a) => {
            const aptDate = new Date(`${a.date}T00:00:00`).getTime();
            return aptDate < todayTime || a.status === 'concluido';
          })
          .sort((a, b) => new Date(`${b.date}T00:00:00`).getTime() - new Date(`${a.date}T00:00:00`).getTime());

        const lastApt = pastApts[0];
        let lastDateObj: Date;

        if (lastApt) {
          lastDateObj = new Date(`${lastApt.date}T00:00:00`);
        } else if (patient.createdAt) {
          lastDateObj = new Date(`${patient.createdAt}T00:00:00`);
        } else {
          return null;
        }

        const diffTime = todayTime - lastDateObj.getTime();
        const daysSince = Math.floor(diffTime / (1000 * 60 * 60 * 24));

        if (daysSince >= 180) {
          const monthsSince = Math.floor(daysSince / 30);
          return {
            patient,
            lastAppointment: lastApt,
            daysSinceLastVisit: daysSince,
            monthsSinceLastVisit: monthsSince,
            lastDateFormatted: formatDateBR(lastApt?.date || patient.createdAt),
          };
        }
        return null;
      })
      .filter((item): item is NonNullable<typeof item> => item !== null)
      .sort((a, b) => b.daysSinceLastVisit - a.daysSinceLastVisit);
  }, [patients, appointments]);

  // Compute Aniversariantes do Mês
  const birthdayList = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1; // 1-12
    const currentDay = now.getDate();

    return patients
      .map((patient) => {
        if (!patient.birthDate) return null;

        let bYear = 1990;
        let bMonth = 1;
        let bDay = 1;

        if (patient.birthDate.includes('-')) {
          const parts = patient.birthDate.split('-');
          bYear = parseInt(parts[0], 10);
          bMonth = parseInt(parts[1], 10);
          bDay = parseInt(parts[2], 10);
        } else if (patient.birthDate.includes('/')) {
          const parts = patient.birthDate.split('/');
          bDay = parseInt(parts[0], 10);
          bMonth = parseInt(parts[1], 10);
          bYear = parseInt(parts[2], 10);
        } else {
          return null;
        }

        if (isNaN(bMonth) || isNaN(bDay)) return null;

        const isCurrentMonth = bMonth === currentMonth;
        const isToday = bMonth === currentMonth && bDay === currentDay;
        const isTomorrow = bMonth === currentMonth && bDay === currentDay + 1;
        const turningAge = currentYear - bYear;

        if (!isCurrentMonth) return null;

        return {
          patient,
          bDay,
          bMonth,
          turningAge,
          isToday,
          isTomorrow,
          formattedDayMonth: `${String(bDay).padStart(2, '0')}/${String(bMonth).padStart(2, '0')}`,
        };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null)
      .sort((a, b) => {
        if (a.isToday) return -1;
        if (b.isToday) return 1;
        if (a.isTomorrow) return -1;
        if (b.isTomorrow) return 1;
        return a.bDay - b.bDay;
      });
  }, [patients]);

  const handleOpenWhatsApp = (apt: Appointment) => {
    const text = `Olá ${apt.patientName}, tudo bem? Aqui é da clínica da Dra. Pâmela. Confirmando sua consulta de ${apt.procedure} hoje às ${apt.time}. Podemos contar com sua presença?`;
    window.open(buildWhatsAppUrl(apt.patientPhone, text), '_blank');
  };

  const handleRecallWhatsApp = (item: (typeof recallList)[0]) => {
    const lastProc = item.lastAppointment?.procedure ? ` após ${item.lastAppointment.procedure}` : '';
    const text = `Olá ${item.patient.name}, tudo bem? Aqui é da clínica da Dra. Pâmela.\n\nNotamos que faz cerca de ${item.monthsSinceLastVisit} meses desde seu último atendimento${lastProc}. O acompanhamento semestral e a limpeza preventiva (profilaxia) são fundamentais para manter seus dentes e gengivas saudáveis e prevenir cáries e inflamações.\n\nPodemos agendar sua revisão preventiva esta semana? 😊`;
    window.open(buildWhatsAppUrl(item.patient.phone, text), '_blank');
  };

  const handleBirthdayWhatsApp = (item: (typeof birthdayList)[0]) => {
    const text = `Olá ${item.patient.name}, parabéns pelo seu aniversário! 🎉🎂\n\nToda a equipe do consultório da Dra. Pâmela deseja a você muita saúde, paz, realizações e muitos sorrisos iluminados neste novo ciclo! Conte sempre conosco para cuidar do seu sorriso com muito carinho. Tenha um dia maravilhoso! ✨`;
    window.open(buildWhatsAppUrl(item.patient.phone, text), '_blank');
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-teal-700 via-teal-800 to-slate-900 p-5 text-white shadow-xl shadow-teal-900/10">
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-teal-400/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-emerald-400/15 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-white/15 backdrop-blur-md text-teal-100 border border-white/10">
              <Sparkles className="w-3 h-3 text-teal-300" />
              Clínica OdontoFlow
            </span>
            <span className="text-xs text-teal-200/90 font-medium">
              {new Date().toLocaleDateString('pt-BR', {
                weekday: 'short',
                day: '2-digit',
                month: 'short',
              })}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
            {getGreeting()}, <span className="text-teal-200">Dra. Pâmela!</span> 👋
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-teal-100/90 font-normal">
            Você tem <strong className="text-white font-semibold">{waitingCount} {waitingCount === 1 ? 'paciente' : 'pacientes'}</strong> na agenda de hoje, <strong className="text-white font-semibold">{recallList.length} retornos preventivos</strong> pendentes e <strong className="text-white font-semibold">{pendingBudgetsCount} orçamentos</strong> em negociação.
          </p>

          {/* Quick Action Buttons inside hero */}
          <div className="mt-4 flex flex-wrap gap-2 pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={() => openAppointmentModal()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white text-teal-900 hover:bg-teal-50 active:scale-95 transition-all shadow-sm"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              Novo Agendamento
            </button>
            <button
              type="button"
              onClick={() => openPatientModal()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/20 hover:bg-white/30 text-white backdrop-blur-xs active:scale-95 transition-all"
            >
              <Users className="w-3.5 h-3.5" />
              Novo Paciente
            </button>
            <button
              type="button"
              onClick={() => openGeminiChat()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-amber-400/25 to-teal-300/25 hover:from-amber-400/35 hover:to-teal-300/35 text-white border border-amber-300/40 backdrop-blur-xs active:scale-95 transition-all shadow-xs"
              title="Abrir Assistente Clínico & Gestão Inteligente Dra. Pâmela"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-200" />
              <span>IA Gemini</span>
            </button>
            <button
              onClick={() => setRelationshipTab('recall')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-amber-400/25 hover:bg-amber-400/35 text-amber-100 border border-amber-300/30 active:scale-95 transition-all"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Recall ({recallList.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('finance')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-500/30 hover:bg-emerald-500/40 text-emerald-100 border border-emerald-300/30 active:scale-95 transition-all"
            >
              <TrendingUp className="w-3.5 h-3.5" />
              Financeiro
            </button>
            <button
              onClick={() => openDocumentModal()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-white/20 hover:bg-white/30 text-white backdrop-blur-xs active:scale-95 transition-all"
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span>Receitas & Atestados ({documents.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('odontogram')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-teal-500/30 hover:bg-teal-500/40 text-teal-100 border border-teal-300/30 active:scale-95 transition-all"
            >
              <Stethoscope className="w-3.5 h-3.5" />
              Odontograma
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row (3 Main Cards Required by Prompt) */}
      <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
        {/* Card 1: Consultas Hoje */}
        <div
          onClick={() => setActiveTab('schedule')}
          className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-teal-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-xl bg-teal-50 flex items-center justify-center text-teal-700">
              <Calendar className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded-md">
              {completedTodayCount}/{totalToday}
            </span>
          </div>
          <div className="mt-2">
            <p className="text-xl sm:text-2xl font-black text-slate-900 leading-none">
              {totalToday}
            </p>
            <p className="text-[11px] font-medium text-slate-500 mt-1 line-clamp-1">
              Consultas Hoje
            </p>
          </div>
        </div>

        {/* Card 2: Pacientes Aguardando */}
        <div
          onClick={() => setActiveTab('schedule')}
          className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-sky-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-xl bg-sky-50 flex items-center justify-center text-sky-700">
              <Clock className="w-4 h-4" />
            </div>
            <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse" />
          </div>
          <div className="mt-2">
            <p className="text-xl sm:text-2xl font-black text-slate-900 leading-none">
              {waitingCount}
            </p>
            <p className="text-[11px] font-medium text-slate-500 mt-1 line-clamp-1">
              Aguardando
            </p>
          </div>
        </div>

        {/* Card 3: Orçamentos Pendentes (Clickable to Finance module) */}
        <div
          onClick={() => setActiveTab('finance')}
          className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-amber-300 transition-all cursor-pointer group"
          title="Ver Relatórios Financeiros e Orçamentos"
        >
          <div className="flex items-center justify-between">
            <div className="w-7 h-7 rounded-xl bg-amber-50 flex items-center justify-center text-amber-700">
              <FileText className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded-md">
              {pendingBudgetsCount}
            </span>
          </div>
          <div className="mt-2">
            <p className="text-xl sm:text-2xl font-black text-slate-900 leading-none">
              {pendingBudgetsCount}
            </p>
            <p className="text-[11px] font-medium text-slate-500 mt-1 line-clamp-1 group-hover:text-amber-700 transition-colors">
              Orçamentos Pend.
            </p>
          </div>
        </div>
      </div>

      {/* Clinical Health Warnings of the Day */}
      {todayAlerts.length > 0 && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50/80 p-3.5 text-amber-900 shadow-xs">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
              Atenção Clínica • Alertas dos Pacientes de Hoje
            </h4>
          </div>
          <div className="space-y-1.5">
            {todayAlerts.map((alert, idx) => (
              <div
                key={idx}
                className="flex items-start justify-between text-xs bg-white/80 p-2 rounded-xl border border-amber-200/60"
              >
                <div>
                  <span className="font-bold text-slate-900">{alert.patientName}:</span>
                  {alert.allergies.length > 0 && (
                    <span className="ml-1 text-rose-700 font-semibold">
                      Alérgico a {alert.allergies.join(', ')}
                    </span>
                  )}
                  {alert.alerts.length > 0 && (
                    <span className="ml-1 text-amber-800">
                      • {alert.alerts.join(', ')}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => openOdontogramForPatient(alert.patientId)}
                  className="text-[10px] font-bold text-teal-700 hover:underline shrink-0 ml-2"
                >
                  Odontograma
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Section: Próximos Atendimentos de Hoje */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Próximos Atendimentos
            </h3>
            <p className="text-xs text-slate-500">Consultas de hoje ({formatDateBR(todayStr)})</p>
          </div>

          <button
            onClick={() => setActiveTab('schedule')}
            className="flex items-center gap-0.5 text-xs font-semibold text-teal-700 hover:text-teal-800"
          >
            <span>Ver Agenda Completa</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {todayAppointments.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center">
            <div className="w-12 h-12 rounded-full bg-teal-50 text-teal-600 flex items-center justify-center mx-auto mb-3">
              <Calendar className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800">Nenhuma consulta agendada para hoje</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              Aproveite para organizar a clínica ou agendar retornos e avaliações.
            </p>
            <button
              type="button"
              onClick={() => openAppointmentModal()}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-teal-600 text-white hover:bg-teal-700 shadow-sm transition-all"
            >
              <Plus className="w-4 h-4" />
              Agendar Nova Consulta
            </button>
          </div>
        ) : (
          <div className="space-y-2.5">
            {todayAppointments.map((apt) => (
              <div
                key={apt.id}
                className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all flex flex-col gap-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-3">
                    {/* Time Pill */}
                    <div className="flex flex-col items-center justify-center px-2.5 py-1.5 rounded-xl bg-slate-100 text-slate-800 border border-slate-200/60 shrink-0">
                      <Clock className="w-3.5 h-3.5 text-teal-600 mb-0.5" />
                      <span className="text-xs font-extrabold">{apt.time}</span>
                      <span className="text-[9px] text-slate-500 font-medium">{apt.durationMinutes}m</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="text-sm font-bold text-slate-900">{apt.patientName}</h4>
                        {(() => {
                          const p = patients.find((pat) => pat.id === apt.patientId);
                          if (p && hasCriticalClinicalAlert(p)) {
                            return (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase bg-rose-600 text-white shadow-xs">
                                <AlertTriangle className="w-2.5 h-2.5" />
                                Alerta Clínico
                              </span>
                            );
                          }
                          return null;
                        })()}
                      </div>
                      <p className="text-xs font-medium text-teal-700 mt-0.5">{apt.procedure}</p>
                      {apt.notes && (
                        <p className="text-[11px] text-slate-500 mt-1 line-clamp-1 italic">
                          "{apt.notes}"
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="shrink-0">
                    {getStatusBadge(apt.status)}
                  </div>
                </div>

                {/* Card Action Shortcuts: WhatsApp + Status Fast Toggles */}
                <div className="flex items-center justify-between pt-2.5 border-t border-slate-100 gap-2">
                  {/* WhatsApp Direct Action Button */}
                  <button
                    onClick={() => handleOpenWhatsApp(apt)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200/70 text-xs font-semibold active:scale-95 transition-all"
                    title="Abrir WhatsApp do paciente com mensagem pré-preenchida"
                  >
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" />
                    <span>WhatsApp</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {apt.status !== 'concluido' && (
                      <button
                        onClick={() => updateAppointmentStatus(apt.id, 'concluido')}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200 text-xs font-medium active:scale-95 transition-all"
                        title="Marcar como Concluído"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                        <span>Concluir</span>
                      </button>
                    )}

                    {apt.status === 'agendado' && (
                      <button
                        onClick={() => updateAppointmentStatus(apt.id, 'confirmado')}
                        className="px-2.5 py-1.5 rounded-xl bg-sky-50 text-sky-800 hover:bg-sky-100 border border-sky-200 text-xs font-medium active:scale-95 transition-all"
                        title="Confirmar Presença"
                      >
                        Confirmar
                      </button>
                    )}

                    <button
                      onClick={() => openOdontogramForPatient(apt.patientId)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-teal-700 hover:bg-slate-100 transition-colors"
                      title="Abrir Odontograma do Paciente"
                    >
                      <Stethoscope className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Prevenção Clínica & Fidelização de Pacientes (Recall & Aniversariantes) */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-5 shadow-xs space-y-4">
        {/* Section Header & Tab Switcher */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center border border-teal-100/80">
                <RotateCcw className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  Prevenção & Fidelização
                  <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-800 border border-teal-200/60">
                    Atendimento Ativo
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Gestão ativa de retorno preventivo semestral e carinho com aniversariantes
                </p>
              </div>
            </div>
          </div>

          {/* Segmented Tab Buttons */}
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl self-start sm:self-auto border border-slate-200/60">
            <button
              onClick={() => setRelationshipTab('recall')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                relationshipTab === 'recall'
                  ? 'bg-white text-teal-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5 text-teal-600" />
              <span>Recall Preventivo</span>
              {recallList.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-100 text-amber-800">
                  {recallList.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setRelationshipTab('aniversarios')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                relationshipTab === 'aniversarios'
                  ? 'bg-white text-teal-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Cake className="w-3.5 h-3.5 text-rose-500" />
              <span>Aniversariantes</span>
              {birthdayList.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-rose-100 text-rose-800">
                  {birthdayList.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Tab 1: Recall Preventivo */}
        {relationshipTab === 'recall' && (
          <div className="space-y-3">
            <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-3 flex items-start gap-2.5 text-xs text-amber-900">
              <CalendarHeart className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>Protocolo Preventivo (180 dias):</strong> Pacientes cuja última consulta foi há 6 meses ou mais sem retorno agendado. O envio do convite pelo WhatsApp estimula o cuidado bucal contínuo e aumenta a fidelização da clínica.
              </div>
            </div>

            {recallList.length === 0 ? (
              <div className="py-6 text-center text-slate-500 text-xs bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="font-semibold text-slate-700">Parabéns! Todos os pacientes estão com consultas em dia.</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Nenhum retorno semestral pendente sem agendamento no momento.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {recallList.map((item) => (
                  <div
                    key={item.patient.id}
                    className="p-3.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between gap-3 shadow-2xs"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">{item.patient.name}</h4>
                          <p className="text-[11px] text-slate-500">{item.patient.phone}</p>
                        </div>
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-900 border border-amber-200/60">
                          <RotateCcw className="w-2.5 h-2.5 text-amber-700" />
                          Há {item.monthsSinceLastVisit} meses ({item.daysSinceLastVisit}d)
                        </span>
                      </div>

                      <div className="mt-2.5 text-xs text-slate-600 bg-white p-2 rounded-xl border border-slate-200/70">
                        {item.lastAppointment ? (
                          <>
                            <span className="font-semibold text-slate-800">Último procedimento:</span>{' '}
                            <span className="text-teal-800 font-medium">{item.lastAppointment.procedure}</span>{' '}
                            <span className="text-[10px] text-slate-400">({item.lastDateFormatted})</span>
                          </>
                        ) : (
                          <>
                            <span className="font-semibold text-slate-800">Cadastro inicial:</span>{' '}
                            {item.lastDateFormatted} (sem retorno posterior)
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2.5 border-t border-slate-200/60">
                      <button
                        onClick={() => handleRecallWhatsApp(item)}
                        className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all"
                        title="Convidar paciente pelo WhatsApp para profilaxia preventiva"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Convidar no WhatsApp</span>
                      </button>

                      <button
                        onClick={() => openAppointmentModal(undefined, undefined, item.patient.id)}
                        className="px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 active:scale-95 text-teal-800 text-xs font-bold border border-teal-200/80 transition-all"
                        title="Agendar consulta de retorno"
                      >
                        Agendar
                      </button>

                      <button
                        onClick={() => openOdontogramForPatient(item.patient.id)}
                        className="p-1.5 rounded-xl text-slate-400 hover:text-teal-700 hover:bg-slate-200/60 transition-colors"
                        title="Abrir Odontograma"
                      >
                        <Stethoscope className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Aniversariantes do Mês */}
        {relationshipTab === 'aniversarios' && (
          <div className="space-y-3">
            <div className="bg-rose-50/70 border border-rose-200/80 rounded-2xl p-3 flex items-start gap-2.5 text-xs text-rose-900">
              <Gift className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="leading-relaxed">
                <strong>Aniversariantes do Mês ({new Date().toLocaleDateString('pt-BR', { month: 'long' })}):</strong> Envie mensagens carinhosas no WhatsApp para demonstrar cuidado e fortalecer o relacionamento com seus pacientes.
              </div>
            </div>

            {birthdayList.length === 0 ? (
              <div className="py-6 text-center text-slate-500 text-xs bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                <Cake className="w-8 h-8 text-rose-300 mx-auto mb-2" />
                <p className="font-semibold text-slate-700">Nenhum aniversariante neste mês.</p>
                <p className="text-[11px] text-slate-400 mt-0.5">À medida que novos pacientes forem cadastrados, eles aparecerão aqui automaticamente.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {birthdayList.map((item) => (
                  <div
                    key={item.patient.id}
                    className="p-3.5 rounded-2xl border border-slate-200/80 bg-slate-50/60 hover:bg-white hover:border-slate-300 transition-all flex flex-col justify-between gap-3 shadow-2xs"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="text-sm font-bold text-slate-900">{item.patient.name}</h4>
                            {item.isToday && (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[9px] font-black bg-rose-600 text-white animate-pulse">
                                🎉 Hoje!
                              </span>
                            )}
                            {item.isTomorrow && (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[9px] font-black bg-amber-500 text-white">
                                🎂 Amanhã
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500">{item.patient.phone}</p>
                        </div>

                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-extrabold bg-rose-100 text-rose-800 border border-rose-200/60 shrink-0">
                          <Cake className="w-3.5 h-3.5 text-rose-600" />
                          Dia {item.formattedDayMonth}
                        </span>
                      </div>

                      <p className="mt-2 text-xs text-slate-600 bg-white p-2 rounded-xl border border-slate-200/70">
                        🎂 <strong>Completando {item.turningAge} anos</strong> •{' '}
                        <span className="text-slate-500">{item.patient.profession || 'Paciente cadastrado'}</span>
                      </p>
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-2.5 border-t border-slate-200/60">
                      <button
                        onClick={() => handleBirthdayWhatsApp(item)}
                        className="flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all"
                        title="Enviar mensagem carinhosa de aniversário no WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Enviar Parabéns (WhatsApp)</span>
                      </button>

                      <button
                        onClick={() => openAppointmentModal(undefined, undefined, item.patient.id)}
                        className="px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 active:scale-95 text-teal-800 text-xs font-bold border border-teal-200/80 transition-all"
                        title="Agendar consulta de presente"
                      >
                        Agendar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Quick Financial Overview Card */}
      <div className="rounded-3xl bg-gradient-to-r from-teal-900 to-slate-900 p-4 text-white shadow-lg flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 flex items-center justify-center shrink-0 border border-teal-500/30">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold">Relatórios & Faturamento</h4>
            <p className="text-xs text-slate-400">
              {budgets.filter((b) => b.status === 'aprovado' || b.status === 'pago').length} orçamentos aprovados • Gráficos mensais
            </p>
          </div>
        </div>
        <button
          onClick={() => setActiveTab('finance')}
          className="flex items-center gap-1 px-3 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 active:scale-95 text-xs font-semibold text-white transition-all shrink-0"
        >
          <span>Visualizar</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Quick Security & Backup Access */}
      <div className="rounded-2xl bg-white border border-slate-200/90 p-3.5 shadow-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0 border border-teal-100">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-800">Segurança & Cópia dos Prontuários</h4>
            <p className="text-[11px] text-slate-500">
              Exportar ou restaurar arquivo .json de pacientes e atendimentos
            </p>
          </div>
        </div>
        <button
          onClick={() => setIsBackupModalOpen(true)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 font-bold active:scale-95 text-xs border border-teal-200/70 transition-all shrink-0"
        >
          <span>Backup</span>
        </button>
      </div>
    </div>
  );
};
