import React from 'react';
import { LayoutDashboard, Users, CalendarDays, Activity, TrendingUp } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { getTodayString } from '../../data/mockData';

export const BottomNavigation: React.FC = () => {
  const { activeTab, setActiveTab, appointments, budgets } = useApp();

  const todayStr = getTodayString();
  const todayPendingAppointments = appointments.filter(
    (apt) => apt.date === todayStr && apt.status !== 'concluido' && apt.status !== 'cancelado'
  ).length;

  const pendingBudgetsCount = budgets.filter((b) => b.status === 'pendente').length;

  const handleTabClick = (tab: 'dashboard' | 'patients' | 'schedule' | 'odontogram' | 'finance') => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(10);
      } catch {
        // Safe fallback
      }
    }
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navItems = [
    {
      id: 'dashboard' as const,
      label: 'Início',
      icon: LayoutDashboard,
      badge: 0,
    },
    {
      id: 'patients' as const,
      label: 'Pacientes',
      icon: Users,
      badge: 0,
    },
    {
      id: 'schedule' as const,
      label: 'Agenda',
      icon: CalendarDays,
      badge: todayPendingAppointments,
    },
    {
      id: 'odontogram' as const,
      label: 'Odonto.',
      icon: Activity,
      badge: 0,
    },
    {
      id: 'finance' as const,
      label: 'Financeiro',
      icon: TrendingUp,
      badge: pendingBudgetsCount,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 glass-nav border-t border-slate-200/90 pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.04)]">
      <div className="max-w-md mx-auto px-2 h-15 flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;

          return (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`relative flex flex-col items-center justify-center flex-1 py-1 transition-all duration-200 active:scale-90 ${
                isActive ? 'text-teal-700' : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <div className="relative">
                {/* Active indicator dot or pill */}
                {isActive && (
                  <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-5 h-1 bg-teal-600 rounded-full animate-in fade-in zoom-in-75 duration-200" />
                )}
                <div
                  className={`p-1 rounded-xl transition-all ${
                    isActive ? 'bg-teal-50 text-teal-700 scale-105' : ''
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[2]'}`} />
                </div>

                {/* Badge for notifications */}
                {item.badge > 0 && (
                  <span className="absolute -top-1 -right-2 px-1 min-w-3.5 h-3.5 rounded-full bg-teal-600 text-[9px] font-bold text-white flex items-center justify-center border-2 border-white shadow-xs">
                    {item.badge}
                  </span>
                )}
              </div>

              <span
                className={`text-[10px] sm:text-[11px] mt-0.5 tracking-tight transition-colors ${
                  isActive ? 'font-extrabold text-teal-800' : 'font-semibold text-slate-600'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
