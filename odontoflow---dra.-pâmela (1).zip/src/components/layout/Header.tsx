import React from 'react';
import { Sparkles, Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { OfflineIndicator } from '../pwa/OfflineIndicator';
import { AuthHeaderButton } from '../auth/AuthHeaderButton';

export const Header: React.FC = () => {
  const { openAppointmentModal, openGeminiChat } = useApp();

  return (
    <header className="sticky top-0 z-30 w-full glass-nav border-b border-slate-200/80 transition-all">
      <OfflineIndicator />
      <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between">
        {/* Brand & Dra. Pâmela Identity */}
        <div className="flex items-center gap-2.5">
          <div className="relative">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-teal-700 via-teal-600 to-teal-500 flex items-center justify-center text-white shadow-xs ring-1 ring-white">
              <span className="font-extrabold text-xs tracking-wider">DP</span>
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white" title="Pronta para atendimento" />
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold text-slate-900 leading-tight">OdontoFlow</h1>
              <span className="inline-flex items-center px-1.5 py-0.2 text-[9px] font-bold text-teal-800 bg-teal-100 rounded-md">
                PRO
              </span>
            </div>
            <p className="text-[11px] font-medium text-slate-500 leading-none mt-0.5">
              Dra. Pâmela <span className="text-teal-600 font-semibold">• Dentista</span>
            </p>
          </div>
        </div>

        {/* Clean, Focused Action Controls (Only 3 balanced elements) */}
        <div className="flex items-center gap-2">
          {/* 1. Gemini AI Assistant Button */}
          <button
            onClick={() => openGeminiChat()}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-teal-500/10 to-indigo-500/10 hover:from-teal-500/20 hover:to-indigo-500/20 text-teal-900 border border-teal-200/90 font-semibold text-xs transition-all active:scale-95 shadow-2xs group"
            title="Abrir Assistente Inteligente Dra. Pâmela (Gemini)"
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-600 group-hover:rotate-12 transition-transform duration-300" />
            <span className="hidden xs:inline">IA Odonto</span>
          </button>

          {/* 2. Fast Primary Action: + Consulta */}
          <button
            type="button"
            onClick={() => openAppointmentModal()}
            className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 rounded-xl shadow-xs transition-all"
            title="Agendar Nova Consulta"
            aria-label="Nova Consulta"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Consulta</span>
          </button>

          {/* 3. Unified Clinic & Google Account Menu */}
          <AuthHeaderButton />
        </div>
      </div>
    </header>
  );
};
