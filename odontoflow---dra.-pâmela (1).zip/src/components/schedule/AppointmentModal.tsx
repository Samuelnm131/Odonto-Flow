import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, Stethoscope, FileText } from 'lucide-react';
import { Appointment, AppointmentStatus } from '../../types';
import { useApp } from '../../context/AppContext';
import { COMMON_PROCEDURES } from '../../utils/masks';
import { getTodayString } from '../../data/mockData';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Appointment, 'id'>) => void;
  initialData?: Appointment | null;
  defaultDate?: string;
  defaultPatientId?: string | null;
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
  defaultDate,
  defaultPatientId,
}) => {
  const { patients, openPatientModal } = useApp();

  const [patientId, setPatientId] = useState('');
  const [date, setDate] = useState(defaultDate || getTodayString());
  const [time, setTime] = useState('09:00');
  const [durationMinutes, setDurationMinutes] = useState(45);
  const [procedure, setProcedure] = useState(COMMON_PROCEDURES[0]);
  const [customProcedure, setCustomProcedure] = useState('');
  const [status, setStatus] = useState<AppointmentStatus>('agendado');
  const [notes, setNotes] = useState('');
  const [estimatedPrice, setEstimatedPrice] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (initialData) {
      setPatientId(initialData.patientId);
      setDate(initialData.date);
      setTime(initialData.time);
      setDurationMinutes(initialData.durationMinutes);
      if (COMMON_PROCEDURES.includes(initialData.procedure)) {
        setProcedure(initialData.procedure);
        setCustomProcedure('');
      } else {
        setProcedure('Outro');
        setCustomProcedure(initialData.procedure);
      }
      setStatus(initialData.status);
      setNotes(initialData.notes || '');
      setEstimatedPrice(initialData.estimatedPrice ? String(initialData.estimatedPrice) : '');
    } else {
      setPatientId(defaultPatientId || (patients[0]?.id ?? ''));
      setDate(defaultDate || getTodayString());
      setTime('09:00');
      setDurationMinutes(45);
      setProcedure(COMMON_PROCEDURES[0]);
      setCustomProcedure('');
      setStatus('agendado');
      setNotes('');
      setEstimatedPrice('');
    }
    setError('');
  }, [initialData, defaultDate, defaultPatientId, isOpen, patients]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientId) {
      setError('Por favor, selecione um paciente para agendar.');
      return;
    }

    const selectedPatient = patients.find((p) => p.id === patientId);
    if (!selectedPatient) {
      setError('Paciente não encontrado.');
      return;
    }

    const finalProcedure = procedure === 'Outro' ? customProcedure.trim() || 'Procedimento Clínico' : procedure;

    onSave({
      patientId,
      patientName: selectedPatient.name,
      patientPhone: selectedPatient.phone,
      date,
      time,
      durationMinutes: Number(durationMinutes),
      procedure: finalProcedure,
      status,
      notes: notes.trim(),
      estimatedPrice: estimatedPrice ? Number(estimatedPrice) : undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-lg max-h-[92vh] sm:max-h-[88vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                {initialData ? 'Editar Consulta' : 'Nova Consulta Odontológica'}
              </h3>
              <p className="text-xs text-slate-500">Agenda da Dra. Pâmela</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-700">
              {error}
            </div>
          )}

          {/* Selecionar Paciente */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Paciente *
              </label>
              <button
                type="button"
                onClick={() => openPatientModal()}
                className="text-xs text-teal-700 font-semibold hover:underline"
              >
                + Cadastrar Novo
              </button>
            </div>
            <select
              value={patientId}
              onChange={(e) => setPatientId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="" disabled>Selecione um paciente...</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.phone})
                </option>
              ))}
            </select>
          </div>

          {/* Data e Horário */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Data *
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Horário *
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                required
              />
            </div>
          </div>

          {/* Duração & Procedimento */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Duração Estimada
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[15, 30, 45, 60].map((mins) => (
                <button
                  type="button"
                  key={mins}
                  onClick={() => setDurationMinutes(mins)}
                  className={`py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    durationMinutes === mins
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {mins} min
                </button>
              ))}
            </div>
          </div>

          {/* Procedimento */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Procedimento Odontológico *
            </label>
            <select
              value={procedure}
              onChange={(e) => setProcedure(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 mb-2"
            >
              {COMMON_PROCEDURES.map((proc) => (
                <option key={proc} value={proc}>
                  {proc}
                </option>
              ))}
              <option value="Outro">Outro Procedimento...</option>
            </select>

            {procedure === 'Outro' && (
              <input
                type="text"
                value={customProcedure}
                onChange={(e) => setCustomProcedure(e.target.value)}
                placeholder="Digite o procedimento..."
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            )}
          </div>

          {/* Status Inicial */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Status da Consulta
            </label>
            <div className="grid grid-cols-4 gap-2">
              {(['agendado', 'confirmado', 'concluido', 'cancelado'] as AppointmentStatus[]).map(
                (st) => {
                  const labels = {
                    agendado: 'Agendado',
                    confirmado: 'Confirmado',
                    concluido: 'Concluído',
                    cancelado: 'Cancelado',
                  };
                  return (
                    <button
                      type="button"
                      key={st}
                      onClick={() => setStatus(st)}
                      className={`py-1.5 rounded-xl text-[11px] font-semibold capitalize transition-all ${
                        status === st
                          ? 'bg-teal-700 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {labels[st]}
                    </button>
                  );
                }
              )}
            </div>
          </div>

          {/* Observações / Notas Clínicas */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Observações da Consulta
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Ex: dente 16, paciente prefere anestesia tópica reforçada..."
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
            />
          </div>

          {/* Actions (pb-safe for iPhone) */}
          <div className="pt-2 pb-safe sm:pb-0 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 active:scale-95 transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 shadow-md shadow-teal-600/20 transition-all"
            >
              {initialData ? 'Atualizar Consulta' : 'Confirmar Agendamento'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
