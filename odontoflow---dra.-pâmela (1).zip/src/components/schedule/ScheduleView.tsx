import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  MessageCircle,
  CheckCircle2,
  AlertCircle,
  Filter,
  MoreVertical,
  Trash2,
  Edit2,
  Stethoscope,
  AlertTriangle,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Appointment, AppointmentStatus } from '../../types';
import { getTodayString } from '../../data/mockData';
import { formatDateBR, buildWhatsAppUrl, hasCriticalClinicalAlert } from '../../utils/masks';

export const ScheduleView: React.FC = () => {
  const {
    patients,
    appointments,
    updateAppointmentStatus,
    deleteAppointment,
    openAppointmentModal,
    openOdontogramForPatient,
  } = useApp();

  const [selectedDate, setSelectedDate] = useState<string>(getTodayString());
  const [statusFilter, setStatusFilter] = useState<string>('todos');

  // Generate 14-day date pills centered around today or selectedDate
  const datePills = useMemo(() => {
    const pills = [];
    for (let i = -3; i <= 6; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];
      const count = appointments.filter((a) => a.date === dateStr).length;
      pills.push({
        dateStr,
        dayName: d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''),
        dayNumber: d.getDate(),
        monthName: d.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', ''),
        isToday: dateStr === getTodayString(),
        count,
      });
    }
    return pills;
  }, [appointments]);

  // Appointments for selected date
  const dayAppointments = useMemo(() => {
    return appointments
      .filter((apt) => apt.date === selectedDate)
      .filter((apt) => (statusFilter === 'todos' ? true : apt.status === statusFilter))
      .sort((a, b) => a.time.localeCompare(b.time));
  }, [appointments, selectedDate, statusFilter]);

  const handleOpenWhatsApp = (apt: Appointment) => {
    const text = `Olá ${apt.patientName}! Passando para confirmar sua consulta odontológica com a Dra. Pâmela agendada para ${formatDateBR(apt.date)} às ${apt.time} (${apt.procedure}). Qualquer dúvida estamos à disposição!`;
    window.open(buildWhatsAppUrl(apt.patientPhone, text), '_blank');
  };

  const handleEdit = (apt: Appointment) => {
    openAppointmentModal(apt, apt.date);
  };

  const handleDelete = (apt: Appointment) => {
    if (confirm(`Deseja cancelar e remover a consulta de ${apt.patientName}?`)) {
      deleteAppointment(apt.id);
    }
  };

  const getStatusColor = (status: AppointmentStatus) => {
    switch (status) {
      case 'confirmado':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'concluido':
        return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'cancelado':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      default:
        return 'bg-sky-100 text-sky-800 border-sky-200';
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Schedule Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Agenda Clínica</h2>
          <p className="text-xs text-slate-500">
            {formatDateBR(selectedDate)} • {dayAppointments.length} atendimentos
          </p>
        </div>

        <button
          type="button"
          onClick={() => openAppointmentModal(undefined, selectedDate)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold shadow-md shadow-teal-600/20 transition-all"
        >
          <Plus className="w-4 h-4 stroke-[2.3]" />
          <span>Nova Consulta</span>
        </button>
      </div>

      {/* Date Carousel Bar */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between px-2 pb-2 mb-1 border-b border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 font-bold text-slate-800">
            <CalendarIcon className="w-3.5 h-3.5 text-teal-600" />
            <span>
              {new Date(selectedDate + 'T00:00:00').toLocaleDateString('pt-BR', {
                month: 'long',
                year: 'numeric',
              })}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setSelectedDate(getTodayString())}
              className="px-2 py-0.5 rounded-lg text-[10px] font-bold text-teal-700 bg-teal-50 hover:bg-teal-100 transition-colors"
            >
              Hoje
            </button>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => e.target.value && setSelectedDate(e.target.value)}
              className="text-xs p-1 rounded-md border border-slate-200 text-slate-700 bg-slate-50 focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
        </div>

        {/* Scrollable Day Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 px-1 no-scrollbar">
          {datePills.map((pill) => {
            const isSelected = pill.dateStr === selectedDate;
            return (
              <button
                key={pill.dateStr}
                onClick={() => setSelectedDate(pill.dateStr)}
                className={`relative flex flex-col items-center justify-center min-w-14 py-2 px-1 rounded-xl transition-all ${
                  isSelected
                    ? 'bg-teal-600 text-white shadow-sm shadow-teal-600/30 font-bold scale-102'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
                }`}
              >
                <span className={`text-[10px] uppercase font-semibold ${isSelected ? 'text-teal-100' : 'text-slate-400'}`}>
                  {pill.dayName}
                </span>
                <span className="text-base font-extrabold leading-tight mt-0.5">
                  {pill.dayNumber}
                </span>

                {/* Appointment count badge dot */}
                {pill.count > 0 && (
                  <span
                    className={`mt-1 w-1.5 h-1.5 rounded-full ${
                      isSelected ? 'bg-white' : 'bg-teal-600'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Status Filters */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {['todos', 'confirmado', 'agendado', 'concluido', 'cancelado'].map((st) => {
          const labels: Record<string, string> = {
            todos: 'Todos',
            confirmado: 'Confirmados',
            agendado: 'Agendados',
            concluido: 'Concluídos',
            cancelado: 'Cancelados',
          };
          const isActive = statusFilter === st;
          return (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-full font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {labels[st]}
            </button>
          );
        })}
      </div>

      {/* Appointment Cards for Selected Day */}
      {dayAppointments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center">
          <div className="w-12 h-12 rounded-full bg-slate-50 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Clock className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-bold text-slate-800">
            Nenhuma consulta agendada para {formatDateBR(selectedDate)}
          </h4>
          <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
            Clique no botão abaixo para adicionar um atendimento nesta data.
          </p>
          <button
            type="button"
            onClick={() => openAppointmentModal(undefined, selectedDate)}
            className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-teal-600 text-white hover:bg-teal-700 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            Agendar Consulta neste Dia
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {dayAppointments.map((apt) => (
            <div
              key={apt.id}
              className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-slate-300 transition-all space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-3">
                  {/* Time Badge */}
                  <div className="flex flex-col items-center justify-center px-3 py-1.5 rounded-xl bg-teal-50 text-teal-800 border border-teal-100 shrink-0">
                    <Clock className="w-3.5 h-3.5 text-teal-600 mb-0.5" />
                    <span className="text-xs font-black">{apt.time}</span>
                    <span className="text-[9px] text-teal-600 font-medium">
                      {apt.durationMinutes} min
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h4 className="text-sm font-bold text-slate-900">{apt.patientName}</h4>
                      {(() => {
                        const p = patients.find((pat) => pat.id === apt.patientId);
                        if (p && hasCriticalClinicalAlert(p)) {
                          return (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[9px] font-black uppercase bg-rose-600 text-white shadow-xs">
                              <AlertTriangle className="w-2.5 h-2.5" />
                              Alerta Clínico
                            </span>
                          );
                        }
                        return null;
                      })()}
                    </div>
                    <span className="inline-block px-2 py-0.5 rounded-md bg-slate-100 text-teal-800 text-xs font-semibold mt-0.5">
                      {apt.procedure}
                    </span>
                    {apt.notes && (
                      <p className="text-xs text-slate-500 mt-1 italic">
                        "{apt.notes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Status Badge */}
                <div className="flex flex-col items-end gap-1 shrink-0">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border capitalize ${getStatusColor(
                      apt.status
                    )}`}
                  >
                    {apt.status}
                  </span>
                </div>
              </div>

              {/* Action Toolbar */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                {/* WhatsApp button */}
                <button
                  onClick={() => handleOpenWhatsApp(apt)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold active:scale-95 transition-all"
                  title="Enviar mensagem ou confirmação pelo WhatsApp"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" />
                  <span>Lembrete WhatsApp</span>
                </button>

                {/* Status Selector Dropdown / Pills */}
                <div className="flex items-center gap-1">
                  <select
                    value={apt.status}
                    onChange={(e) =>
                      updateAppointmentStatus(apt.id, e.target.value as AppointmentStatus)
                    }
                    className="text-xs font-semibold py-1 px-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="agendado">Agendado</option>
                    <option value="confirmado">Confirmado</option>
                    <option value="concluido">Concluído</option>
                    <option value="cancelado">Cancelado</option>
                  </select>

                  <button
                    onClick={() => openOdontogramForPatient(apt.patientId)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-teal-700 hover:bg-slate-100 transition-colors"
                    title="Odontograma deste Paciente"
                  >
                    <Stethoscope className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleEdit(apt)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                    title="Editar Consulta"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => handleDelete(apt)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    title="Excluir Consulta"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
