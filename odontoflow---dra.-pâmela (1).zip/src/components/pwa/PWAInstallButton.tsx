import React, { useState } from 'react';
import { Download, Share2, PlusSquare, X, CheckCircle2, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSModal, setShowIOSModal] = useState(false);

  // If already running standalone as an installed PWA, show a subtle active badge or hide
  if (isInstalled) {
    return (
      <div className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-teal-800 bg-teal-50 rounded-full border border-teal-200">
        <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
        <span className="hidden sm:inline">PWA Instalado</span>
      </div>
    );
  }

  return (
    <>
      {isInstallable && (
        <button
          onClick={install}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 rounded-full shadow-sm transition-all duration-150"
          title="Instalar OdontoFlow no seu aparelho"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Instalar App</span>
        </button>
      )}

      {/* iOS Safari Button */}
      {isIOS && !isInstallable && (
        <button
          onClick={() => setShowIOSModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 border border-teal-200 active:scale-95 rounded-full transition-all duration-150"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Instalar no iPhone</span>
        </button>
      )}

      {/* Fallback button if neither is triggered (for desktop browsers or testing) */}
      {!isInstallable && !isIOS && (
        <button
          onClick={() => setShowIOSModal(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-teal-700 bg-slate-100 hover:bg-slate-200 rounded-full transition-colors"
          title="Como instalar no seu celular ou computador"
        >
          <Download className="w-3.5 h-3.5 text-teal-600" />
          <span className="hidden sm:inline">Instalar</span>
        </button>
      )}

      {/* iOS Safari Installation Guide Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
          <div className="relative w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl border border-slate-100 animate-in slide-in-from-bottom-6">
            <button
              onClick={() => setShowIOSModal(false)}
              className="absolute right-4 top-4 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              aria-label="Fechar"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-teal-600 flex items-center justify-center text-white shadow-md shadow-teal-600/30">
                <span className="text-xl font-bold">OF</span>
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Instalar o OdontoFlow</h3>
                <p className="text-xs text-slate-500">App nativo para iPhone & Safari</p>
              </div>
            </div>

            <div className="space-y-3.5 text-sm text-slate-700 mb-6 bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <div className="flex items-start gap-3">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-teal-100 text-teal-700 text-xs font-bold">
                  1
                </div>
                <div className="text-xs text-slate-600">
                  No Safari do iPhone, toque no botão <strong className="text-slate-900">Compartilhar</strong>{' '}
                  <Share2 className="w-3.5 h-3.5 inline text-teal-600 -mt-0.5" /> na barra inferior.
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-teal-100 text-teal-700 text-xs font-bold">
                  2
                </div>
                <div className="text-xs text-slate-600">
                  Role o menu para baixo e selecione <strong className="text-slate-900">Adicionar à Tela de Início</strong>{' '}
                  <PlusSquare className="w-3.5 h-3.5 inline text-teal-600 -mt-0.5" />.
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-teal-100 text-teal-700 text-xs font-bold">
                  3
                </div>
                <div className="text-xs text-slate-600">
                  Toque em <strong className="text-teal-700">Adicionar</strong> no canto superior direito. Pronto!
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowIOSModal(false)}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 active:scale-98 rounded-xl shadow-md transition-colors"
            >
              Entendi, obrigado!
            </button>
          </div>
        </div>
      )}
    </>
  );
};
