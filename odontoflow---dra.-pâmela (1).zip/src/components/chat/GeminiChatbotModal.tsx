import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Send,
  Sparkles,
  Bot,
  User,
  Trash2,
  Copy,
  Check,
  Stethoscope,
  HeartHandshake,
  TrendingUp,
  RefreshCw,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../lib/firebase';
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  serverTimestamp,
  deleteDoc,
  getDocs,
} from 'firebase/firestore';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'model';
  text: string;
  timestamp: string;
  rolePreset?: string;
  modelUsed?: string;
}

export type AssistantRole = 'clinico' | 'secretaria' | 'gestao';

const ROLE_PRESETS: Record<
  AssistantRole,
  {
    title: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    color: string;
    badgeColor: string;
    systemInstruction: string;
    quickPrompts: string[];
  }
> = {
  clinico: {
    title: 'Consultor Clínico Odontológico',
    description: 'Diagnósticos, farmacologia, doses anestésicas e condutas com pacientes especiais',
    icon: Stethoscope,
    color: 'teal',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-200',
    systemInstruction: `Você é o Consultor Clínico Odontológico de Inteligência Artificial da Dra. Pâmela na Clínica OdontoFlow.
Sua missão é auxiliar com condutas terapêuticas baseadas em evidências científicas, farmacologia odontológica (antibioticoterapia, analgésicos e anti-inflamatórios), cálculo de dose máxima de anestésicos locais (Lidocaína, Articaína, Mepivacaína, Prilocaina), condutas para gestantes, hipertensos, diabéticos e pacientes cardiopatas, além de passos clínicos de endodontia, periodontia e restaurações estéticas.
Mantenha um tom profissional, técnico, preciso e acolhedor. Responda em português com tópicos organizados e doses quando pertinentes.`,
    quickPrompts: [
      'Qual a conduta para gestante no 2º trimestre com pulpite aguda?',
      'Dose máxima de articaína 4% com epinefrina 1:100.000 para paciente de 60kg?',
      'Prescrição padrão para profilaxia antibiótica em endocardite infecciosa?',
      'Protocolo pós-operatório seguro para exodontia de siso incluso?',
    ],
  },
  secretaria: {
    title: 'Secretária Virtual & Relacionamento',
    description: 'Roteiros de WhatsApp, pós-operatório, confirmação de agenda e acolhimento',
    icon: HeartHandshake,
    color: 'emerald',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    systemInstruction: `Você é a Secretária Virtual e Especialista em Relacionamento com Pacientes da Clínica OdontoFlow da Dra. Pâmela.
Você elabora mensagens humanizadas, gentis e persuasivas para envio via WhatsApp e comunicação com pacientes: confirmação de consultas, orientações carinhosas de pós-operatório (gelo, repouso, alimentação fria), convites para recall preventivo semestral e mensagens de parabéns de aniversário.
Escreva textos prontos para copiar e colar no WhatsApp, usando emojis sutis e linguagem muito agradável.`,
    quickPrompts: [
      'Mensagem carinhosa de pós-operatório no dia seguinte à extração',
      'Mensagem persuasiva e gentil para paciente que sumiu há 7 meses',
      'Confirmação formal e acolhedora de consulta de clareamento dental',
      'Como responder paciente que cancelou de última hora pedindo remarcação?',
    ],
  },
  gestao: {
    title: 'Consultor de Gestão & Orçamentos',
    description: 'Apresentação de planos de tratamento, precificação e conversão ética',
    icon: TrendingUp,
    color: 'sky',
    badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
    systemInstruction: `Você é o Consultor de Gestão e Finanças Odontológicas da Dra. Pâmela.
Você auxilia na estruturação de planos de tratamento, argumentos éticos para apresentação de orçamentos (facetas em resina, reabilitação oral, clareamento), estratégias para reduzir inadimplência e faltas na clínica, e cálculo de margem de lucro por procedimento.`,
    quickPrompts: [
      'Como apresentar um plano de facetas em resina sem soar comercial?',
      'Estratégia para parcelamento sem risco no consultório',
      'Como cobrar consulta de avaliação inicial sem afastar o paciente?',
      'Como calcular o custo/hora do consultório para procedimentos de resina?',
    ],
  },
};

interface GeminiChatbotModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GeminiChatbotModal: React.FC<GeminiChatbotModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();

  const [activeRole, setActiveRole] = useState<AssistantRole>('clinico');
  const [selectedModel, setSelectedModel] = useState<string>('gemini-3.8-flash');
  const [inputMessage, setInputMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initial welcome message per role
  const getInitialRoleMessage = (role: AssistantRole): ChatMessage => {
    const roleInfo = ROLE_PRESETS[role];
    return {
      id: `welcome-${role}`,
      sender: 'model',
      text: `Olá, Dra. Pâmela! 👋 Sou seu **${roleInfo.title}** alimentado pela inteligência artificial Gemini.\n\nComo posso ajudar seu consultório agora? Você pode tirar dúvidas clínicas, pedir roteiros de mensagens para pacientes ou simular propostas de tratamento.`,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      rolePreset: role,
    };
  };

  // Sync with Firestore if authenticated or fallback to local state
  useEffect(() => {
    if (!isOpen) return;

    if (user) {
      const messagesRef = collection(db, 'chats', user.uid, 'messages');
      const q = query(messagesRef, orderBy('createdAt', 'asc'));

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const firestoreMsgs: ChatMessage[] = snapshot.docs.map((docSnap) => {
              const d = docSnap.data();
              return {
                id: docSnap.id,
                sender: d.sender,
                text: d.text,
                timestamp: d.timestamp || new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
                rolePreset: d.rolePreset,
                modelUsed: d.modelUsed,
              };
            });
            setMessages(firestoreMsgs);
          } else {
            setMessages([getInitialRoleMessage(activeRole)]);
          }
        },
        (err) => {
          console.warn('Firestore snapshot notice:', err);
          setMessages((prev) => (prev.length === 0 ? [getInitialRoleMessage(activeRole)] : prev));
        }
      );

      return () => unsubscribe();
    } else {
      // Local session
      setMessages((prev) => (prev.length === 0 ? [getInitialRoleMessage(activeRole)] : prev));
    }
  }, [isOpen, user, activeRole]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || loading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      rolePreset: activeRole,
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInputMessage('');
    setLoading(true);

    // Save to Firestore if authenticated
    if (user) {
      try {
        await addDoc(collection(db, 'chats', user.uid, 'messages'), {
          sender: 'user',
          text,
          timestamp: userMsg.timestamp,
          rolePreset: activeRole,
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        console.warn('Error persisting user message in Firestore:', err);
      }
    }

    try {
      // Send conversation to server-side Gemini endpoint
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map((m) => ({ sender: m.sender, text: m.text })),
          systemInstruction: ROLE_PRESETS[activeRole].systemInstruction,
          model: selectedModel,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro na resposta do servidor Gemini');
      }

      const botMsg: ChatMessage = {
        id: `model-${Date.now()}`,
        sender: 'model',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        rolePreset: activeRole,
        modelUsed: selectedModel,
      };

      setMessages((prev) => [...prev, botMsg]);

      // Save bot message to Firestore if authenticated
      if (user) {
        try {
          await addDoc(collection(db, 'chats', user.uid, 'messages'), {
            sender: 'model',
            text: botMsg.text,
            timestamp: botMsg.timestamp,
            rolePreset: activeRole,
            modelUsed: selectedModel,
            createdAt: serverTimestamp(),
          });
        } catch (err) {
          console.warn('Error persisting bot message in Firestore:', err);
        }
      }
    } catch (err: any) {
      console.error('Chatbot error:', err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'model',
        text: `⚠️ **Ops:** ${err.message || 'Não foi possível se comunicar com o modelo Gemini no momento. Verifique a chave de API nas configurações.'}`,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = async () => {
    if (!confirm('Deseja limpar o histórico desta conversa?')) return;

    if (user) {
      try {
        const msgsSnap = await getDocs(collection(db, 'chats', user.uid, 'messages'));
        const deletes = msgsSnap.docs.map((docSnap) => deleteDoc(docSnap.ref));
        await Promise.all(deletes);
      } catch (err) {
        console.warn('Error clearing Firestore chat history:', err);
      }
    }
    setMessages([getInitialRoleMessage(activeRole)]);
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (!isOpen) return null;

  const currentRole = ROLE_PRESETS[activeRole];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-auto h-[90vh] max-h-[780px]">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 text-white flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-400/30 flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-tight text-white flex items-center gap-1.5">
                  Assistente OdontoFlow AI
                  <span className="inline-flex items-center gap-1 px-2 py-0.2 rounded-full text-[10px] font-bold bg-teal-400/20 text-teal-200 border border-teal-300/30">
                    <Sparkles className="w-2.5 h-2.5" />
                    Gemini
                  </span>
                </h3>
              </div>
              <p className="text-xs text-teal-200/90 line-clamp-1">
                Inteligência clínica, apoio ao diagnóstico e atendimento da Dra. Pâmela
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Model Selector */}
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="bg-white/10 hover:bg-white/20 text-white text-[11px] font-semibold rounded-xl px-2.5 py-1.5 border border-white/15 focus:outline-none cursor-pointer"
              title="Selecione o modelo Gemini"
            >
              <option value="gemini-3.8-flash" className="text-slate-900 font-medium">
                Gemini 3.8 Flash (Padrão)
              </option>
              <option value="gemini-3.1-flash-lite" className="text-slate-900 font-medium">
                Gemini 3.1 Flash Lite (Rápido)
              </option>
              <option value="gemini-4-argon" className="text-slate-900 font-medium">
                Gemini 4 Argon (Raciocínio Complexo)
              </option>
            </select>

            <button
              onClick={handleClearHistory}
              className="p-2 text-teal-200 hover:text-rose-200 hover:bg-white/10 rounded-xl transition-colors"
              title="Limpar histórico da conversa"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Role Presets Tabs */}
        <div className="bg-slate-50 border-b border-slate-200 px-3 py-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
          {(Object.keys(ROLE_PRESETS) as AssistantRole[]).map((rKey) => {
            const role = ROLE_PRESETS[rKey];
            const Icon = role.icon;
            const isActive = activeRole === rKey;
            return (
              <button
                key={rKey}
                onClick={() => {
                  setActiveRole(rKey);
                  setMessages([getInitialRoleMessage(rKey)]);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-white text-teal-900 shadow-xs border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-teal-700' : 'text-slate-400'}`} />
                <span>{role.title}</span>
              </button>
            );
          })}
        </div>

        {/* Scrollable Chat Thread */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-slate-50/50">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex items-start gap-2.5 max-w-[88%] sm:max-w-[80%] ${
                  isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold shadow-2xs ${
                    isUser
                      ? 'bg-teal-700 text-white'
                      : 'bg-white border border-slate-200 text-teal-700'
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div
                  className={`rounded-2xl p-3.5 text-xs sm:text-sm leading-relaxed shadow-xs relative group ${
                    isUser
                      ? 'bg-teal-600 text-white rounded-tr-none'
                      : 'bg-white border border-slate-200/90 text-slate-800 rounded-tl-none'
                  }`}
                >
                  {/* Sender Header for Bot */}
                  {!isUser && (
                    <div className="flex items-center justify-between gap-3 mb-1.5 pb-1 border-b border-slate-100">
                      <span className="text-[10px] font-bold text-teal-800 flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5 text-teal-600" />
                        {currentRole.title}
                      </span>
                      <button
                        onClick={() => handleCopyText(msg.id, msg.text)}
                        className="text-slate-400 hover:text-slate-600 p-0.5 rounded transition-colors"
                        title="Copiar texto da resposta"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  )}

                  {/* Message Body with clean paragraphs/newlines */}
                  <div className="whitespace-pre-wrap font-normal break-words">
                    {msg.text}
                  </div>

                  {/* Time Footer */}
                  <div
                    className={`mt-1.5 text-[9px] text-right font-medium ${
                      isUser ? 'text-teal-200' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                    {msg.modelUsed && <span className="ml-1 opacity-80">• {msg.modelUsed}</span>}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Loading Indicator */}
          {loading && (
            <div className="flex items-start gap-2.5 max-w-[80%] mr-auto">
              <div className="w-8 h-8 rounded-xl bg-white border border-slate-200 text-teal-700 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-white border border-slate-200/90 rounded-2xl rounded-tl-none p-3.5 text-xs text-slate-600 flex items-center gap-2 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-teal-600 animate-pulse" />
                <span className="w-2 h-2 rounded-full bg-teal-600 animate-pulse delay-100" />
                <span className="w-2 h-2 rounded-full bg-teal-600 animate-pulse delay-200" />
                <span className="text-[11px] font-medium text-slate-500 ml-1">
                  Gemini analisando conduta odontológica...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestions Pills */}
        <div className="px-3.5 py-2 bg-slate-100/70 border-t border-slate-200/80 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 shrink-0">
            Sugestões:
          </span>
          {currentRole.quickPrompts.map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(prompt)}
              className="text-[11px] font-medium bg-white hover:bg-teal-50 hover:text-teal-900 hover:border-teal-300 text-slate-700 px-2.5 py-1 rounded-xl border border-slate-200/90 transition-all whitespace-nowrap shrink-0 active:scale-95 shadow-2xs"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder={`Pergunte algo sobre ${currentRole.title.toLowerCase()}...`}
            className="flex-1 px-3.5 py-2.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white transition-all"
            disabled={loading}
          />

          <button
            onClick={() => handleSendMessage()}
            disabled={!inputMessage.trim() || loading}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 disabled:hover:bg-teal-600 text-white rounded-2xl font-bold text-xs flex items-center gap-1.5 shadow-md shadow-teal-600/20 active:scale-95 transition-all shrink-0"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Enviar</span>
          </button>
        </div>
      </div>
    </div>
  );
};
