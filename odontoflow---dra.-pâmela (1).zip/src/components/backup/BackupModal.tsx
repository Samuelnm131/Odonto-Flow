import React, { useState, useRef } from 'react';
import {
  X,
  ShieldCheck,
  Download,
  Upload,
  Database,
  FileJson,
  AlertTriangle,
  CheckCircle2,
  Users,
  Calendar,
  Activity,
  DollarSign,
  FileText,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface BackupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BackupModal: React.FC<BackupModalProps> = ({ isOpen, onClose }) => {
  const {
    exportBackupData,
    importBackupData,
    patients,
    appointments,
    budgets,
    dentalCharts,
    documents,
    showToast,
  } = useApp();

  const [isImporting, setIsImporting] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleExport = () => {
    exportBackupData();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFileName(file.name);
    const reader = new FileReader();

    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        setIsImporting(true);
        const success = importBackupData(content);
        setIsImporting(false);

        if (success) {
          onClose();
        }
      } catch (err) {
        setIsImporting(false);
        showToast('Falha ao processar arquivo de backup. Formato inválido.', 'error');
      }
    };

    reader.readAsText(file);
    // Reset input value so same file can be reselected if needed
    e.target.value = '';
  };

  const teethWithRecords = Object.values(dentalCharts).reduce(
    (acc, chart) => acc + Object.keys(chart).length,
    0
  );

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-lg max-h-[92vh] sm:max-h-[88vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                Segurança e Backup de Dados
              </h3>
              <p className="text-xs text-slate-500">
                OdontoFlow • Dra. Pâmela
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Summary of current database */}
          <div className="p-3.5 rounded-2xl bg-teal-50/70 border border-teal-200/80">
            <h4 className="text-xs font-bold text-teal-950 mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-teal-700" />
              <span>Resumo dos Dados Atuais no Dispositivo</span>
            </h4>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 text-center text-xs">
              <div className="bg-white/80 p-2 rounded-xl border border-teal-100">
                <span className="block text-base font-black text-teal-900">{patients.length}</span>
                <span className="text-[10px] text-teal-700 font-medium">Pacientes</span>
              </div>
              <div className="bg-white/80 p-2 rounded-xl border border-teal-100">
                <span className="block text-base font-black text-teal-900">{appointments.length}</span>
                <span className="text-[10px] text-teal-700 font-medium">Consultas</span>
              </div>
              <div className="bg-white/80 p-2 rounded-xl border border-teal-100">
                <span className="block text-base font-black text-teal-900">{teethWithRecords}</span>
                <span className="text-[10px] text-teal-700 font-medium">Odontograma</span>
              </div>
              <div className="bg-white/80 p-2 rounded-xl border border-teal-100">
                <span className="block text-base font-black text-teal-900">{budgets.length}</span>
                <span className="text-[10px] text-teal-700 font-medium">Orçamentos</span>
              </div>
              <div className="bg-white/80 p-2 rounded-xl border border-teal-100 col-span-2 sm:col-span-1">
                <span className="block text-base font-black text-teal-900">{documents.length}</span>
                <span className="text-[10px] text-teal-700 font-medium">Receitas/Atest.</span>
              </div>
            </div>
          </div>

          {/* SECTION 1: EXPORTAR BACKUP */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center shrink-0 mt-0.5">
                <Download className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="text-xs font-bold text-slate-900">
                  1. Exportar Cópia de Segurança (Backup)
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                  Gera e baixa um arquivo <strong className="text-slate-700">.json</strong> com todos os pacientes, anamneses, odontogramas, orçamentos, evoluções clínicas, receituários e atestados para guardar no seu computador ou celular.
                </p>
              </div>
            </div>

            <button
              onClick={handleExport}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold shadow-md shadow-teal-600/20 transition-all"
            >
              <Download className="w-4 h-4 stroke-[2.3]" />
              <span>Baixar Arquivo de Backup (.json)</span>
            </button>
          </div>

          {/* SECTION 2: RESTAURAR BACKUP */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 mt-0.5">
                <Upload className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="text-xs font-bold text-slate-900">
                  2. Restaurar Dados de um Backup
                </h4>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                  Trocou de aparelho celular ou limpou o navegador? Selecione o arquivo <strong className="text-slate-700">.json</strong> exportado anteriormente para recuperar todo o histórico clínico imediatamente.
                </p>
              </div>
            </div>

            {/* Hidden file input */}
            <input
              type="file"
              ref={fileInputRef}
              accept=".json,application/json"
              onChange={handleFileChange}
              className="hidden"
            />

            <button
              type="button"
              disabled={isImporting}
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-800 text-xs font-bold border border-slate-200 transition-all"
            >
              <Upload className="w-4 h-4 text-teal-700 stroke-[2.3]" />
              <span>{isImporting ? 'Processando arquivo...' : 'Selecionar Arquivo .json para Restaurar'}</span>
            </button>

            <div className="flex items-start gap-2 p-2.5 rounded-xl bg-amber-50/80 border border-amber-200/80 text-[11px] text-amber-950">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                <strong>Atenção:</strong> A restauração substitui os registros atuais pelos dados do arquivo selecionado.
              </span>
            </div>
          </div>
        </div>

        {/* Footer (pb-safe for iPhone) */}
        <div className="p-4 pb-safe sm:pb-4 border-t border-slate-100 flex items-center justify-end bg-slate-50 shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-95 transition-all"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
