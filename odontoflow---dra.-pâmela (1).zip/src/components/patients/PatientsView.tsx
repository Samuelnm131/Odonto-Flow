import React, { useState, useMemo } from 'react';
import {
  Search,
  UserPlus,
  MessageCircle,
  AlertCircle,
  HeartPulse,
  Phone,
  Calendar,
  ChevronRight,
  Filter,
  X,
  Stethoscope,
  ShieldAlert,
  AlertTriangle,
  FileCheck,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Patient } from '../../types';
import { calculateAge, buildWhatsAppUrl, hasCriticalClinicalAlert } from '../../utils/masks';
import { PatientDetailModal } from './PatientDetailModal';

export const PatientsView: React.FC = () => {
  const {
    patients,
    openPatientModal,
    openOdontogramForPatient,
    openDocumentModal,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'todos' | 'criticos' | 'alergicos' | 'com_alerta'>('todos');
  const [selectedPatientForDetail, setSelectedPatientForDetail] = useState<Patient | null>(null);

  // Text normalization helper (removes accents, lowercase, trimmed)
  const normalize = (text: string) =>
    (text || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();

  // Detect whether user is searching predominantly by digits (CPF) or text (Name)
  const digitsInSearch = searchQuery.replace(/\D/g, '');
  const isCpfSearch = digitsInSearch.length >= 2;

  // Filter patients by real-time search (name or CPF)
  const filteredPatients = useMemo(() => {
    const rawQuery = searchQuery.trim();
    if (!rawQuery) {
      if (filterType === 'criticos') return patients.filter(hasCriticalClinicalAlert);
      if (filterType === 'alergicos') return patients.filter((p) => p.allergies.length > 0);
      if (filterType === 'com_alerta') return patients.filter((p) => p.medicalAlerts.length > 0 || p.allergies.length > 0);
      return patients;
    }

    const normQuery = normalize(rawQuery);
    const cleanNumbers = digitsInSearch;

    return patients.filter((patient) => {
      const normName = normalize(patient.name);
      const patientCpfDigits = (patient.cpf || '').replace(/\D/g, '');
      const patientPhoneDigits = (patient.phone || '').replace(/\D/g, '');

      // Name match (accent-insensitive)
      const matchesName = normName.includes(normQuery);

      // CPF match (numbers only comparison or raw match)
      const matchesCpf =
        (cleanNumbers.length > 0 && patientCpfDigits.includes(cleanNumbers)) ||
        (patient.cpf && normalize(patient.cpf).includes(normQuery));

      // Optional phone match when numbers provided
      const matchesPhone = cleanNumbers.length >= 4 && patientPhoneDigits.includes(cleanNumbers);

      const matchesSearch = matchesName || matchesCpf || matchesPhone;
      if (!matchesSearch) return false;

      if (filterType === 'criticos') {
        return hasCriticalClinicalAlert(patient);
      }
      if (filterType === 'alergicos') {
        return patient.allergies.length > 0;
      }
      if (filterType === 'com_alerta') {
        return patient.medicalAlerts.length > 0 || patient.allergies.length > 0;
      }
      return true;
    });
  }, [patients, searchQuery, filterType, digitsInSearch]);

  const handleOpenWhatsApp = (e: React.MouseEvent, patient: Patient) => {
    e.stopPropagation();
    const text = `Olá ${patient.name}, tudo bem? Aqui é da clínica odontológica da Dra. Pâmela.`;
    window.open(buildWhatsAppUrl(patient.phone, text), '_blank');
  };

  const handleEditPatient = (patient: Patient) => {
    setSelectedPatientForDetail(null);
    openPatientModal(patient);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Top Action & Search Bar */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">Pacientes</h2>
            <p className="text-xs text-slate-500">
              {filteredPatients.length} de {patients.length} pacientes cadastrados
            </p>
          </div>

          <button
            type="button"
            onClick={() => openPatientModal()}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold shadow-xs transition-all"
            title="Cadastrar Novo Paciente"
          >
            <UserPlus className="w-4 h-4 stroke-[2.3]" />
            <span>Novo Paciente</span>
          </button>
        </div>

        {/* Quick Search Input with Real-time Filtering */}
        <div className="space-y-1.5">
          <div className="relative group">
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none text-slate-400 group-focus-within:text-teal-600 transition-colors">
              <Search className="w-4 h-4" />
            </div>

            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') setSearchQuery('');
              }}
              placeholder="Pesquisar paciente por Nome ou CPF..."
              className="w-full pl-10 pr-24 py-2.5 rounded-2xl border border-slate-200/90 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 shadow-xs transition-all font-medium"
            />

            {/* Right side badge / clear action */}
            <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
              {searchQuery ? (
                <>
                  <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md border border-teal-200/60 hidden xs:inline">
                    {filteredPatients.length} enc.
                  </span>
                  <button
                    onClick={() => setSearchQuery('')}
                    className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition-all"
                    title="Limpar pesquisa (Esc)"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </>
              ) : (
                <span className="text-[10px] text-slate-400 font-semibold bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 hidden sm:inline">
                  Nome ou CPF
                </span>
              )}
            </div>
          </div>

          {/* Active Search Filter Status Notification */}
          {searchQuery && (
            <div className="flex items-center justify-between px-1 text-xs">
              <p className="text-slate-500 text-[11px] flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
                <span>
                  {isCpfSearch ? 'Filtrando por CPF:' : 'Filtrando por Nome:'}{' '}
                  <strong className="text-slate-800 font-bold">"{searchQuery}"</strong>
                </span>
                <span className="text-slate-400">• {filteredPatients.length} {filteredPatients.length === 1 ? 'resultado' : 'resultados'}</span>
              </p>
              <button
                onClick={() => setSearchQuery('')}
                className="text-[11px] font-semibold text-teal-700 hover:text-teal-900 underline underline-offset-2"
              >
                Limpar filtro
              </button>
            </div>
          )}
        </div>

        {/* Quick Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
          <button
            onClick={() => setFilterType('todos')}
            className={`px-3 py-1 rounded-full font-semibold whitespace-nowrap transition-all ${
              filterType === 'todos'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Todos ({patients.length})
          </button>
          <button
            onClick={() => setFilterType('criticos')}
            className={`flex items-center gap-1 px-3 py-1 rounded-full font-semibold whitespace-nowrap transition-all ${
              filterType === 'criticos'
                ? 'bg-rose-700 text-white shadow-xs'
                : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>Alerta Clínico</span>
          </button>
          <button
            onClick={() => setFilterType('alergicos')}
            className={`flex items-center gap-1 px-3 py-1 rounded-full font-semibold whitespace-nowrap transition-all ${
              filterType === 'alergicos'
                ? 'bg-rose-600 text-white'
                : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
            }`}
          >
            <AlertCircle className="w-3 h-3 text-rose-500" />
            <span>Alérgicos</span>
          </button>
          <button
            onClick={() => setFilterType('com_alerta')}
            className={`flex items-center gap-1 px-3 py-1 rounded-full font-semibold whitespace-nowrap transition-all ${
              filterType === 'com_alerta'
                ? 'bg-amber-600 text-white'
                : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            <HeartPulse className="w-3 h-3 text-amber-500" />
            <span>Saúde Geral</span>
          </button>
        </div>
      </div>

      {/* Patient Cards List */}
      {filteredPatients.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-bold text-slate-800">Nenhum paciente encontrado</h4>
          <p className="text-xs text-slate-500 mt-1">
            {searchQuery
              ? `Não encontramos pacientes para o termo "${searchQuery}". Tente outro nome ou número de CPF.`
              : 'Verifique a busca por nome ou CPF ou adicione um novo paciente à clínica.'}
          </p>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="mt-3 px-3.5 py-1.5 rounded-xl bg-teal-50 text-teal-800 font-bold text-xs hover:bg-teal-100 transition-colors"
            >
              Limpar busca
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredPatients.map((patient) => {
            const age = calculateAge(patient.birthDate);
            const isCritical = hasCriticalClinicalAlert(patient);
            const hasAllergy = patient.allergies.length > 0;
            const hasAlert = patient.medicalAlerts.length > 0;
            const chief = patient.dentalHealth?.chiefComplaint || patient.notes;

            return (
              <div
                key={patient.id}
                onClick={() => setSelectedPatientForDetail(patient)}
                className={`bg-white p-4 rounded-2xl border shadow-xs active:scale-[0.99] transition-all cursor-pointer group ${
                  isCritical
                    ? 'border-rose-200/90 hover:border-rose-400 ring-1 ring-rose-200/50'
                    : 'border-slate-200/80 hover:border-teal-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-10 h-10 rounded-2xl font-bold flex items-center justify-center shrink-0 transition-colors ${
                        isCritical
                          ? 'bg-rose-50 border border-rose-200 text-rose-700 group-hover:bg-rose-600 group-hover:text-white'
                          : 'bg-teal-50 border border-teal-100 text-teal-800 group-hover:bg-teal-600 group-hover:text-white'
                      }`}
                    >
                      {patient.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="text-sm font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                          {patient.name}
                        </h4>

                        {/* Critical Clinical Alert Badge Requested by User */}
                        {isCritical && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.2 rounded-full text-[9px] font-black tracking-wider uppercase bg-rose-600 text-white shadow-xs animate-in zoom-in-75">
                            <AlertTriangle className="w-2.5 h-2.5" />
                            Alerta Clínico
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5 flex-wrap">
                        <span>{age ? `${age} anos` : 'Idade não inf.'}</span>
                        <span>•</span>
                        <span
                          className={`transition-colors ${
                            isCpfSearch &&
                            digitsInSearch.length >= 2 &&
                            patient.cpf?.replace(/\D/g, '').includes(digitsInSearch)
                              ? 'font-bold text-teal-900 bg-teal-100 px-1.5 py-0.2 rounded-md ring-1 ring-teal-300'
                              : 'text-slate-600'
                          }`}
                        >
                          CPF: {patient.cpf || 'Sem CPF'}
                        </span>
                        {patient.profession && (
                          <>
                            <span>•</span>
                            <span>{patient.profession}</span>
                          </>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Action Triggers: Document & WhatsApp */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openDocumentModal({ patientId: patient.id });
                      }}
                      className="p-1.5 rounded-xl bg-teal-50 text-teal-800 hover:bg-teal-100 border border-teal-200 transition-colors"
                      title="Emitir Receituário ou Atestado"
                    >
                      <FileCheck className="w-3.5 h-3.5 text-teal-700" />
                    </button>

                    <button
                      onClick={(e) => handleOpenWhatsApp(e, patient)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold transition-colors"
                      title="Disparar mensagem no WhatsApp"
                    >
                      <MessageCircle className="w-3.5 h-3.5 text-emerald-600 fill-emerald-100" />
                      <span className="hidden xs:inline">WhatsApp</span>
                    </button>
                  </div>
                </div>

                {/* Chief Complaint if available */}
                {chief && (
                  <p className="mt-2 text-xs text-slate-600 bg-slate-50 p-2 rounded-xl border border-slate-100 italic line-clamp-1">
                    "{chief}"
                  </p>
                )}

                {/* Badges for Allergies & Health Alerts (Red & Yellow) */}
                {(hasAllergy || hasAlert) && (
                  <div className="mt-2 pt-2 border-t border-slate-100 flex flex-wrap gap-1.5">
                    {patient.allergies.map((allergy, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                        Alérgico: {allergy}
                      </span>
                    ))}

                    {patient.medicalAlerts.map((cond, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                        {cond}
                      </span>
                    ))}
                  </div>
                )}

                {/* Bottom Row: Contact & Quick Access */}
                <div className="mt-2 pt-2 flex items-center justify-between text-xs text-slate-500">
                  <span className="text-[11px] font-medium text-slate-400">
                    {patient.phone}
                  </span>
                  <div className="flex items-center gap-1 text-teal-700 font-semibold group-hover:translate-x-0.5 transition-transform">
                    <span>Ver Prontuário & Anamneses</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}


      {/* Patient Details Modal */}
      <PatientDetailModal
        patient={selectedPatientForDetail}
        isOpen={!!selectedPatientForDetail}
        onClose={() => setSelectedPatientForDetail(null)}
        onEdit={handleEditPatient}
      />
    </div>
  );
};
