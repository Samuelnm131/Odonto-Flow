import React, { useState } from 'react';
import {
  FileCheck,
  Plus,
  Trash2,
  Eye,
  Printer,
  Share2,
  ShieldCheck,
  Calendar,
  PenTool,
} from 'lucide-react';
import { ConsentForm, Patient } from '../../types';
import { useApp } from '../../context/AppContext';
import { formatDateBR, buildWhatsAppUrl } from '../../utils/masks';
import { ConsentFormModal } from './ConsentFormModal';

interface ConsentFormsListProps {
  patient: Patient;
}

export const ConsentFormsList: React.FC<ConsentFormsListProps> = ({ patient }) => {
  const { getPatientConsentForms, deleteConsentForm } = useApp();
  const consentForms = getPatientConsentForms(patient.id);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedFormToView, setSelectedFormToView] = useState<ConsentForm | null>(null);

  const handleOpenNew = () => {
    setSelectedFormToView(null);
    setIsModalOpen(true);
  };

  const handleViewForm = (form: ConsentForm) => {
    setSelectedFormToView(form);
    setIsModalOpen(true);
  };

  const handleShareOnWhatsApp = (e: React.MouseEvent, form: ConsentForm) => {
    e.stopPropagation();
    const text = `Olá ${patient.name}! Segue a confirmação do seu ${form.title} assinado digitalmente na clínica da Dra. Pâmela em ${form.signedDate}. O termo está arquivado em seu prontuário clínico.`;
    window.open(buildWhatsAppUrl(patient.phone, text), '_blank');
  };

  return (
    <div className="space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
            <FileCheck className="w-3.5 h-3.5 text-teal-600" />
            <span>Termos de Consentimento Assinados ({consentForms.length})</span>
          </h4>
          <p className="text-[11px] text-slate-400">Proteção jurídica e transparência para paciente e dentista</p>
        </div>

        <button
          type="button"
          onClick={handleOpenNew}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
        >
          <PenTool className="w-3.5 h-3.5" />
          <span>Novo Termo (TCLE)</span>
        </button>
      </div>

      {/* List of Signed Forms */}
      {consentForms.length === 0 ? (
        <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50 space-y-3">
          <div className="w-12 h-12 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center mx-auto">
            <FileCheck className="w-6 h-6" />
          </div>
          <div>
            <h5 className="text-xs font-bold text-slate-700">Nenhum termo de consentimento registrado</h5>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Colete a assinatura digital do paciente pelo celular/tablet antes de procedimentos cirúrgicos, clareamento ou canal.
            </p>
          </div>
          <button
            type="button"
            onClick={handleOpenNew}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Coletar Assinatura Agora</span>
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {consentForms.map((form) => (
            <div
              key={form.id}
              onClick={() => handleViewForm(form)}
              className="p-3.5 bg-white rounded-2xl border border-slate-200 hover:border-teal-400 shadow-xs hover:shadow-md transition-all cursor-pointer flex items-center justify-between gap-3 group"
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                  <FileCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h5 className="text-xs font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                      {form.title}
                    </h5>
                    <span className="inline-flex items-center gap-1 text-[9px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.2 rounded-full">
                      <ShieldCheck className="w-2.5 h-2.5" /> Assinado
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Assinado por: <strong className="text-slate-700">{form.signedByName}</strong> • {form.signedDate}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-1 italic">
                    "{form.content.substring(0, 110)}..."
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={(e) => handleShareOnWhatsApp(e, form)}
                  className="p-1.5 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors"
                  title="Enviar no WhatsApp"
                >
                  <Share2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewForm(form);
                  }}
                  className="p-1.5 rounded-xl bg-teal-50 text-teal-700 hover:bg-teal-100 transition-colors"
                  title="Visualizar Termo Completo"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm(`Excluir o termo "${form.title}"?`)) {
                      deleteConsentForm(patient.id, form.id);
                    }
                  }}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                  title="Excluir Termo"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      <ConsentFormModal
        patient={patient}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        formToView={selectedFormToView}
      />
    </div>
  );
};
