import React, { useState } from 'react';
import {
  X,
  Phone,
  MessageCircle,
  MapPin,
  Calendar,
  AlertCircle,
  HeartPulse,
  Pill,
  Clock,
  Plus,
  Stethoscope,
  Edit2,
  Trash2,
  ShieldAlert,
  User,
  Activity,
  Smile,
  FileText,
  PlusCircle,
  CheckCircle2,
  FileCheck,
  Printer,
  Send,
  AlertTriangle,
} from 'lucide-react';
import { Patient, Appointment, ClinicalDocument, PrescriptionDocument, CertificateDocument } from '../../types';
import { calculateAge, formatDateBR, buildWhatsAppUrl, hasCriticalClinicalAlert, formatPrescriptionWhatsAppMessage, formatCertificateWhatsAppMessage } from '../../utils/masks';
import { useApp } from '../../context/AppContext';
import { ClinicalEvolutionModal } from './ClinicalEvolutionModal';
import { ClinicalPhotoGallery } from './ClinicalPhotoGallery';
import { ConsentFormsList } from './ConsentFormsList';

interface PatientDetailModalProps {
  patient: Patient | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (patient: Patient) => void;
}

export const PatientDetailModal: React.FC<PatientDetailModalProps> = ({
  patient,
  isOpen,
  onClose,
  onEdit,
}) => {
  const {
    appointments,
    openOdontogramForPatient,
    openAppointmentModal,
    deletePatient,
    getPatientChart,
    getPatientEvolutions,
    addClinicalEvolution,
    deleteClinicalEvolution,
    getPatientDocuments,
    openDocumentModal,
    deleteDocument,
    getPatientPhotos,
    getPatientConsentForms,
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'anamnese' | 'odonto' | 'evolucoes' | 'fotos' | 'termos' | 'consultas' | 'documentos'
  >('anamnese');
  const [isEvolutionModalOpen, setIsEvolutionModalOpen] = useState(false);

  if (!isOpen || !patient) return null;

  const age = calculateAge(patient.birthDate);
  const patientDocuments = getPatientDocuments(patient.id);
  const patientAppointments = appointments.filter((apt) => apt.patientId === patient.id);
  const patientEvolutions = getPatientEvolutions(patient.id);
  const patientPhotos = getPatientPhotos(patient.id);
  const patientConsentForms = getPatientConsentForms(patient.id);
  const chart = getPatientChart(patient.id);
  const treatedOrNeededTeeth = Object.values(chart).filter(
    (t) => t.status === 'tratamento_necessario' || t.status === 'em_andamento'
  );

  const isCritical = hasCriticalClinicalAlert(patient);
  const gh = patient.generalHealth;
  const dh = patient.dentalHealth;

  const handleOpenWhatsApp = () => {
    const text = `Olá ${patient.name}, tudo bem? Aqui é da clínica da Dra. Pâmela. Como podemos ajudar hoje?`;
    window.open(buildWhatsAppUrl(patient.phone, text), '_blank');
  };

  const handleOpenEmergencyWhatsApp = () => {
    if (!patient.emergencyContact?.phone) return;
    const text = `Olá, aqui é da clínica odontológica da Dra. Pâmela. Entrando em contato a respeito de ${patient.name}.`;
    window.open(buildWhatsAppUrl(patient.emergencyContact.phone, text), '_blank');
  };

  const handleScheduleForThisPatient = () => {
    onClose();
    openAppointmentModal(undefined, undefined, patient.id);
  };

  const handleOpenOdontogram = () => {
    onClose();
    openOdontogramForPatient(patient.id);
  };

  const handleDelete = () => {
    if (confirm(`Tem certeza que deseja excluir o cadastro de ${patient.name}?`)) {
      deletePatient(patient.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-xl max-h-[94vh] sm:max-h-[90vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/90">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-11 h-11 rounded-2xl bg-teal-600 text-white font-extrabold flex items-center justify-center text-base shadow-sm">
                {patient.name.charAt(0)}
              </div>
              {isCritical && (
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-600 rounded-full border-2 border-white animate-pulse" title="Alerta Clínico" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <h3 className="text-base font-bold text-slate-900 leading-tight">
                  {patient.name}
                </h3>
                {isCritical && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-rose-600 text-white shadow-xs">
                    <AlertTriangle className="w-2.5 h-2.5" />
                    Alerta Clínico
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500">
                {age ? `${age} anos` : 'Idade não informada'} • CPF: {patient.cpf || 'Não cadastrado'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Critical Banner if patient has medical risk */}
        {isCritical && (
          <div className="bg-rose-50 border-b border-rose-200 px-5 py-2.5 flex items-start gap-2.5 text-xs text-rose-950">
            <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-rose-900">Alerta Médico de Risco Clínico:</strong>
              <span className="text-rose-800">
                {patient.allergies.length > 0 && `Alergias: ${patient.allergies.join(', ')}. `}
                {gh?.systemicDiseases && gh.systemicDiseases.length > 0 && `Condições: ${gh.systemicDiseases.join(', ')}. `}
                {gh?.hasAnticoagulantsOrBisphosphonates && 'Uso de Anticoagulante/Bifosfonato. '}
                {gh?.pregnancyStatus === 'gestante' && `Gestante (${gh.pregnancyDetails || 'Atenção especial'}). `}
                {gh?.healingOrBleedingIssues && 'Histórico de hemorragia ou lipotimia.'}
              </span>
            </div>
          </div>
        )}

        {/* Sub-tabs Selector */}
        <div className="px-3 pt-3 pb-1 border-b border-slate-100 bg-white">
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl overflow-x-auto text-[10px] sm:text-[11px] font-bold text-slate-600">
            <button
              type="button"
              onClick={() => setActiveTab('anamnese')}
              className={`py-1.5 px-2.5 rounded-xl text-center whitespace-nowrap transition-all ${
                activeTab === 'anamnese'
                  ? 'bg-white text-teal-800 shadow-xs font-extrabold'
                  : 'hover:text-slate-900'
              }`}
            >
              Geral
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('odonto')}
              className={`py-1.5 px-2.5 rounded-xl text-center whitespace-nowrap transition-all ${
                activeTab === 'odonto'
                  ? 'bg-white text-teal-800 shadow-xs font-extrabold'
                  : 'hover:text-slate-900'
              }`}
            >
              Bucal
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('evolucoes')}
              className={`py-1.5 px-2.5 rounded-xl text-center whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
                activeTab === 'evolucoes'
                  ? 'bg-white text-teal-800 shadow-xs font-extrabold'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>Evolução</span>
              {patientEvolutions.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-teal-100 text-teal-800 font-extrabold">
                  {patientEvolutions.length}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('fotos')}
              className={`py-1.5 px-2.5 rounded-xl text-center whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
                activeTab === 'fotos'
                  ? 'bg-white text-teal-800 shadow-xs font-extrabold'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>Fotos & Rx</span>
              {patientPhotos.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-purple-100 text-purple-800 font-extrabold">
                  {patientPhotos.length}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('termos')}
              className={`py-1.5 px-2.5 rounded-xl text-center whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
                activeTab === 'termos'
                  ? 'bg-white text-teal-800 shadow-xs font-extrabold'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>Termos (TCLE)</span>
              {patientConsentForms.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-emerald-100 text-emerald-800 font-extrabold">
                  {patientConsentForms.length}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('consultas')}
              className={`py-1.5 px-2.5 rounded-xl text-center whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
                activeTab === 'consultas'
                  ? 'bg-white text-teal-800 shadow-xs font-extrabold'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>Agenda</span>
              {patientAppointments.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-slate-200 text-slate-700 font-extrabold">
                  {patientAppointments.length}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('documentos')}
              className={`py-1.5 px-2.5 rounded-xl text-center whitespace-nowrap transition-all flex items-center justify-center gap-1 ${
                activeTab === 'documentos'
                  ? 'bg-white text-teal-800 shadow-xs font-extrabold'
                  : 'hover:text-slate-900'
              }`}
            >
              <span>Receitas/Atestados</span>
              {patientDocuments.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-teal-600 text-white font-extrabold">
                  {patientDocuments.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Quick Action Shortcuts */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            <button
              onClick={() => setIsEvolutionModalOpen(true)}
              className="col-span-2 sm:col-span-3 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 active:scale-98 text-white text-xs font-bold shadow-sm shadow-teal-700/20 transition-all"
            >
              <FileText className="w-4 h-4 text-teal-200" />
              <span>+ Evolução Clínica / Anotação da Consulta</span>
            </button>

            <button
              onClick={() => openDocumentModal({ patientId: patient.id })}
              className="col-span-2 sm:col-span-3 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-bold border border-teal-200/90 transition-all active:scale-98"
            >
              <FileCheck className="w-4 h-4 text-teal-700" />
              <span>Emitir Receituário ou Atestado</span>
            </button>

            <button
              onClick={handleOpenWhatsApp}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white text-xs font-bold shadow-xs transition-all"
            >
              <MessageCircle className="w-4 h-4 fill-white/20" />
              <span>WhatsApp</span>
            </button>

            <button
              onClick={handleOpenOdontogram}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-teal-600 hover:bg-teal-700 active:scale-95 text-white text-xs font-bold shadow-xs transition-all"
            >
              <Stethoscope className="w-4 h-4" />
              <span>Odontograma</span>
            </button>

            <button
              onClick={handleScheduleForThisPatient}
              className="col-span-2 sm:col-span-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-800 text-xs font-semibold transition-all"
            >
              <Plus className="w-4 h-4 text-teal-600" />
              <span>Agendar</span>
            </button>
          </div>

          {/* TAB 1: SAÚDE GERAL & DADOS */}
          {activeTab === 'anamnese' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              {/* Informações Pessoais & Emergência */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-700">
                  <span className="flex items-center gap-1.5 font-semibold">
                    <Phone className="w-3.5 h-3.5 text-teal-600" />
                    {patient.phone}
                  </span>
                  {patient.gender && (
                    <span className="capitalize text-slate-500 font-medium">
                      Sexo: {patient.gender === 'prefiro_nao_informar' ? 'Não informado' : patient.gender}
                    </span>
                  )}
                </div>

                {patient.birthDate && (
                  <div className="flex items-center justify-between text-slate-700">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-teal-600" />
                      Nascimento: {formatDateBR(patient.birthDate)} ({age} anos)
                    </span>
                    {patient.profession && (
                      <span className="text-slate-500">Profissão: {patient.profession}</span>
                    )}
                  </div>
                )}

                {patient.address && (
                  <div className="flex items-start gap-1.5 text-slate-700 pt-1 border-t border-slate-200/60">
                    <MapPin className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                    <span>{patient.address}</span>
                  </div>
                )}

                {/* Contato de Emergência */}
                {patient.emergencyContact && patient.emergencyContact.name && (
                  <div className="mt-2 pt-2 border-t border-slate-200/60 flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200">
                    <div>
                      <span className="text-[10px] font-bold uppercase text-slate-400 block">
                        Contato de Emergência:
                      </span>
                      <span className="font-bold text-slate-800">
                        {patient.emergencyContact.name}{' '}
                        {patient.emergencyContact.relationship && `(${patient.emergencyContact.relationship})`}
                      </span>
                      <span className="text-slate-500 block">{patient.emergencyContact.phone}</span>
                    </div>

                    {patient.emergencyContact.phone && (
                      <button
                        onClick={handleOpenEmergencyWhatsApp}
                        className="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 text-[11px] font-bold flex items-center gap-1"
                      >
                        <MessageCircle className="w-3 h-3 text-emerald-600" />
                        Avisar
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* Alergias Medicamentosas */}
              <div className="p-3.5 rounded-2xl bg-rose-50/80 border border-rose-200 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-rose-900">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                  <span>Alergias Medicamentosas:</span>
                </div>
                {patient.allergies.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {patient.allergies.map((allergy, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-600 text-white shadow-xs"
                      >
                        ⚠️ {allergy}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-rose-700 italic">Nenhuma alergia relatada.</p>
                )}
              </div>

              {/* Doenças Sistêmicas & Alertas */}
              <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-amber-900">
                  <HeartPulse className="w-3.5 h-3.5 text-amber-600" />
                  <span>Doenças Sistêmicas & Risco Clínico:</span>
                </div>
                {patient.medicalAlerts.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {patient.medicalAlerts.map((dis, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500 text-white shadow-xs"
                      >
                        {dis}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-amber-800 italic">Sem doenças sistêmicas registradas.</p>
                )}
              </div>

              {/* Medicamentos & Alerta de Anticoagulantes */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-slate-800">
                  <Pill className="w-3.5 h-3.5 text-teal-600" />
                  <span>Medicamentos de Uso Contínuo:</span>
                </div>
                <p className="text-slate-700">
                  {patient.currentMedications || gh?.continuousMedications || 'Nenhum medicamento contínuo informado.'}
                </p>

                {gh?.hasAnticoagulantsOrBisphosphonates && (
                  <div className="p-2 rounded-xl bg-rose-100 text-rose-900 font-bold border border-rose-300 text-[11px] flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-700 shrink-0" />
                    <span>Paciente faz uso de Anticoagulantes ou Bifosfonatos. Prevenir hemorragia e osteonecrose.</span>
                  </div>
                )}
              </div>

              {/* Hábitos: Fumo, Álcool, Cicatrização */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">
                    Tabagismo:
                  </span>
                  <span className="font-semibold text-slate-800 capitalize">
                    {gh?.habitsSmoking === 'nao' ? 'Não fuma' : gh?.habitsSmoking === 'fumante' ? 'Fumante ativo' : 'Ex-fumante'}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">
                    Consumo de Álcool:
                  </span>
                  <span className="font-semibold text-slate-800 capitalize">
                    {gh?.habitsAlcohol === 'nao' ? 'Não consome' : gh?.habitsAlcohol || 'Socialmente'}
                  </span>
                </div>
              </div>

              {gh?.healingOrBleedingIssues && (
                <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                  <span className="font-bold block mb-0.5">
                    ⚠️ Histórico de Cicatrização / Hemorragia / Lipotimia:
                  </span>
                  <p>{gh.healingBleedingNotes || 'Paciente relata episódios anteriores em consultório.'}</p>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ANAMNESE ODONTOLÓGICA (HISTÓRICO BUCAL) */}
          {activeTab === 'odonto' && (
            <div className="space-y-3 animate-in fade-in duration-150 text-xs">
              {/* Queixa Principal */}
              <div className="p-3.5 rounded-2xl bg-teal-50 border border-teal-200 text-teal-950">
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 block mb-1">
                  Queixa Principal do Paciente:
                </span>
                <p className="font-semibold text-sm">
                  "{dh?.chiefComplaint || patient.notes || 'Consulta de rotina / avaliação geral.'}"
                </p>
              </div>

              {/* Última Consulta e Higiene */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">
                    Última Visita ao Dentista:
                  </span>
                  <span className="font-bold text-slate-800">{dh?.lastDentalVisit || '6 a 12 meses'}</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">
                    Higiene Bucal Diária:
                  </span>
                  <span className="font-semibold text-slate-800 block">
                    Escovação: {dh?.brushingFrequency || '3x ao dia'}
                  </span>
                  <span className="text-slate-600 block">
                    Fio dental: {dh?.flossFrequency || 'Diariamente'}
                  </span>
                </div>
              </div>

              {/* Sensibilidade Dental & Sangramento */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800">Sensibilidade Dental:</span>
                  <div className="flex gap-1.5">
                    {dh?.toothSensitivity?.cold && (
                      <span className="px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 text-[10px] font-bold">
                        Frio
                      </span>
                    )}
                    {dh?.toothSensitivity?.hot && (
                      <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-bold">
                        Calor
                      </span>
                    )}
                    {dh?.toothSensitivity?.sweet && (
                      <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                        Doce
                      </span>
                    )}
                    {!dh?.toothSensitivity?.cold && !dh?.toothSensitivity?.hot && !dh?.toothSensitivity?.sweet && (
                      <span className="text-slate-500">Sem sensibilidade</span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                  <span className="font-bold text-slate-800">Sangramento Gengival:</span>
                  <span className="capitalize font-semibold text-slate-700">
                    {dh?.gumBleeding === 'ao_escovar'
                      ? 'Ao escovar / passar fio'
                      : dh?.gumBleeding === 'espontaneo'
                      ? 'Espontâneo (Atenção Periodontal)'
                      : 'Nenhum'}
                  </span>
                </div>
              </div>

              {/* ATM e Hábitos Parafuncionais */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
                <span className="font-bold text-slate-800 block">ATM e Articulação:</span>
                <p className="text-slate-700">
                  {dh?.tmjOrBruxism?.jawPainOrClicking ? '⚠️ Apresenta dor ou estalos na mandíbula/ATM.' : '• Sem estalos ou dor na ATM.'}
                </p>
                <p className="text-slate-700">
                  {dh?.tmjOrBruxism?.bruxismOrClenching ? '⚠️ Relato de bruxismo ou apertamento dental.' : '• Sem queixas de bruxismo.'}
                </p>
              </div>

              {/* Anestesia Local */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-bold uppercase text-slate-400 block mb-0.5">
                  Experiência Prévia c/ Anestesia Local:
                </span>
                <p className="text-slate-800 font-medium">
                  {dh?.previousAnestheticReactions || 'Sem intercorrências conhecidas.'}
                </p>
              </div>

              {/* Dentes Pendentes no Odontograma */}
              {treatedOrNeededTeeth.length > 0 && (
                <div className="p-3 rounded-2xl bg-teal-50 border border-teal-200">
                  <span className="font-bold text-teal-900 block mb-1">
                    Dentes com Tratamento no Odontograma ({treatedOrNeededTeeth.length}):
                  </span>
                  <div className="space-y-1">
                    {treatedOrNeededTeeth.map((t) => (
                      <div key={t.toothNumber} className="flex items-center justify-between">
                        <span className="font-semibold text-teal-800">
                          Dente {t.toothNumber}: {t.conditionTitle || 'Tratamento Necessário'}
                        </span>
                        <span className="text-[10px] text-teal-600">{t.notes}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: EVOLUÇÕES CLÍNICAS CONTÍNUAS */}
          {activeTab === 'evolucoes' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                    Evoluções Clínicas ({patientEvolutions.length})
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Histórico cronológico de condutas e anotações da Dra. Pâmela
                  </p>
                </div>
                <button
                  onClick={() => setIsEvolutionModalOpen(true)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Nova Anotação</span>
                </button>
              </div>

              {patientEvolutions.length === 0 ? (
                <div className="p-6 rounded-2xl border border-dashed border-slate-200 text-center bg-slate-50/50 space-y-2">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs text-slate-600 font-medium">
                    Nenhuma evolução clínica registrada ainda para {patient.name}.
                  </p>
                  <button
                    onClick={() => setIsEvolutionModalOpen(true)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-50 text-teal-800 border border-teal-200 text-xs font-bold hover:bg-teal-100 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Registrar primeira evolução do dia</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {patientEvolutions.map((evo) => (
                    <div
                      key={evo.id}
                      className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2 text-xs"
                    >
                      {/* Top bar with date and tags */}
                      <div className="flex items-center justify-between flex-wrap gap-1.5 border-b border-slate-100 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-slate-900 flex items-center gap-1 text-xs">
                            <Calendar className="w-3.5 h-3.5 text-teal-600" />
                            {formatDateBR(evo.date)} às {evo.time}
                          </span>
                          <span className="px-2 py-0.5 rounded-md bg-teal-50 text-teal-800 font-bold text-[10px]">
                            {evo.author}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          {evo.toothNumber && (
                            <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-bold text-[10px]">
                              Dente {evo.toothNumber}
                            </span>
                          )}
                          <button
                            onClick={() => {
                              if (confirm('Deseja excluir esta anotação clínica?')) {
                                deleteClinicalEvolution(patient.id, evo.id);
                              }
                            }}
                            className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Excluir anotação"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Procedimento */}
                      {evo.procedureDone && (
                        <div className="font-bold text-slate-800 flex items-center gap-1.5">
                          <Stethoscope className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                          <span>{evo.procedureDone}</span>
                        </div>
                      )}

                      {/* Anestésico */}
                      {evo.anestheticUsed && (
                        <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 text-[11px] text-slate-600 flex items-center gap-1.5">
                          <Pill className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                          <span><strong>Anestésico:</strong> {evo.anestheticUsed}</span>
                        </div>
                      )}

                      {/* Content / Conduta */}
                      <div className="text-slate-700 leading-relaxed whitespace-pre-wrap bg-slate-50/70 p-2.5 rounded-xl border border-slate-100">
                        {evo.content}
                      </div>

                      {/* Próxima sessão */}
                      {evo.nextSessionPlan && (
                        <div className="pt-1 text-[11px] text-slate-600 flex items-start gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                          <span><strong>Próxima conduta:</strong> {evo.nextSessionPlan}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: HISTÓRICO DE ATENDIMENTOS */}
          {activeTab === 'consultas' && (
            <div className="space-y-2.5 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Consultas ({patientAppointments.length})
                </h4>
                <button
                  type="button"
                  onClick={() => openAppointmentModal(undefined, undefined, patient.id)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold shadow-xs transition-all active:scale-95"
                >
                  <Plus className="w-3 h-3" />
                  <span>Nova Consulta</span>
                </button>
              </div>
              {patientAppointments.length === 0 ? (
                <p className="text-xs text-slate-400 italic">Nenhum atendimento registrado ainda.</p>
              ) : (
                <div className="space-y-2">
                  {patientAppointments.map((apt) => (
                    <div
                      key={apt.id}
                      className="p-3 rounded-xl bg-white border border-slate-200/80 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-800">{apt.procedure}</span>
                        <p className="text-slate-500">
                          {formatDateBR(apt.date)} às {apt.time} ({apt.durationMinutes}m)
                        </p>
                      </div>
                      <span className="capitalize px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700">
                        {apt.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: RECEITUÁRIOS & ATESTADOS DO PACIENTE */}
          {activeTab === 'documentos' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <FileCheck className="w-3.5 h-3.5 text-teal-600" />
                  <span>Documentos Emitidos ({patientDocuments.length})</span>
                </h4>
                <button
                  onClick={() => openDocumentModal({ patientId: patient.id })}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold shadow-xs transition-all active:scale-95"
                >
                  <Plus className="w-3 h-3" />
                  <span>Novo Documento</span>
                </button>
              </div>

              {patientDocuments.length === 0 ? (
                <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50">
                  <FileText className="w-7 h-7 text-slate-300 mx-auto mb-1.5" />
                  <p className="text-xs font-bold text-slate-600">
                    Nenhum receituário ou atestado emitido para {patient.name}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5 mb-3">
                    Gere prescrições odontológicas ou atestados de repouso/comparecimento em segundos.
                  </p>
                  <button
                    onClick={() => openDocumentModal({ patientId: patient.id })}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-600 text-white text-xs font-bold shadow-xs hover:bg-teal-700 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Emitir Primeiro Documento</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  {patientDocuments.map((doc) => {
                    const isRx = doc.type === 'receita';
                    const rx = isRx ? (doc as PrescriptionDocument) : null;
                    const cert = !isRx ? (doc as CertificateDocument) : null;

                    const handleSendDocWhatsApp = () => {
                      let text = '';
                      if (isRx && rx) {
                        text = formatPrescriptionWhatsAppMessage(
                          rx.patientName,
                          rx.medicines,
                          rx.date,
                          rx.generalInstructions
                        );
                      } else if (cert) {
                        text = formatCertificateWhatsAppMessage({
                          certificateType: cert.certificateType,
                          patientName: cert.patientName,
                          patientCpf: cert.patientCpf,
                          date: cert.date,
                          startTime: cert.startTime,
                          endTime: cert.endTime,
                          restDays: cert.restDays,
                          startDate: cert.startDate,
                          cid: cert.cid,
                          reason: cert.reason,
                          notes: cert.notes,
                        });
                      }
                      window.open(buildWhatsAppUrl(patient.phone, text), '_blank');
                    };

                    return (
                      <div
                        key={doc.id}
                        className="p-3 rounded-2xl bg-slate-50/80 border border-slate-200 hover:border-teal-300 transition-all space-y-2"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span
                              className={`p-1.5 rounded-xl text-xs font-black ${
                                isRx ? 'bg-teal-100 text-teal-800' : 'bg-sky-100 text-sky-800'
                              }`}
                            >
                              {isRx ? <FileText className="w-4 h-4" /> : <FileCheck className="w-4 h-4" />}
                            </span>
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-bold text-slate-900">
                                  {isRx
                                    ? 'Receituário Odontológico'
                                    : cert?.certificateType === 'comparecimento'
                                    ? 'Atestado de Comparecimento'
                                    : 'Atestado de Repouso'}
                                </span>
                                <span
                                  className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded-md ${
                                    isRx ? 'bg-teal-100 text-teal-800' : 'bg-sky-100 text-sky-800'
                                  }`}
                                >
                                  {isRx ? 'Prescrição' : 'Atestado'}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500">
                                Emitido em: {formatDateBR(doc.date)}
                              </p>
                            </div>
                          </div>

                          {/* Action icons */}
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => openDocumentModal({ patientId: patient.id, documentToView: doc })}
                              className="p-1.5 rounded-lg text-slate-600 hover:text-teal-700 hover:bg-white transition-colors"
                              title="Visualizar documento timbrado / Imprimir"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={handleSendDocWhatsApp}
                              className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 transition-colors"
                              title="Enviar no WhatsApp do Paciente"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => deleteDocument(doc.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                              title="Excluir documento"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Details snippet */}
                        <div className="text-[11px] text-slate-600 bg-white p-2 rounded-xl border border-slate-100">
                          {isRx && rx && (
                            <p>
                              <strong>Medicações ({rx.medicines.length}): </strong>
                              {rx.medicines.map((m) => m.name).join(', ')}
                            </p>
                          )}
                          {!isRx && cert && (
                            <p>
                              <strong>
                                {cert.certificateType === 'comparecimento'
                                  ? `Comparecimento: ${cert.startTime || ''} às ${cert.endTime || ''}`
                                  : `Repouso: ${cert.restDays || 1} dias`}
                              </strong>
                              {cert.reason ? ` • ${cert.reason}` : ''}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: FOTOS CLÍNICAS E RADIOGRAFIAS (Antes & Depois) */}
          {activeTab === 'fotos' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <ClinicalPhotoGallery patient={patient} />
            </div>
          )}

          {/* TAB 7: TERMOS DE CONSENTIMENTO (TCLE) */}
          {activeTab === 'termos' && (
            <div className="space-y-3 animate-in fade-in duration-150">
              <ConsentFormsList patient={patient} />
            </div>
          )}
        </div>

        {/* Footer Actions (pb-safe for iPhone) */}
        <div className="p-4 pb-safe sm:pb-4 border-t border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <button
            onClick={handleDelete}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 active:scale-95 rounded-xl transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Excluir</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(patient)}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 active:scale-95 rounded-xl transition-all"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Editar</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-95 rounded-xl transition-all"
            >
              Fechar
            </button>
          </div>
        </div>
      </div>

      {/* Clinical Evolution Modal */}
      <ClinicalEvolutionModal
        isOpen={isEvolutionModalOpen}
        onClose={() => setIsEvolutionModalOpen(false)}
        patientId={patient.id}
        patientName={patient.name}
        onSave={(data) => addClinicalEvolution(patient.id, data)}
      />
    </div>
  );
};
