import React, { useState, useRef, useEffect } from 'react';
import {
  FileCheck,
  X,
  PenTool,
  RotateCcw,
  CheckCircle2,
  Printer,
  Share2,
  AlertTriangle,
  Calendar,
  User,
  ShieldCheck,
  FileText,
} from 'lucide-react';
import { ConsentForm, ConsentFormCategory, Patient } from '../../types';
import { useApp } from '../../context/AppContext';
import { getTodayString } from '../../data/mockData';
import { formatDateBR, buildWhatsAppUrl } from '../../utils/masks';

interface ConsentFormModalProps {
  patient: Patient;
  isOpen: boolean;
  onClose: () => void;
  formToView?: ConsentForm | null;
}

interface TemplateDef {
  category: ConsentFormCategory;
  title: string;
  defaultText: string;
}

const CONSENT_TEMPLATES: TemplateDef[] = [
  {
    category: 'clareamento',
    title: 'Termo de Consentimento para Clareamento Dental',
    defaultText: `Eu declaro que fui informado(a) pela Dra. Pâmela sobre a indicação, técnica e objetivos do tratamento de clareamento dental.

Compreendo que:
1. O clareamento altera a tonalidade dos dentes naturais e NÃO altera a cor de restaurações prévias, resinas ou próteses cerâmicas, podendo ser necessária a troca destas após a conclusão do tratamento.
2. É comum a ocorrência de sensibilidade dentinária de grau leve a moderado durante o tratamento, que costuma cessar após a finalização do protocolo.
3. Devo abster-me ou reduzir drasticamente o consumo de alimentos e bebidas altamente pigmentadas (café, vinho tinto, refrigerantes escuros, açaí, molho de tomate) e evitar tabaco durante todo o período clareador.
4. A durabilidade do resultado estético varia conforme meus hábitos alimentares e de higiene bucal, exigindo manutenções periódicas.

Estou plenamente ciente das orientações e autorizo a realização do procedimento.`,
  },
  {
    category: 'extracao_siso',
    title: 'Termo de Consentimento para Exodontia / Cirurgia de Siso',
    defaultText: `Declaro que fui devidamente esclarecido(a) pela Dra. Pâmela sobre a necessidade clínica da realização da cirurgia para extração dentária (exodontia).

Fui alertado(a) e concordo com os seguintes aspectos inerentes ao ato cirúrgico:
1. A intervenção exige anestesia local, da qual relatei todo meu histórico médico e alérgico na anamnese.
2. É esperado processo inflamatório pós-operatório (inchaço/edema facial, dor controlada por analgésicos e eventual dificuldade na abertura bucal/trismo temporário).
3. Em dentes inclusos/semi-inclusos inferiores próximos ao nervo alveolar inferior ou lingual, existe risco de parestesia transitória (sensação de formigamento ou dormência no lábio/língua), que em raras exceções pode ser prolongada.
4. Comprometo-me a seguir rigorosamente as prescrições medicamentosas, fazer repouso físico nas primeiras 48h, manter alimentação fria/pastosa e evitar bochechos vigorosos e esforço físico.

Autorizo o ato cirúrgico e eventuais condutas complementares necessárias durante o procedimento.`,
  },
  {
    category: 'endodontia',
    title: 'Termo de Consentimento para Tratamento Endodôntico (Canal)',
    defaultText: `Declaro estar ciente de que o tratamento de canal (endodontia) consiste na remoção da polpa dentária inflamada ou necrosada, desinfecção e obturação hermética dos condutos radiculares com material biocompatível.

Compreendo que:
1. O procedimento visa salvar o elemento dentário da extração, com alto índice de sucesso, porém anatomias radiculares atípicas, canais calcificados ou infecções crônicas prévias podem requerer complementações (retratamento ou cirurgia parendodôntica).
2. Pode haver dor ou sensibilidade mastigatória reflexa nos primeiros dias subsequentes, controlável com analgésicos/anti-inflamatórios prescritos.
3. O dente despolpado torna-se mais frágil até a confecção da restauração definitiva ou coroa protética. O atraso na restauração final pode acarretar fratura dental irreparável ou recontaminação dos canais.

Autorizo a realização do tratamento endodôntico.`,
  },
  {
    category: 'implante_protese',
    title: 'Termo de Consentimento para Implantes Dentários e Prótese',
    defaultText: `Declaro ter recebido da Dra. Pâmela todas as explicações técnicas sobre o planejamento e a instalação de implantes dentários osseointegráveis e reabilitação protética.

Fui informado(a) que:
1. A osseointegração é um processo biológico de cicatrização do osso ao redor do titânio, que demanda período de cicatrização e repouso mastigatório.
2. Fatores como tabagismo, higiene bucal deficitária, bruxismo descontrolado ou doenças sistêmicas não compensadas aumentam o risco de insucesso.
3. Comprometo-me a comparecer às consultas periódicas de manutenção e controle radiográfico, essenciais para a longevidade dos implantes.

Autorizo o procedimento cirúrgico-protético.`,
  },
  {
    category: 'restauracao_estetica',
    title: 'Termo de Consentimento para Restaurações Estéticas e Facetas',
    defaultText: `Declaro que aprovei o planejamento estético proposto pela Dra. Pâmela para restaurações em resina composta / facetas estéticas.

Fui informado(a) que:
1. Podem ocorrer ligeiras alterações de sensibilidade transitória pós-operatória.
2. Restaurações estéticas necessitam de polimento e revisões periódicas para conservação de brilho e integridade marginal.
3. Hábitos parafuncionais (roer unhas, morder objetos duros, bruxismo sem placa) podem causar fraturas ou lascas, cuja prevenção depende de minha cooperação.

Autorizo a execução das restaurações.`,
  },
  {
    category: 'geral',
    title: 'Termo Geral de Consentimento e Plano de Tratamento Odontológico',
    defaultText: `Declaro que respondi com total sinceridade à ficha de anamnese médica e odontológica, sem ocultar informações sobre alergias, cirurgias, medicamentos ou estado de saúde geral.

Autorizo a Dra. Pâmela a:
1. Realizar exames clínicos, radiografias diagnósticas e registros fotográficos estritamente para documentação do prontuário.
2. Administrar anestésicos locais necessários ao alívio da dor e conforto clínico.
3. Executar o plano de tratamento apresentado, discutido e aceito por mim.

Estou ciente de que posso solicitar esclarecimentos adicionais a qualquer momento durante meu tratamento.`,
  },
];

export const ConsentFormModal: React.FC<ConsentFormModalProps> = ({
  patient,
  isOpen,
  onClose,
  formToView,
}) => {
  const { addConsentForm, showToast } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<ConsentFormCategory>('clareamento');
  const [customTitle, setCustomTitle] = useState('');
  const [customText, setCustomText] = useState('');
  const [signedByName, setSignedByName] = useState(patient.name);
  const [responsibleName, setResponsibleName] = useState('');
  const [isViewingSaved, setIsViewingSaved] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Initialize template text when category changes
  useEffect(() => {
    if (formToView) {
      setIsViewingSaved(true);
      setCustomTitle(formToView.title);
      setCustomText(formToView.content);
      setSelectedCategory(formToView.category);
      setSignedByName(formToView.signedByName);
      setResponsibleName(formToView.responsibleName || '');
    } else {
      setIsViewingSaved(false);
      const tmpl = CONSENT_TEMPLATES.find((t) => t.category === selectedCategory) || CONSENT_TEMPLATES[0];
      setCustomTitle(tmpl.title);
      setCustomText(tmpl.defaultText);
      setSignedByName(patient.name);
      setResponsibleName('');
      clearSignature();
    }
  }, [selectedCategory, formToView, isOpen, patient]);

  // Canvas drawing handlers
  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    if ('touches' in e && e.touches.length > 0) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    } else if ('clientX' in e) {
      return {
        x: (e.clientX - rect.left) * scaleX,
        y: (e.clientY - rect.top) * scaleY,
      };
    }
    return { x: 0, y: 0 };
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (isViewingSaved) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#0f766e'; // teal-700
    setIsDrawing(true);
    setHasSignature(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing || isViewingSaved) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    e.preventDefault();
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasSignature) {
      showToast('Por favor, solicite a assinatura do paciente na tela antes de salvar.', 'error');
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const signatureDataUrl = canvas.toDataURL('image/png');

    const now = new Date();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const signedDate = `${getTodayString()} ${timeStr}`;

    addConsentForm(patient.id, {
      patientId: patient.id,
      patientName: patient.name,
      patientCpf: patient.cpf || 'Não informado',
      category: selectedCategory,
      title: customTitle.trim() || 'Termo de Consentimento',
      content: customText.trim(),
      signatureDataUrl,
      signedDate,
      signedByName: signedByName.trim() || patient.name,
      responsibleName: responsibleName.trim() || undefined,
      professionalName: 'Dra. Pâmela Meneghetti',
      professionalCro: 'CRO/SP 123.456',
    });

    onClose();
  };

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsAppShare = () => {
    const form = formToView;
    const title = form ? form.title : customTitle;
    const text = `Olá ${patient.name}! Segue a confirmação do seu ${title} assinado digitalmente na clínica da Dra. Pâmela. Os termos acordados estão arquivados em seu prontuário clínico oficial.`;
    window.open(buildWhatsAppUrl(patient.phone, text), '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-100 flex flex-col max-h-[94vh] overflow-hidden animate-in slide-in-from-bottom-6">
        {/* Modal Top Header */}
        <div className="px-5 py-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-teal-100 text-teal-800 flex items-center justify-center font-bold shadow-xs">
              <FileCheck className="w-5 h-5 text-teal-700" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900 leading-tight">
                {isViewingSaved ? 'Termo de Consentimento Assinado' : 'Novo Termo de Consentimento (TCLE)'}
              </h3>
              <p className="text-xs text-slate-500">
                Paciente: <strong className="text-slate-700">{patient.name}</strong> • CPF: {patient.cpf || 'Sem CPF'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {isViewingSaved && (
              <>
                <button
                  type="button"
                  onClick={handlePrint}
                  className="p-2 text-slate-500 hover:text-teal-700 hover:bg-slate-200/50 rounded-full transition-colors"
                  title="Imprimir documento"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleWhatsAppShare}
                  className="p-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-full transition-colors"
                  title="Enviar confirmação no WhatsApp"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Document Body */}
        <form onSubmit={handleSaveForm} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          {/* Template Selection Pills (Only when creating new) */}
          {!isViewingSaved && (
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Selecione o Modelo de Procedimento *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                {CONSENT_TEMPLATES.map((tmpl) => (
                  <button
                    key={tmpl.category}
                    type="button"
                    onClick={() => setSelectedCategory(tmpl.category)}
                    className={`px-3 py-2 rounded-xl text-left border transition-all ${
                      selectedCategory === tmpl.category
                        ? 'bg-teal-700 text-white border-teal-700 font-bold shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100 font-medium'
                    }`}
                  >
                    <span className="block truncate">{tmpl.title.replace('Termo de Consentimento para ', '')}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Form Header Info Card */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400">Profissional Responsável</span>
              <p className="font-bold text-slate-800 text-xs">Dra. Pâmela Meneghetti • CRO/SP 123.456</p>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400">Data e Local</span>
              <p className="font-medium text-slate-700 text-xs">São Paulo - SP, {formatDateBR(formToView?.signedDate?.split(' ')[0] || getTodayString())}</p>
            </div>
          </div>

          {/* Document Content / Term Text */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-700">
                Texto do Consentimento Livre e Esclarecido
              </label>
              {!isViewingSaved && (
                <span className="text-[10px] text-teal-700 font-semibold">
                  (Personalizável conforme o caso clínico)
                </span>
              )}
            </div>
            {isViewingSaved ? (
              <div className="p-4 rounded-2xl bg-white border border-slate-200 text-slate-700 leading-relaxed whitespace-pre-wrap font-sans text-xs">
                {customText}
              </div>
            ) : (
              <textarea
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                rows={9}
                className="w-full p-3.5 rounded-2xl border border-slate-200 text-xs leading-relaxed text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 font-sans"
                required
              />
            )}
          </div>

          {/* Signer Info inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Nome do Assinante (Paciente ou Responsável) *
              </label>
              <input
                type="text"
                value={signedByName}
                onChange={(e) => setSignedByName(e.target.value)}
                disabled={isViewingSaved}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none disabled:bg-slate-50 disabled:text-slate-600"
                required
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Nome do Responsável Legal (Se menor de idade ou incapaz)
              </label>
              <input
                type="text"
                value={responsibleName}
                onChange={(e) => setResponsibleName(e.target.value)}
                disabled={isViewingSaved}
                placeholder="Opcional"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none disabled:bg-slate-50 disabled:text-slate-600"
              />
            </div>
          </div>

          {/* SIGNATURE SECTION */}
          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                <PenTool className="w-3.5 h-3.5 text-teal-700" />
                <span>Assinatura Digital do Paciente *</span>
              </label>
              {!isViewingSaved && (
                <button
                  type="button"
                  onClick={clearSignature}
                  className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-rose-600 font-semibold"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Limpar</span>
                </button>
              )}
            </div>

            {isViewingSaved && formToView?.signatureDataUrl ? (
              <div className="p-4 bg-teal-50/40 rounded-2xl border border-teal-200 flex flex-col items-center justify-center">
                <img
                  src={formToView.signatureDataUrl}
                  alt="Assinatura Digital"
                  className="max-h-24 object-contain"
                />
                <div className="mt-2 text-center border-t border-teal-200/80 pt-1.5 w-64">
                  <p className="font-bold text-xs text-slate-800">{formToView.signedByName}</p>
                  <p className="text-[10px] text-slate-500">
                    CPF: {patient.cpf || 'Não informado'} • Assinado em {formToView.signedDate}
                  </p>
                  <span className="inline-flex items-center gap-1 text-[9px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full mt-1">
                    <ShieldCheck className="w-3 h-3" /> Assinatura Digital Verificada
                  </span>
                </div>
              </div>
            ) : (
              <div className="relative rounded-2xl overflow-hidden border-2 border-dashed border-teal-400 bg-slate-50/70">
                <canvas
                  ref={canvasRef}
                  width={600}
                  height={160}
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  onTouchStart={startDrawing}
                  onTouchMove={draw}
                  onTouchEnd={stopDrawing}
                  className="w-full h-36 bg-white cursor-crosshair touch-none"
                />
                {!hasSignature && (
                  <div className="absolute inset-0 pointer-events-none flex items-center justify-center text-slate-400">
                    <p className="text-xs font-medium flex items-center gap-1.5">
                      <PenTool className="w-4 h-4 text-slate-400" />
                      Assine com o dedo ou caneta touch aqui
                    </p>
                  </div>
                )}
                <div className="px-3 py-1.5 bg-slate-100/90 border-t border-slate-200 text-[10px] text-slate-500 flex items-center justify-between">
                  <span>Assinatura eletrônica válida nos termos do prontuário odontológico</span>
                  {hasSignature && (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Assinado
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Bottom Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-all"
            >
              {isViewingSaved ? 'Fechar' : 'Cancelar'}
            </button>

            {!isViewingSaved && (
              <button
                type="submit"
                disabled={!hasSignature}
                className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold active:scale-95 transition-all shadow-md shadow-teal-700/20"
              >
                Registrar e Salvar Termo no Prontuário
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
