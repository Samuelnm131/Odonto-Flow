import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Plus,
  Trash2,
  Maximize2,
  X,
  Calendar,
  Sparkles,
  Columns,
  Eye,
  FileImage,
  Share2,
  Stethoscope,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { ClinicalPhoto, ClinicalPhotoCategory, Patient } from '../../types';
import { useApp } from '../../context/AppContext';
import { getTodayString } from '../../data/mockData';
import { formatDateBR, buildWhatsAppUrl } from '../../utils/masks';

interface ClinicalPhotoGalleryProps {
  patient: Patient;
}

const CATEGORY_LABELS: Record<ClinicalPhotoCategory, { label: string; badge: string }> = {
  antes: { label: 'Inicial (Antes)', badge: 'bg-rose-100 text-rose-800 border-rose-200' },
  depois: { label: 'Final (Depois)', badge: 'bg-teal-100 text-teal-800 border-teal-200' },
  evolucao: { label: 'Evolução', badge: 'bg-sky-100 text-sky-800 border-sky-200' },
  radiografia: { label: 'Radiografia / Rx', badge: 'bg-purple-100 text-purple-800 border-purple-200' },
  outro: { label: 'Outro', badge: 'bg-slate-100 text-slate-800 border-slate-200' },
};

export const ClinicalPhotoGallery: React.FC<ClinicalPhotoGalleryProps> = ({ patient }) => {
  const { getPatientPhotos, addPhoto, deletePhoto, showToast } = useApp();
  const photos = getPatientPhotos(patient.id);

  const [activeFilter, setActiveFilter] = useState<'todos' | ClinicalPhotoCategory>('todos');
  const [selectedPhotoForView, setSelectedPhotoForView] = useState<ClinicalPhoto | null>(null);
  const [isAddPhotoOpen, setIsAddPhotoOpen] = useState(false);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);

  // Add photo form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<ClinicalPhotoCategory>('antes');
  const [newToothNumber, setNewToothNumber] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [newImageData, setNewImageData] = useState<string>('');
  const [newDate, setNewDate] = useState(getTodayString());
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Comparison state
  const antesPhotos = photos.filter((p) => p.category === 'antes');
  const depoisPhotos = photos.filter((p) => p.category === 'depois');
  const [selectedAntesId, setSelectedAntesId] = useState<string>(antesPhotos[0]?.id || '');
  const [selectedDepoisId, setSelectedDepoisId] = useState<string>(depoisPhotos[0]?.id || '');
  const [comparisonSlider, setComparisonSlider] = useState<number>(50);

  const filteredPhotos = photos.filter((p) => {
    if (activeFilter === 'todos') return true;
    return p.category === activeFilter;
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Por favor, selecione um arquivo de imagem válido.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setNewImageData(reader.result);
        if (!newTitle) {
          const defaultTitles: Record<ClinicalPhotoCategory, string> = {
            antes: `Foto Inicial - Dente / Sorriso`,
            depois: `Resultado Final - Pós Tratamento`,
            evolucao: `Evolução Clínica`,
            radiografia: `Radiografia Odontológica`,
            outro: `Registro Fotográfico`,
          };
          setNewTitle(defaultTitles[newCategory]);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSavePhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newImageData) {
      showToast('Por favor, tire uma foto ou selecione uma imagem do aparelho.', 'error');
      return;
    }

    addPhoto(patient.id, {
      patientId: patient.id,
      title: newTitle.trim() || 'Registro Clínico',
      category: newCategory,
      imageData: newImageData,
      date: newDate,
      toothNumber: newToothNumber ? Number(newToothNumber) : undefined,
      notes: newNotes.trim() || undefined,
    });

    // Reset form
    setNewTitle('');
    setNewCategory('antes');
    setNewToothNumber('');
    setNewNotes('');
    setNewImageData('');
    setIsAddPhotoOpen(false);
  };

  const handleShareOnWhatsApp = (photo: ClinicalPhoto) => {
    const text = `Olá ${patient.name}! Aqui está o registro fotográfico odontológico (${photo.title}) do seu tratamento na clínica da Dra. Pâmela realizado em ${formatDateBR(photo.date)}.`;
    window.open(buildWhatsAppUrl(patient.phone, text), '_blank');
  };

  const selectedAntes = antesPhotos.find((p) => p.id === selectedAntesId) || antesPhotos[0];
  const selectedDepois = depoisPhotos.find((p) => p.id === selectedDepoisId) || depoisPhotos[0];

  return (
    <div className="space-y-4">
      {/* Top Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
          {(['todos', 'antes', 'depois', 'radiografia', 'evolucao'] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveFilter(cat)}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold capitalize whitespace-nowrap transition-all ${
                activeFilter === cat
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat === 'todos' ? `Todas (${photos.length})` : cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {antesPhotos.length > 0 && depoisPhotos.length > 0 && (
            <button
              type="button"
              onClick={() => setIsComparisonOpen(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-800 border border-purple-200 text-xs font-bold transition-all active:scale-95 shadow-xs"
              title="Comparar Antes & Depois"
            >
              <Columns className="w-3.5 h-3.5 text-purple-600" />
              <span>Antes & Depois</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsAddPhotoOpen(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-all active:scale-95 shadow-xs"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Adicionar Foto / Rx</span>
          </button>
        </div>
      </div>

      {/* Photos Grid */}
      {filteredPhotos.length === 0 ? (
        <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50 space-y-3">
          <div className="w-12 h-12 rounded-full bg-teal-50 text-teal-600 flex items-center justify-center mx-auto">
            <Camera className="w-6 h-6" />
          </div>
          <div>
            <h5 className="text-xs font-bold text-slate-700">Nenhuma foto registrada nesta categoria</h5>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Tire fotos com a câmera do celular ou anexe exames e radiografias para acompanhar a evolução clínica de {patient.name}.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsAddPhotoOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Registrar Primeira Foto</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {filteredPhotos.map((photo) => {
            const catInfo = CATEGORY_LABELS[photo.category] || CATEGORY_LABELS.outro;
            return (
              <div
                key={photo.id}
                onClick={() => setSelectedPhotoForView(photo)}
                className="group relative bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md hover:border-teal-400 transition-all cursor-pointer flex flex-col"
              >
                {/* Image Container with aspect ratio */}
                <div className="relative aspect-4/3 w-full bg-slate-900 overflow-hidden flex items-center justify-center">
                  <img
                    src={photo.imageData}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-2">
                    <span className="text-[10px] text-white font-medium flex items-center gap-1">
                      <Maximize2 className="w-3 h-3" /> Ampliar
                    </span>
                  </div>

                  {/* Category Pill Tag */}
                  <span
                    className={`absolute top-2 left-2 px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider border shadow-xs ${catInfo.badge}`}
                  >
                    {catInfo.label}
                  </span>

                  {photo.toothNumber && (
                    <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-md text-[9px] font-bold bg-slate-900/80 text-white backdrop-blur-xs">
                      Dente {photo.toothNumber}
                    </span>
                  )}
                </div>

                {/* Details Bottom */}
                <div className="p-2.5 flex-1 flex flex-col justify-between">
                  <div>
                    <h6 className="text-xs font-bold text-slate-800 line-clamp-1 group-hover:text-teal-700 transition-colors">
                      {photo.title}
                    </h6>
                    {photo.notes && (
                      <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5 italic">
                        {photo.notes}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1.5 mt-1 border-t border-slate-100">
                    <span>{formatDateBR(photo.date)}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Excluir a foto "${photo.title}"?`)) {
                          deletePhoto(patient.id, photo.id);
                        }
                      }}
                      className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                      title="Excluir foto"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL 1: ADICIONAR NOVA FOTO */}
      {isAddPhotoOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[90vh] animate-in slide-in-from-bottom-6">
            <div className="px-5 py-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center">
                  <Camera className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Nova Foto Clínica / Exame</h4>
                  <p className="text-[11px] text-slate-500">Paciente: {patient.name}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddPhotoOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/60"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePhoto} className="p-5 overflow-y-auto space-y-4">
              {/* Image Preview / File Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Foto ou Radiografia *
                </label>
                {newImageData ? (
                  <div className="relative rounded-2xl overflow-hidden border border-teal-200 bg-slate-950 aspect-16/10 flex items-center justify-center">
                    <img src={newImageData} alt="Preview" className="w-full h-full object-contain" />
                    <button
                      type="button"
                      onClick={() => setNewImageData('')}
                      className="absolute top-2 right-2 p-1.5 rounded-full bg-slate-900/80 text-white hover:bg-rose-600 transition-colors"
                      title="Trocar imagem"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-teal-300 hover:border-teal-500 bg-teal-50/50 hover:bg-teal-50 rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-2"
                  >
                    <div className="w-12 h-12 rounded-full bg-white text-teal-700 shadow-xs flex items-center justify-center">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs font-bold text-teal-900">Clique para tirar foto ou selecionar</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">Suporta fotos da câmera, galeria ou arquivos de Raio-X</p>
                    </div>
                  </div>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </div>

              {/* Category Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Classificação da Foto *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {(['antes', 'depois', 'radiografia', 'evolucao'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setNewCategory(cat)}
                      className={`px-2 py-2 rounded-xl text-xs font-bold border transition-all text-center ${
                        newCategory === cat
                          ? 'bg-teal-700 text-white border-teal-700 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {cat === 'antes'
                        ? 'Inicial (Antes)'
                        : cat === 'depois'
                        ? 'Final (Depois)'
                        : cat === 'radiografia'
                        ? 'Radiografia'
                        : 'Evolução'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Title & Tooth */}
              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Título da Foto</label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Ex: Sorriso Inicial ou Molar 16"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Dente (Opcional)</label>
                  <input
                    type="number"
                    value={newToothNumber}
                    onChange={(e) => setNewToothNumber(e.target.value)}
                    placeholder="Ex: 11"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Date */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Data do Registro</label>
                <input
                  type="date"
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  required
                />
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Observações Clínicas (Opcional)</label>
                <textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Ex: Escala Vita A3.5, presença de trinca superficial, etc."
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddPhotoOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={!newImageData}
                  className="px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 rounded-xl transition-all shadow-xs active:scale-95"
                >
                  Salvar Foto no Prontuário
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: VISUALIZADOR DE FOTO EM ALTA RESOLUÇÃO */}
      {selectedPhotoForView && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-2xl bg-slate-900 text-white rounded-3xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col max-h-[92vh]">
            <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${CATEGORY_LABELS[selectedPhotoForView.category]?.badge}`}>
                    {CATEGORY_LABELS[selectedPhotoForView.category]?.label}
                  </span>
                  <h4 className="text-sm font-bold text-white">{selectedPhotoForView.title}</h4>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {formatDateBR(selectedPhotoForView.date)} • {patient.name} {selectedPhotoForView.toothNumber ? `• Dente ${selectedPhotoForView.toothNumber}` : ''}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPhotoForView(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Image Preview Container */}
            <div className="flex-1 bg-black p-2 flex items-center justify-center overflow-hidden min-h-[300px]">
              <img
                src={selectedPhotoForView.imageData}
                alt={selectedPhotoForView.title}
                className="max-h-[60vh] max-w-full object-contain rounded-lg shadow-lg"
              />
            </div>

            {/* Footer with notes and WhatsApp share */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs text-slate-300 max-w-md">
                {selectedPhotoForView.notes ? (
                  <p className="italic">"{selectedPhotoForView.notes}"</p>
                ) : (
                  <p className="text-slate-500">Sem anotações adicionais.</p>
                )}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => handleShareOnWhatsApp(selectedPhotoForView)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold active:scale-95 transition-all shadow-xs"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Enviar no WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedPhotoForView(null)}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: COMPARADOR ANTES & DEPOIS */}
      {isComparisonOpen && selectedAntes && selectedDepois && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-5 bg-slate-950/90 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-3xl bg-slate-900 text-white rounded-3xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col max-h-[94vh]">
            <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                  <Columns className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span>Comparador Clínico: Antes & Depois</span>
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  </h4>
                  <p className="text-[11px] text-slate-400">Paciente: {patient.name}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsComparisonOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Selectors for which Antes and which Depois */}
            <div className="px-5 py-2.5 bg-slate-800/80 border-b border-slate-700/60 grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-rose-400 mb-1">
                  Foto Inicial (Antes)
                </label>
                <select
                  value={selectedAntesId}
                  onChange={(e) => setSelectedAntesId(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  {antesPhotos.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} ({formatDateBR(p.date)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-teal-400 mb-1">
                  Foto Final (Depois)
                </label>
                <select
                  value={selectedDepoisId}
                  onChange={(e) => setSelectedDepoisId(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  {depoisPhotos.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} ({formatDateBR(p.date)})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Side-by-side split visualization */}
            <div className="p-4 bg-black flex-1 overflow-y-auto flex flex-col items-center justify-center min-h-[280px]">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl">
                {/* Left: Antes */}
                <div className="relative rounded-2xl overflow-hidden border-2 border-rose-600/60 bg-slate-950 flex flex-col">
                  <div className="absolute top-2 left-2 z-10 px-2 py-0.5 rounded-md text-[10px] font-black uppercase bg-rose-600 text-white shadow-xs">
                    Antes (Inicial)
                  </div>
                  <img
                    src={selectedAntes.imageData}
                    alt={selectedAntes.title}
                    className="w-full aspect-4/3 object-contain"
                  />
                  <div className="p-2 bg-slate-900 border-t border-slate-800 text-[11px] text-slate-300">
                    <p className="font-bold text-white line-clamp-1">{selectedAntes.title}</p>
                    <p className="text-[10px] text-slate-400">{formatDateBR(selectedAntes.date)}</p>
                  </div>
                </div>

                {/* Right: Depois */}
                <div className="relative rounded-2xl overflow-hidden border-2 border-teal-500/80 bg-slate-950 flex flex-col">
                  <div className="absolute top-2 left-2 z-10 px-2 py-0.5 rounded-md text-[10px] font-black uppercase bg-teal-600 text-white shadow-xs">
                    Depois (Resultado)
                  </div>
                  <img
                    src={selectedDepois.imageData}
                    alt={selectedDepois.title}
                    className="w-full aspect-4/3 object-contain"
                  />
                  <div className="p-2 bg-slate-900 border-t border-slate-800 text-[11px] text-slate-300">
                    <p className="font-bold text-white line-clamp-1">{selectedDepois.title}</p>
                    <p className="text-[10px] text-slate-400">{formatDateBR(selectedDepois.date)}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                Comparativo clínico demonstrativo da Dra. Pâmela
              </span>
              <button
                type="button"
                onClick={() => setIsComparisonOpen(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
              >
                Concluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
