import React, { useState } from 'react';
import { X, Calendar, Clock, Stethoscope, Save, Pill, CheckCircle2 } from 'lucide-react';
import { ClinicalEvolution } from '../../types';
import { getTodayString } from '../../data/mockData';

interface ClinicalEvolutionModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientId: string;
  patientName: string;
  onSave: (data: Omit<ClinicalEvolution, 'id' | 'patientId'>) => void;
}

const COMMON_ANESTHETICS = [
  'Lidocaína 2% c/ Epinefrina 1:100.000 (1 tubete)',
  'Articaína 4% c/ Epinefrina 1:100.000 (1 tubete)',
  'Mepivacaína 3% sem vasoconstritor (1 tubete)',
  'Prilocaína 3% c/ Felipressina',
  'Anestésico Tópico (Benzocaína 20%)',
  'Sem necessidade de anestésico',
];

export const ClinicalEvolutionModal: React.FC<ClinicalEvolutionModalProps> = ({
  isOpen,
  onClose,
  patientId,
  patientName,
  onSave,
}) => {
  const now = new Date();
  const currentHours = String(now.getHours()).padStart(2, '0');
  const currentMinutes = String(now.getMinutes()).padStart(2, '0');

  const [date, setDate] = useState(getTodayString());
  const [time, setTime] = useState(`${currentHours}:${currentMinutes}`);
  const [procedureDone, setProcedureDone] = useState('');
  const [toothNumber, setToothNumber] = useState('');
  const [anestheticUsed, setAnestheticUsed] = useState('');
  const [content, setContent] = useState('');
  const [nextSessionPlan, setNextSessionPlan] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    onSave({
      date,
      time,
      author: 'Dra. Pâmela',
      procedureDone: procedureDone.trim() || 'Atendimento Clínico',
      toothNumber: toothNumber ? Number(toothNumber) : undefined,
      anestheticUsed: anestheticUsed.trim() || undefined,
      content: content.trim(),
      nextSessionPlan: nextSessionPlan.trim() || undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-lg max-h-[92vh] sm:max-h-[88vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-teal-50/70 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 leading-tight">
                Evolução Clínica / Anotação da Consulta
              </h3>
              <p className="text-xs text-slate-600">
                Paciente: <strong className="text-teal-900">{patientName}</strong> • Dra. Pâmela
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Data e Horário */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Data do Atendimento *
              </label>
              <div className="relative">
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Horário *
              </label>
              <div className="relative">
                <input
                  type="time"
                  required
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>
          </div>

          {/* Procedimento e Dente */}
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Procedimento Realizado *
              </label>
              <input
                type="text"
                required
                value={procedureDone}
                onChange={(e) => setProcedureDone(e.target.value)}
                placeholder="Ex: Restauração Resina Oclusal, Exodontia..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Dente (FDI)
              </label>
              <input
                type="number"
                min="11"
                max="48"
                value={toothNumber}
                onChange={(e) => setToothNumber(e.target.value)}
                placeholder="Ex: 16"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-teal-500"
              />
            </div>
          </div>

          {/* Anestésico Utilizado */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
              <Pill className="w-3.5 h-3.5 text-teal-600" />
              <span>Anestésico Utilizado / Dosagem (Opcional)</span>
            </label>
            <input
              type="text"
              value={anestheticUsed}
              onChange={(e) => setAnestheticUsed(e.target.value)}
              placeholder="Ex: Articaína 4% c/ Epinefrina 1:100.000 (1 tubete)"
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-teal-500 mb-1.5"
            />
            {/* Quick anesthetic tags */}
            <div className="flex flex-wrap gap-1">
              {COMMON_ANESTHETICS.slice(0, 3).map((ane) => (
                <button
                  type="button"
                  key={ane}
                  onClick={() => setAnestheticUsed(ane)}
                  className="px-2 py-0.5 rounded-lg text-[10px] bg-slate-100 hover:bg-teal-50 text-slate-600 hover:text-teal-700 border border-slate-200/60 transition-colors"
                >
                  {ane.split('(')[0].trim()}
                </button>
              ))}
            </div>
          </div>

          {/* Relato da Evolução Clínica */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Conduta Clínica / Relato da Sessão *
            </label>
            <textarea
              required
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Descreva a técnica empregada, materiais utilizados (resina, adesivo, isolamento absoluto/relativo), resposta do paciente, ausência de intercorrências..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs text-slate-800 leading-relaxed focus:ring-2 focus:ring-teal-500 resize-none"
            />
          </div>

          {/* Próxima Conduta / Planejamento */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Plano para a Próxima Consulta (Opcional)
            </label>
            <input
              type="text"
              value={nextSessionPlan}
              onChange={(e) => setNextSessionPlan(e.target.value)}
              placeholder="Ex: Remoção de sutura em 7 dias, restauração do dente 24..."
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 font-medium focus:ring-2 focus:ring-teal-500"
            />
          </div>

          {/* Action buttons (respecting iOS safe area) */}
          <div className="pt-2 pb-safe sm:pb-0 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 active:scale-95 transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 shadow-md shadow-teal-600/20 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>Salvar Evolução</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
