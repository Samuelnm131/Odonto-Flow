import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Phone,
  Calendar,
  HeartPulse,
  Stethoscope,
  AlertCircle,
  Check,
  ChevronRight,
  ChevronLeft,
  ShieldAlert,
  Sparkles,
  Info,
  MessageCircle,
} from 'lucide-react';
import { Patient, EmergencyContact, GeneralHealthAnamnesis, DentalAnamnesis } from '../../types';
import { maskCPF, maskPhone, calculateAge, buildWhatsAppUrl } from '../../utils/masks';

interface PatientFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Patient, 'id' | 'createdAt'>) => void;
  initialData?: Patient | null;
}

const COMMON_ALLERGIES = [
  'Penicilina',
  'Dipirona',
  'AINEs (Anti-inflamatórios)',
  'Anestésico c/ vasoconstritor',
  'Látex',
  'Iodo',
];

const COMMON_SYSTEMIC_DISEASES = [
  'Hipertensão Arterial',
  'Diabetes Tipo 1',
  'Diabetes Tipo 2',
  'Cardiopatias / Problemas cardíacos',
  'Asma / Problemas respiratórios',
  'Doença Renal',
  'Doença Hepática',
  'Hipotireoidismo',
  'Ansiedade Odontológica / Fobia',
];

export const PatientFormModal: React.FC<PatientFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
}) => {
  // Wizard Step: 1 = Dados Pessoais, 2 = Saúde Geral, 3 = Histórico Odontológico
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);

  // ETAPA 1: Dados Pessoais & Contato
  const [name, setName] = useState('');
  const [cpf, setCpf] = useState('');
  const [phone, setPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState<'feminino' | 'masculino' | 'outro' | 'prefiro_nao_informar'>('feminino');
  const [profession, setProfession] = useState('');
  const [address, setAddress] = useState('');
  const [emergencyName, setEmergencyName] = useState('');
  const [emergencyPhone, setEmergencyPhone] = useState('');
  const [emergencyRelationship, setEmergencyRelationship] = useState('');

  // ETAPA 2: Anamnese de Saúde Geral (Risco Médico/Sistêmico)
  const [selectedAllergies, setSelectedAllergies] = useState<string[]>([]);
  const [customAllergy, setCustomAllergy] = useState('');
  const [selectedDiseases, setSelectedDiseases] = useState<string[]>([]);
  const [continuousMedications, setContinuousMedications] = useState('');
  const [hasAnticoagulantsOrBisphosphonates, setHasAnticoagulantsOrBisphosphonates] = useState(false);
  const [pregnancyStatus, setPregnancyStatus] = useState<'nao' | 'gestante' | 'lactante'>('nao');
  const [pregnancyDetails, setPregnancyDetails] = useState('');
  const [healingOrBleedingIssues, setHealingOrBleedingIssues] = useState(false);
  const [healingBleedingNotes, setHealingBleedingNotes] = useState('');
  const [habitsSmoking, setHabitsSmoking] = useState<'nao' | 'fumante' | 'ex_fumante'>('nao');
  const [habitsAlcohol, setHabitsAlcohol] = useState<'nao' | 'socialmente' | 'frequente'>('nao');

  // ETAPA 3: Anamnese Odontológica (Histórico Bucal)
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [lastDentalVisit, setLastDentalVisit] = useState('6 a 12 meses');
  const [brushingFrequency, setBrushingFrequency] = useState('3x ou mais ao dia');
  const [flossFrequency, setFlossFrequency] = useState('Diariamente');
  const [sensCold, setSensCold] = useState(false);
  const [sensHot, setSensHot] = useState(false);
  const [sensSweet, setSensSweet] = useState(false);
  const [gumBleeding, setGumBleeding] = useState<'nenhum' | 'ao_escovar' | 'espontaneo'>('nenhum');
  const [jawPainOrClicking, setJawPainOrClicking] = useState(false);
  const [bruxismOrClenching, setBruxismOrClenching] = useState(false);
  const [previousAnestheticReactions, setPreviousAnestheticReactions] = useState('Nenhuma');
  const [dentalNotes, setDentalNotes] = useState('');

  // Validation
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (initialData) {
      setName(initialData.name || '');
      setCpf(initialData.cpf || '');
      setPhone(initialData.phone || '');
      setBirthDate(initialData.birthDate || '');
      setGender(initialData.gender || 'feminino');
      setProfession(initialData.profession || '');
      setAddress(initialData.address || '');
      setEmergencyName(initialData.emergencyContact?.name || '');
      setEmergencyPhone(initialData.emergencyContact?.phone || '');
      setEmergencyRelationship(initialData.emergencyContact?.relationship || '');

      // Saúde Geral
      const gh = initialData.generalHealth;
      setSelectedAllergies(gh?.allergies || initialData.allergies || []);
      setSelectedDiseases(gh?.systemicDiseases || initialData.medicalAlerts || []);
      setContinuousMedications(gh?.continuousMedications || initialData.currentMedications || '');
      setHasAnticoagulantsOrBisphosphonates(gh?.hasAnticoagulantsOrBisphosphonates || false);
      setPregnancyStatus(gh?.pregnancyStatus || (initialData.medicalAlerts?.some((a) => a.toLowerCase().includes('gestante')) ? 'gestante' : 'nao'));
      setPregnancyDetails(gh?.pregnancyDetails || '');
      setHealingOrBleedingIssues(gh?.healingOrBleedingIssues || false);
      setHealingBleedingNotes(gh?.healingBleedingNotes || '');
      setHabitsSmoking(gh?.habitsSmoking || 'nao');
      setHabitsAlcohol(gh?.habitsAlcohol || 'socialmente');

      // Odonto
      const dh = initialData.dentalHealth;
      setChiefComplaint(dh?.chiefComplaint || initialData.notes || '');
      setLastDentalVisit(dh?.lastDentalVisit || '6 a 12 meses');
      setBrushingFrequency(dh?.brushingFrequency || '3x ou mais ao dia');
      setFlossFrequency(dh?.flossFrequency || 'Diariamente');
      setSensCold(dh?.toothSensitivity?.cold || false);
      setSensHot(dh?.toothSensitivity?.hot || false);
      setSensSweet(dh?.toothSensitivity?.sweet || false);
      setGumBleeding(dh?.gumBleeding || 'nenhum');
      setJawPainOrClicking(dh?.tmjOrBruxism?.jawPainOrClicking || false);
      setBruxismOrClenching(dh?.tmjOrBruxism?.bruxismOrClenching || false);
      setPreviousAnestheticReactions(dh?.previousAnestheticReactions || 'Nenhuma');
      setDentalNotes(dh?.additionalNotes || '');
    } else {
      setName('');
      setCpf('');
      setPhone('');
      setBirthDate('');
      setGender('feminino');
      setProfession('');
      setAddress('');
      setEmergencyName('');
      setEmergencyPhone('');
      setEmergencyRelationship('');

      setSelectedAllergies([]);
      setCustomAllergy('');
      setSelectedDiseases([]);
      setContinuousMedications('');
      setHasAnticoagulantsOrBisphosphonates(false);
      setPregnancyStatus('nao');
      setPregnancyDetails('');
      setHealingOrBleedingIssues(false);
      setHealingBleedingNotes('');
      setHabitsSmoking('nao');
      setHabitsAlcohol('nao');

      setChiefComplaint('');
      setLastDentalVisit('6 a 12 meses');
      setBrushingFrequency('3x ou mais ao dia');
      setFlossFrequency('Diariamente');
      setSensCold(false);
      setSensHot(false);
      setSensSweet(false);
      setGumBleeding('nenhum');
      setJawPainOrClicking(false);
      setBruxismOrClenching(false);
      setPreviousAnestheticReactions('Nenhuma');
      setDentalNotes('');
    }
    setCurrentStep(1);
    setErrors({});
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  const calculatedAge = calculateAge(birthDate);

  const toggleAllergy = (allergy: string) => {
    setSelectedAllergies((prev) =>
      prev.includes(allergy) ? prev.filter((a) => a !== allergy) : [...prev, allergy]
    );
  };

  const addCustomAllergy = () => {
    const trimmed = customAllergy.trim();
    if (trimmed && !selectedAllergies.includes(trimmed)) {
      setSelectedAllergies((prev) => [...prev, trimmed]);
      setCustomAllergy('');
    }
  };

  const toggleDisease = (disease: string) => {
    setSelectedDiseases((prev) =>
      prev.includes(disease) ? prev.filter((d) => d !== disease) : [...prev, disease]
    );
  };

  // Step 1 Validation
  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    if (!name.trim()) newErrors.name = 'Nome completo é obrigatório.';
    if (!phone.trim() || phone.replace(/\D/g, '').length < 10) {
      newErrors.phone = 'WhatsApp/Telefone válido é obrigatório.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextFromStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep1()) {
      setCurrentStep(2);
    }
  };

  const handleNextFromStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentStep(3);
  };

  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateStep1()) {
      setCurrentStep(1);
      return;
    }

    // Build consolidated medical alerts array for fast badges and queries
    const compiledAlerts: string[] = [...selectedDiseases];
    if (hasAnticoagulantsOrBisphosphonates) {
      compiledAlerts.push('Uso de Anticoagulante / Bifosfonato');
    }
    if (pregnancyStatus === 'gestante') {
      compiledAlerts.push(pregnancyDetails ? `Gestante (${pregnancyDetails})` : 'Gestante');
    } else if (pregnancyStatus === 'lactante') {
      compiledAlerts.push('Lactante');
    }
    if (healingOrBleedingIssues) {
      compiledAlerts.push('Alerta Hemorragia / Cicatrização');
    }

    const generalHealth: GeneralHealthAnamnesis = {
      allergies: selectedAllergies,
      systemicDiseases: selectedDiseases,
      continuousMedications: continuousMedications.trim(),
      hasAnticoagulantsOrBisphosphonates,
      pregnancyStatus,
      pregnancyDetails: pregnancyDetails.trim(),
      healingOrBleedingIssues,
      healingBleedingNotes: healingBleedingNotes.trim(),
      habitsSmoking,
      habitsAlcohol,
    };

    const dentalHealth: DentalAnamnesis = {
      chiefComplaint: chiefComplaint.trim(),
      lastDentalVisit,
      brushingFrequency,
      flossFrequency,
      toothSensitivity: {
        cold: sensCold,
        hot: sensHot,
        sweet: sensSweet,
      },
      gumBleeding,
      tmjOrBruxism: {
        jawPainOrClicking,
        bruxismOrClenching,
      },
      previousAnestheticReactions: previousAnestheticReactions.trim(),
      additionalNotes: dentalNotes.trim(),
    };

    const emergencyContact: EmergencyContact | undefined = emergencyName.trim()
      ? {
          name: emergencyName.trim(),
          phone: emergencyPhone.trim(),
          relationship: emergencyRelationship.trim(),
        }
      : undefined;

    onSave({
      name: name.trim(),
      cpf: cpf.trim(),
      phone: phone.trim(),
      birthDate,
      gender,
      profession: profession.trim(),
      address: address.trim(),
      emergencyContact,
      allergies: selectedAllergies,
      medicalAlerts: compiledAlerts,
      currentMedications: continuousMedications.trim(),
      notes: chiefComplaint.trim() || dentalNotes.trim(),
      generalHealth,
      dentalHealth,
    });

    onClose();
  };

  const handleTestWhatsApp = () => {
    if (!phone) return;
    const text = `Olá ${name || 'paciente'}, aqui é da clínica da Dra. Pâmela. Confirmando seu contato!`;
    window.open(buildWhatsAppUrl(phone, text), '_blank');
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in">
      <div className="relative w-full sm:max-w-xl max-h-[94vh] sm:max-h-[90vh] rounded-t-3xl sm:rounded-3xl bg-white flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in slide-in-from-bottom-8">
        {/* Wizard Header with Progress Bar */}
        <div className="px-5 pt-4 pb-3 border-b border-slate-100 bg-slate-50/90">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold text-xs">
                {currentStep === 1 ? '1/3' : currentStep === 2 ? '2/3' : '3/3'}
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 leading-tight">
                  {initialData ? 'Editar Cadastro do Paciente' : 'Novo Paciente • Cadastro Clínico'}
                </h3>
                <p className="text-xs text-slate-500">
                  {currentStep === 1 && 'Etapa 1: Dados Pessoais e Contato'}
                  {currentStep === 2 && 'Etapa 2: Anamnese de Saúde Geral (Risco Médico)'}
                  {currentStep === 3 && 'Etapa 3: Anamnese Odontológica (Histórico Bucal)'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper Tabs Bar */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setCurrentStep(1)}
              className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-bold transition-all ${
                currentStep === 1
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span className="truncate">1. Dados</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (validateStep1()) setCurrentStep(2);
              }}
              className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-bold transition-all ${
                currentStep === 2
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <HeartPulse className="w-3.5 h-3.5 text-rose-500" />
              <span className="truncate">2. Saúde Geral</span>
            </button>

            <button
              type="button"
              onClick={() => {
                if (validateStep1()) setCurrentStep(3);
              }}
              className={`flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-xl text-xs font-bold transition-all ${
                currentStep === 3
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Stethoscope className="w-3.5 h-3.5 text-teal-600" />
              <span className="truncate">3. Odonto</span>
            </button>
          </div>

          {/* Progress bar line */}
          <div className="w-full bg-slate-200 h-1 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-teal-600 h-1 transition-all duration-300"
              style={{
                width: currentStep === 1 ? '33.3%' : currentStep === 2 ? '66.6%' : '100%',
              }}
            />
          </div>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* ==================== ETAPA 1 ==================== */}
          {currentStep === 1 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Nome Completo */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: Carlos Eduardo Silva"
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all ${
                    errors.name ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300 bg-white'
                  }`}
                  required
                />
                {errors.name && <p className="text-xs text-rose-600 mt-1">{errors.name}</p>}
              </div>

              {/* CPF e WhatsApp */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    CPF (com máscara)
                  </label>
                  <input
                    type="text"
                    value={cpf}
                    onChange={(e) => setCpf(maskCPF(e.target.value))}
                    placeholder="000.000.000-00"
                    maxLength={14}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      WhatsApp / Celular *
                    </label>
                    {phone.replace(/\D/g, '').length >= 10 && (
                      <button
                        type="button"
                        onClick={handleTestWhatsApp}
                        className="text-[11px] font-semibold text-emerald-700 hover:underline flex items-center gap-1"
                        title="Testar conversa no WhatsApp"
                      >
                        <MessageCircle className="w-3 h-3 text-emerald-600" />
                        Abrir WhatsApp
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(maskPhone(e.target.value))}
                    placeholder="(11) 90000-0000"
                    maxLength={15}
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                      errors.phone ? 'border-rose-400 bg-rose-50/30' : 'border-slate-300 bg-white'
                    }`}
                    required
                  />
                  {errors.phone && <p className="text-xs text-rose-600 mt-1">{errors.phone}</p>}
                </div>
              </div>

              {/* Data de Nascimento e Idade Calculada */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
                      Data de Nascimento
                    </label>
                    {calculatedAge !== null && (
                      <span className="text-xs font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md">
                        {calculatedAge} anos
                      </span>
                    )}
                  </div>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Sexo
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="feminino">Feminino</option>
                    <option value="masculino">Masculino</option>
                    <option value="outro">Outro</option>
                    <option value="prefiro_nao_informar">Prefiro não inf.</option>
                  </select>
                </div>
              </div>

              {/* Profissão e Endereço */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Profissão
                  </label>
                  <input
                    type="text"
                    value={profession}
                    onChange={(e) => setProfession(e.target.value)}
                    placeholder="Ex: Arquiteta, Estudante..."
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Endereço Completo
                  </label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Rua, número, complemento, bairro, cidade"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              {/* Contato de Emergência */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2.5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-teal-600" />
                  Contato de Emergência (Responsável / Familiar)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div className="sm:col-span-1">
                    <input
                      type="text"
                      value={emergencyName}
                      onChange={(e) => setEmergencyName(e.target.value)}
                      placeholder="Nome do contato"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      value={emergencyPhone}
                      onChange={(e) => setEmergencyPhone(maskPhone(e.target.value))}
                      placeholder="Telefone (00) 00000-0000"
                      maxLength={15}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      value={emergencyRelationship}
                      onChange={(e) => setEmergencyRelationship(e.target.value)}
                      placeholder="Parentesco (Ex: Cônjuge, Mãe)"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================== ETAPA 2 ==================== */}
          {currentStep === 2 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="p-3 rounded-2xl bg-rose-50/90 border border-rose-200 text-rose-950 text-xs flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <p>
                  <strong>Atenção Clínica:</strong> As informações desta anamnese definem os alertas vermelhos e precauções anestésicas e cirúrgicas para a Dra. Pâmela.
                </p>
              </div>

              {/* 1. Alergias Medicamentosas */}
              <div className="p-3.5 rounded-2xl bg-rose-50/60 border border-rose-200/80 space-y-2">
                <label className="block text-xs font-bold text-rose-950 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                  Alergias Medicamentosas & Reações Adversas:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {COMMON_ALLERGIES.map((allergy) => {
                    const isSelected = selectedAllergies.includes(allergy);
                    return (
                      <button
                        type="button"
                        key={allergy}
                        onClick={() => toggleAllergy(allergy)}
                        className={`text-xs px-2.5 py-1 rounded-full font-medium transition-all ${
                          isSelected
                            ? 'bg-rose-600 text-white font-bold shadow-xs'
                            : 'bg-white text-rose-800 border border-rose-200 hover:bg-rose-100'
                        }`}
                      >
                        {isSelected && '✓ '}
                        {allergy}
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    value={customAllergy}
                    onChange={(e) => setCustomAllergy(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addCustomAllergy();
                      }
                    }}
                    placeholder="Outra alergia (digite e clique em adicionar)..."
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-rose-200 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                  />
                  <button
                    type="button"
                    onClick={addCustomAllergy}
                    className="px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-100 hover:bg-rose-200 rounded-xl transition-colors"
                  >
                    Adicionar
                  </button>
                </div>
              </div>

              {/* 2. Doenças Sistêmicas */}
              <div className="p-3.5 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-2">
                <label className="block text-xs font-bold text-amber-950 flex items-center gap-1.5">
                  <HeartPulse className="w-3.5 h-3.5 text-amber-600" />
                  Doenças Sistêmicas & Condições Crônicas:
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {COMMON_SYSTEMIC_DISEASES.map((dis) => {
                    const isSelected = selectedDiseases.includes(dis);
                    return (
                      <button
                        type="button"
                        key={dis}
                        onClick={() => toggleDisease(dis)}
                        className={`text-xs px-2.5 py-1 rounded-full font-medium transition-all ${
                          isSelected
                            ? 'bg-amber-600 text-white font-bold shadow-xs'
                            : 'bg-white text-amber-900 border border-amber-200 hover:bg-amber-100'
                        }`}
                      >
                        {isSelected && '✓ '}
                        {dis}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Medicamentos Contínuos & Anticoagulantes */}
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  Medicamentos de Uso Contínuo
                </label>
                <textarea
                  value={continuousMedications}
                  onChange={(e) => setContinuousMedications(e.target.value)}
                  rows={2}
                  placeholder="Ex: Losartana 50mg, Metformina 850mg, Levotiroxina, etc."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
                />

                {/* Checkbox Anticoagulantes / Bifosfonatos */}
                <label className="flex items-start gap-2.5 p-3 rounded-2xl bg-rose-50/70 border border-rose-200/80 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasAnticoagulantsOrBisphosphonates}
                    onChange={(e) => setHasAnticoagulantsOrBisphosphonates(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-rose-600 rounded focus:ring-rose-500"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-rose-900 block">
                      ⚠️ Faz uso de Anticoagulantes ou Bifosfonatos?
                    </span>
                    <span className="text-rose-700 text-[11px]">
                      Atenção redobrada para risco de hemorragia e osteonecrose dos maxilares em cirurgias.
                    </span>
                  </div>
                </label>
              </div>

              {/* 4. Gestante ou Lactante */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                  Condição Gestacional / Lactação
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'nao', label: 'Não' },
                    { id: 'gestante', label: 'Gestante' },
                    { id: 'lactante', label: 'Lactante' },
                  ].map((opt) => (
                    <button
                      type="button"
                      key={opt.id}
                      onClick={() => setPregnancyStatus(opt.id as any)}
                      className={`py-2 rounded-xl text-xs font-semibold transition-all ${
                        pregnancyStatus === opt.id
                          ? 'bg-teal-600 text-white shadow-xs'
                          : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>

                {pregnancyStatus === 'gestante' && (
                  <div className="pt-1">
                    <input
                      type="text"
                      value={pregnancyDetails}
                      onChange={(e) => setPregnancyDetails(e.target.value)}
                      placeholder="Quantas semanas / Qual trimestre? (Ex: 18 semanas - 2º trimestre)"
                      className="w-full px-3 py-1.5 rounded-xl border border-teal-300 text-xs text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-teal-500"
                    />
                  </div>
                )}
              </div>

              {/* 5. Hemorragia / Cicatrização / Quedas de Pressão */}
              <div className="space-y-2">
                <label className="flex items-start gap-2.5 p-3 rounded-2xl bg-amber-50/70 border border-amber-200/80 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={healingOrBleedingIssues}
                    onChange={(e) => setHealingOrBleedingIssues(e.target.checked)}
                    className="mt-0.5 w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-amber-900 block">
                      Histórico de problemas com cicatrização, hemorragias ou lipotimia/desmaio em consultório?
                    </span>
                    <span className="text-amber-800 text-[11px]">
                      Marque se o paciente já teve sangramento prolongado ou quedas bruscas de pressão.
                    </span>
                  </div>
                </label>

                {healingOrBleedingIssues && (
                  <input
                    type="text"
                    value={healingBleedingNotes}
                    onChange={(e) => setHealingBleedingNotes(e.target.value)}
                    placeholder="Descreva o ocorrido (Ex: lipotimia por ansiedade, cicatrização lenta)"
                    className="w-full px-3 py-1.5 rounded-xl border border-amber-300 text-xs text-slate-800 bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                )}
              </div>

              {/* 6. Hábitos: Fumo e Álcool */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Hábito de Fumar (Tabagismo)
                  </label>
                  <select
                    value={habitsSmoking}
                    onChange={(e) => setHabitsSmoking(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="nao">Não fuma</option>
                    <option value="fumante">Fumante ativo</option>
                    <option value="ex_fumante">Ex-fumante</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Consumo de Álcool
                  </label>
                  <select
                    value={habitsAlcohol}
                    onChange={(e) => setHabitsAlcohol(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="nao">Não consome</option>
                    <option value="socialmente">Socialmente</option>
                    <option value="frequente">Consumo frequente</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* ==================== ETAPA 3 ==================== */}
          {currentStep === 3 && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* 1. Queixa Principal */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Queixa Principal (Motivo da Consulta com a Dra. Pâmela) *
                </label>
                <textarea
                  value={chiefComplaint}
                  onChange={(e) => setChiefComplaint(e.target.value)}
                  rows={2}
                  placeholder="Ex: 'Dor ao mastigar no dente do fundo', 'Desejo de clareamento estético', 'Revisão periódica'..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
                  required
                />
              </div>

              {/* 2. Última Consulta ao Dentista */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Quando foi a última consulta ao dentista?
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                  {['Menos de 6 meses', '6 a 12 meses', 'Mais de 1 ano', 'Mais de 2 anos', 'Primeira vez'].map(
                    (opt) => (
                      <button
                        type="button"
                        key={opt}
                        onClick={() => setLastDentalVisit(opt)}
                        className={`py-1.5 px-2 rounded-xl text-xs font-medium transition-all ${
                          lastDentalVisit === opt
                            ? 'bg-teal-600 text-white font-bold shadow-xs'
                            : 'bg-slate-50 text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {opt}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* 3. Hábitos de Higiene Bucal */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Frequência de Escovação
                  </label>
                  <select
                    value={brushingFrequency}
                    onChange={(e) => setBrushingFrequency(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="1x ao dia">1x ao dia</option>
                    <option value="2x ao dia">2x ao dia</option>
                    <option value="3x ou mais ao dia">3x ou mais ao dia</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Uso de Fio Dental
                  </label>
                  <select
                    value={flossFrequency}
                    onChange={(e) => setFlossFrequency(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-800 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="Diariamente">Diariamente</option>
                    <option value="Às vezes">Às vezes</option>
                    <option value="Raramente / Nunca">Raramente / Nunca</option>
                  </select>
                </div>
              </div>

              {/* 4. Sintomas Atuais: Sensibilidade e Sangramento */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    Sensibilidade Dental Atual:
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { state: sensCold, setter: setSensCold, label: '❄️ Frio' },
                      { state: sensHot, setter: setSensHot, label: '☕ Calor' },
                      { state: sensSweet, setter: setSensSweet, label: '🍬 Doce' },
                    ].map((item, i) => (
                      <button
                        type="button"
                        key={i}
                        onClick={() => item.setter(!item.state)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                          item.state
                            ? 'bg-teal-600 text-white shadow-xs'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {item.state && '✓ '}
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    Sangramento Gengival:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'nenhum', label: 'Nenhum' },
                      { id: 'ao_escovar', label: 'Ao escovar / fio' },
                      { id: 'espontaneo', label: 'Espontâneo' },
                    ].map((item) => (
                      <button
                        type="button"
                        key={item.id}
                        onClick={() => setGumBleeding(item.id as any)}
                        className={`py-1.5 px-1 rounded-xl text-xs font-semibold transition-all ${
                          gumBleeding === item.id
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* 5. Articulação e Hábitos Parafuncionais */}
              <div className="p-3.5 rounded-2xl bg-teal-50/60 border border-teal-200/80 space-y-2">
                <label className="block text-xs font-bold text-teal-950">
                  ATM e Hábitos Parafuncionais:
                </label>
                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 text-xs text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={jawPainOrClicking}
                      onChange={(e) => setJawPainOrClicking(e.target.checked)}
                      className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
                    />
                    <span>Dor, estalos ou cansaço na mandíbula / ATM ao mastigar ou bocejar</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs text-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={bruxismOrClenching}
                      onChange={(e) => setBruxismOrClenching(e.target.checked)}
                      className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
                    />
                    <span>Bruxismo (ranger dentes) ou apertamento noturno/diurno</span>
                  </label>
                </div>
              </div>

              {/* 6. Experiências com Anestesia Odontológica */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Reações Prévias ou Desconforto com Anestesia Local
                </label>
                <input
                  type="text"
                  value={previousAnestheticReactions}
                  onChange={(e) => setPreviousAnestheticReactions(e.target.value)}
                  placeholder="Ex: Nenhuma, taquicardia leve, tontura, prefere anestesia sem vaso..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              {/* Notas adicionais */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Observações Clínicas Adicionais da Dra. Pâmela
                </label>
                <textarea
                  value={dentalNotes}
                  onChange={(e) => setDentalNotes(e.target.value)}
                  rows={2}
                  placeholder="Expectativas do paciente, hábitos adicionais, anotações para o exame inicial..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
                />
              </div>
            </div>
          )}
        </div>

        {/* Modal Wizard Navigation Buttons (pb-safe for iPhone) */}
        <div className="px-5 py-3 pb-safe sm:pb-3 border-t border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
          <div>
            {currentStep > 1 && (
              <button
                type="button"
                onClick={() => setCurrentStep((prev) => (prev - 1) as any)}
                className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-95 transition-all"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Voltar</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-100"
            >
              Cancelar
            </button>

            {currentStep === 1 && (
              <button
                type="button"
                onClick={handleNextFromStep1}
                className="inline-flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 shadow-md shadow-teal-600/20 transition-all"
              >
                <span>Saúde Geral</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}

            {currentStep === 2 && (
              <button
                type="button"
                onClick={handleNextFromStep2}
                className="inline-flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 active:scale-95 shadow-md shadow-teal-600/20 transition-all"
              >
                <span>Histórico Odonto</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}

            {currentStep === 3 && (
              <button
                type="button"
                onClick={handleFinalSubmit}
                className="inline-flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-bold text-white bg-teal-700 hover:bg-teal-800 active:scale-95 shadow-md shadow-teal-700/30 transition-all"
              >
                <Check className="w-4 h-4 stroke-[2.5]" />
                <span>{initialData ? 'Salvar Alterações' : 'Concluir Cadastro'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
