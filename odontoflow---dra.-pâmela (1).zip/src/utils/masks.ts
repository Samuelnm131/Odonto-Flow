// CPF mask: 000.000.000-00
export function maskCPF(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  return digits
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
}

// Phone mask: (00) 00000-0000 or (00) 0000-0000
export function maskPhone(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 10) {
    return digits
      .replace(/(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{4})(\d{1,4})$/, '$1-$2');
  }
  return digits
    .replace(/(\d{2})(\d)/, '($1) $2')
    .replace(/(\d{5})(\d{1,4})$/, '$1-$2');
}

// Clean phone digits for WhatsApp URL
export function cleanPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  // If no country code, add Brazilian code (55)
  if (digits.length === 10 || digits.length === 11) {
    return `55${digits}`;
  }
  return digits;
}

// Calculate age from YYYY-MM-DD
export function calculateAge(birthDate: string): number | null {
  if (!birthDate) return null;
  const birth = new Date(birthDate);
  if (isNaN(birth.getTime())) return null;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const m = today.getMonth() - birth.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
}

// Format date to Brazilian format DD/MM/YYYY
export function formatDateBR(dateString: string): string {
  if (!dateString) return '';
  const [year, month, day] = dateString.split('-');
  if (!year || !month || !day) return dateString;
  return `${day}/${month}/${year}`;
}

// Generate friendly WhatsApp URL
export function buildWhatsAppUrl(phone: string, text: string): string {
  const clean = cleanPhone(phone);
  const encoded = encodeURIComponent(text);
  return `https://wa.me/${clean}?text=${encoded}`;
}

// Check if patient has any critical medical/systemic clinical risk
export function hasCriticalClinicalAlert(patient: {
  allergies?: string[];
  medicalAlerts?: string[];
  generalHealth?: {
    allergies?: string[];
    systemicDiseases?: string[];
    hasAnticoagulantsOrBisphosphonates?: boolean;
    pregnancyStatus?: string;
    healingOrBleedingIssues?: boolean;
  };
}): boolean {
  if (patient.allergies && patient.allergies.length > 0) return true;
  if (patient.medicalAlerts && patient.medicalAlerts.length > 0) return true;
  if (patient.generalHealth) {
    const gh = patient.generalHealth;
    if (gh.allergies && gh.allergies.length > 0) return true;
    if (gh.systemicDiseases && gh.systemicDiseases.length > 0) return true;
    if (gh.hasAnticoagulantsOrBisphosphonates) return true;
    if (gh.pregnancyStatus === 'gestante') return true;
    if (gh.healingOrBleedingIssues) return true;
  }
  return false;
}

// FDI Teeth anatomical reference names
export const FDI_TEETH_NAMES: Record<number, string> = {
  // Superior Direito (Q1)
  18: '3º Molar Sup. Dir. (Siso)',
  17: '2º Molar Superior Direito',
  16: '1º Molar Superior Direito',
  15: '2º Pré-Molar Sup. Direito',
  14: '1º Pré-Molar Sup. Direito',
  13: 'Canino Superior Direito',
  12: 'Inc. Lateral Sup. Direito',
  11: 'Inc. Central Sup. Direito',
  // Superior Esquerdo (Q2)
  21: 'Inc. Central Sup. Esquerdo',
  22: 'Inc. Lateral Sup. Esquerdo',
  23: 'Canino Superior Esquerdo',
  24: '1º Pré-Molar Sup. Esquerdo',
  25: '2º Pré-Molar Sup. Esquerdo',
  26: '1º Molar Superior Esquerdo',
  27: '2º Molar Superior Esquerdo',
  28: '3º Molar Sup. Esq. (Siso)',
  // Inferior Esquerdo (Q3)
  38: '3º Molar Inf. Esq. (Siso)',
  37: '2º Molar Inferior Esquerdo',
  36: '1º Molar Inferior Esquerdo',
  35: '2º Pré-Molar Inf. Esquerdo',
  34: '1º Pré-Molar Inf. Esquerdo',
  33: 'Canino Inferior Esquerdo',
  32: 'Inc. Lateral Inf. Esquerdo',
  31: 'Inc. Central Inf. Esquerdo',
  // Inferior Direito (Q4)
  41: 'Inc. Central Inf. Direito',
  42: 'Inc. Lateral Inf. Direito',
  43: 'Canino Inferior Direito',
  44: '1º Pré-Molar Inf. Direito',
  45: '2º Pré-Molar Inf. Direito',
  46: '1º Molar Inferior Direito',
  47: '2º Molar Inferior Direito',
  48: '3º Molar Inf. Dir. (Siso)',

  // Dentes Decíduos (Infantis / Odontopediatria)
  // Superior Direito (Q5)
  55: '2º Molar Decíduo Sup. Dir.',
  54: '1º Molar Decíduo Sup. Dir.',
  53: 'Canino Decíduo Sup. Dir.',
  52: 'Inc. Lateral Decíduo Sup. Dir.',
  51: 'Inc. Central Decíduo Sup. Dir.',
  // Superior Esquerdo (Q6)
  61: 'Inc. Central Decíduo Sup. Esq.',
  62: 'Inc. Lateral Decíduo Sup. Esq.',
  63: 'Canino Decíduo Sup. Esq.',
  64: '1º Molar Decíduo Sup. Esq.',
  65: '2º Molar Decíduo Sup. Esq.',
  // Inferior Esquerdo (Q7)
  75: '2º Molar Decíduo Inf. Esq.',
  74: '1º Molar Decíduo Inf. Esq.',
  73: 'Canino Decíduo Inf. Esq.',
  72: 'Inc. Lateral Decíduo Inf. Esq.',
  71: 'Inc. Central Decíduo Inf. Esq.',
  // Inferior Direito (Q8)
  81: 'Inc. Central Decíduo Inf. Dir.',
  82: 'Inc. Lateral Decíduo Inf. Dir.',
  83: 'Canino Decíduo Inf. Dir.',
  84: '1º Molar Decíduo Inf. Dir.',
  85: '2º Molar Decíduo Inf. Dir.',
};

export const COMMON_PROCEDURES = [
  'Profilaxia e Limpeza',
  'Restauração em Resina Composta',
  'Avaliação Inicial / Check-up',
  'Endodontia (Tratamento de Canal)',
  'Clareamento Dental a Laser',
  'Exodontia Simples (Extração)',
  'Exodontia de Terceiro Molar (Siso)',
  'Aplicação de Flúor / Selante',
  'Ajuste Oclusal / Placa de Bruximsmo',
  'Ortodontia / Alinhadores Invisíveis',
  'Gengivoplastia / Periodontia',
  'Prótese Fixa / Coroa Cerâmica',
];

// Format date to Brazilian full month format
export function formatDateFullBR(dateString: string): string {
  if (!dateString) return '';
  const parts = dateString.split('-');
  if (parts.length !== 3) return dateString;
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const day = parseInt(parts[2], 10);
  if (isNaN(year) || isNaN(month) || isNaN(day)) return dateString;

  const months = [
    'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
    'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'
  ];
  return `${day} de ${months[month - 1]} de ${year}`;
}

export function formatPrescriptionWhatsAppMessage(
  patientName: string,
  medicines: { name: string; quantity: string; posology: string; notes?: string }[],
  date: string,
  generalInstructions?: string
): string {
  let msg = `🦷 *ODONTOFLOW — DRA. PÂMELA MENEGHETTI*\n`;
  msg += `Cirurgiã-Dentista • CRO 24.891\n\n`;
  msg += `📋 *RECEITUÁRIO ODONTOLÓGICO*\n`;
  msg += `*Paciente:* ${patientName}\n`;
  msg += `*Data:* ${formatDateBR(date)}\n\n`;
  msg += `💊 *MEDICAÇÕES PRESCRITAS:*\n`;

  medicines.forEach((med, idx) => {
    msg += `\n*${idx + 1}. ${med.name}* (${med.quantity})\n`;
    msg += `👉 _Posologia:_ ${med.posology}\n`;
    if (med.notes) {
      msg += `ℹ️ _Orientações:_ ${med.notes}\n`;
    }
  });

  if (generalInstructions) {
    msg += `\n⚠️ *Instruções Gerais:*\n${generalInstructions}\n`;
  }

  msg += `\n--------------------------------\n`;
  msg += `Clínica OdontoFlow • Dra. Pâmela Meneghetti\n`;
  msg += `Em caso de dúvidas ou reações imprevistas, entre em contato imediatamente com o consultório.`;

  return msg;
}

export function formatCertificateWhatsAppMessage(
  certificate: {
    certificateType: 'comparecimento' | 'repouso';
    patientName: string;
    patientCpf?: string;
    date: string;
    startTime?: string;
    endTime?: string;
    restDays?: number;
    startDate?: string;
    cid?: string;
    reason?: string;
    notes?: string;
  }
): string {
  let msg = `🦷 *ODONTOFLOW — DRA. PÂMELA MENEGHETTI*\n`;
  msg += `Cirurgiã-Dentista • CRO 24.891\n\n`;

  if (certificate.certificateType === 'comparecimento') {
    msg += `📄 *ATESTADO ODONTOLÓGICO DE COMPARECIMENTO*\n\n`;
    msg += `Atesto para os devidos fins que o(a) paciente *${certificate.patientName}*`;
    if (certificate.patientCpf) {
      msg += `, inscrito(a) no CPF *${certificate.patientCpf}*`;
    }
    msg += `, compareceu a este consultório odontológico no dia *${formatDateBR(certificate.date)}*`;
    if (certificate.startTime && certificate.endTime) {
      msg += `, no período das *${certificate.startTime} às ${certificate.endTime}*`;
    }
    msg += `, para realização de atendimento odontológico.`;
  } else {
    msg += `📄 *ATESTADO ODONTOLÓGICO DE REPOUSO / AFASTAMENTO*\n\n`;
    msg += `Atesto para os devidos fins que o(a) paciente *${certificate.patientName}*`;
    if (certificate.patientCpf) {
      msg += `, inscrito(a) no CPF *${certificate.patientCpf}*`;
    }
    msg += `, foi submetido(a) a procedimento odontológico e necessita de *${certificate.restDays || 1} dia(s) de repouso e afastamento* de suas atividades habituais a contar de *${formatDateBR(certificate.startDate || certificate.date)}*.`;
  }

  if (certificate.cid) {
    msg += `\n\n📌 *CID-10:* ${certificate.cid}`;
  }
  if (certificate.reason) {
    msg += `\n🔍 *Procedimento/Motivo:* ${certificate.reason}`;
  }
  if (certificate.notes) {
    msg += `\n📝 *Observações:* ${certificate.notes}`;
  }

  msg += `\n\nEmitido em: ${formatDateBR(certificate.date)}\n`;
  msg += `*Dra. Pâmela Meneghetti — Cirurgiã-Dentista • CRO 24.891*\n`;
  msg += `OdontoFlow Clínica Odontológica`;

  return msg;
}

