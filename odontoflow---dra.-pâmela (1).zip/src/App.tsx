import React from 'react';
import { AuthProvider } from './context/AuthContext';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { BottomNavigation } from './components/layout/BottomNavigation';
import { DashboardView } from './components/dashboard/DashboardView';
import { PatientsView } from './components/patients/PatientsView';
import { ScheduleView } from './components/schedule/ScheduleView';
import { OdontogramView } from './components/odontogram/OdontogramView';
import { FinancialReportsView } from './components/finance/FinancialReportsView';
import { CheckCircle2, AlertCircle, Info, RefreshCw, Database, Sparkles, Bot } from 'lucide-react';
import { BackupModal } from './components/backup/BackupModal';
import { DocumentsModal } from './components/documents/DocumentsModal';
import { PatientFormModal } from './components/patients/PatientFormModal';
import { AppointmentModal } from './components/schedule/AppointmentModal';
import { GeminiChatbotModal } from './components/chat/GeminiChatbotModal';

const MainContent: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    toast,
    resetToMockData,
    isBackupModalOpen,
    setIsBackupModalOpen,
    isNewPatientOpen,
    patientToEdit,
    closePatientModal,
    addPatient,
    updatePatient,
    isNewAppointmentOpen,
    appointmentToEdit,
    closeAppointmentModal,
    addAppointment,
    updateAppointment,
    appointmentDefaultDate,
    preselectedPatientForAppointment,
    isGeminiChatOpen,
    setIsGeminiChatOpen,
    openGeminiChat,
  } = useApp();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900 pb-24">
      {/* App Header with Dra. Pâmela branding and PWA Install */}
      <Header />

      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed top-18 left-1/2 -translate-x-1/2 z-50 animate-in fade-in slide-in-from-top-4 duration-200">
          <div
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl shadow-xl text-xs font-bold text-white ${
              toast.type === 'error'
                ? 'bg-rose-600'
                : toast.type === 'info'
                ? 'bg-slate-800'
                : 'bg-teal-700'
            }`}
          >
            {toast.type === 'error' ? (
              <AlertCircle className="w-4 h-4" />
            ) : toast.type === 'info' ? (
              <Info className="w-4 h-4" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-teal-200" />
            )}
            <span>{toast.text}</span>
          </div>
        </div>
      )}

      {/* Main View Area (Optimized for iPhone proportion and desktop responsive) */}
      <main className="flex-1 w-full max-w-lg mx-auto px-3.5 pt-3 sm:px-4">
        {activeTab === 'dashboard' && <DashboardView />}
        {activeTab === 'patients' && <PatientsView />}
        {activeTab === 'schedule' && <ScheduleView />}
        {activeTab === 'odontogram' && <OdontogramView />}
        {activeTab === 'finance' && <FinancialReportsView />}

        {/* Small Footer with Backup & Demo Reset */}
        <div className="mt-8 mb-4 text-center space-y-1">
          <p className="text-[11px] text-slate-400">
            OdontoFlow © {new Date().getFullYear()} • Exclusivo para Dra. Pâmela
          </p>
          <div className="flex items-center justify-center gap-3 text-[11px] text-slate-400 pt-1">
            <button
              onClick={() => setIsBackupModalOpen(true)}
              className="inline-flex items-center gap-1 font-semibold text-teal-700 hover:text-teal-800 transition-colors"
            >
              <Database className="w-3.5 h-3.5" />
              <span>Backup & Segurança</span>
            </button>
            <span>•</span>
            <button
              onClick={resetToMockData}
              className="inline-flex items-center gap-1 hover:text-slate-600 transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Restaurar dados demo</span>
            </button>
          </div>
        </div>
      </main>

      {/* Clinical Documents Modal (Receituários e Atestados) */}
      <DocumentsModal />

      {/* Backup and Restore Modal */}
      <BackupModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
      />

      {/* Global Patient Creation / Edit Wizard Modal */}
      <PatientFormModal
        isOpen={isNewPatientOpen || !!patientToEdit}
        onClose={closePatientModal}
        onSave={(data) => {
          if (patientToEdit) {
            updatePatient(patientToEdit.id, data);
          } else {
            addPatient(data);
            setActiveTab('patients');
          }
          closePatientModal();
        }}
        initialData={patientToEdit}
      />

      {/* Global Appointment Modal */}
      <AppointmentModal
        isOpen={isNewAppointmentOpen || !!appointmentToEdit}
        onClose={closeAppointmentModal}
        onSave={(data) => {
          if (appointmentToEdit) {
            updateAppointment(appointmentToEdit.id, data);
          } else {
            addAppointment(data);
          }
          closeAppointmentModal();
        }}
        initialData={appointmentToEdit}
        defaultDate={appointmentDefaultDate}
        defaultPatientId={preselectedPatientForAppointment}
      />

      {/* Floating Gemini AI Assistant Button */}
      <button
        onClick={openGeminiChat}
        className="fixed bottom-20 right-3.5 sm:right-6 z-40 flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-gradient-to-r from-teal-700 via-teal-800 to-slate-900 text-white shadow-xl shadow-teal-900/30 border border-teal-400/30 active:scale-95 hover:scale-105 transition-all group"
        title="Abrir Assistente Clínico Gemini AI"
      >
        <div className="relative">
          <Sparkles className="w-4 h-4 text-teal-300 animate-pulse" />
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400" />
        </div>
        <span className="text-xs font-bold tracking-tight">IA Gemini</span>
      </button>

      {/* Multi-turn Gemini Dental Chatbot Modal */}
      <GeminiChatbotModal
        isOpen={isGeminiChatOpen}
        onClose={() => setIsGeminiChatOpen(false)}
      />

      {/* iOS Style Bottom Navigation Bar */}
      <BottomNavigation />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <MainContent />
      </AppProvider>
    </AuthProvider>
  );
}
