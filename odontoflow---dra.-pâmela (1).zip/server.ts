import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize server-side Gemini client with required User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Gemini Chat Endpoint (Multi-turn conversations)
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, systemInstruction, model } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Lista de mensagens inválida ou vazia.' });
    }

    const selectedModel = model || 'gemini-3.8-flash';

    // Format message history for @google/genai SDK
    const contents = messages.map((m: { sender: string; text: string }) => ({
      role: m.sender === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }],
    }));

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents,
      config: {
        systemInstruction:
          systemInstruction ||
          'Você é o Assistente Odontológico Inteligente da Dra. Pâmela na Clínica OdontoFlow. Auxilie com diagnósticos clínicos, sugestões de medicamentos, orientações pós-operatórias e gestão da clínica com linguagem acolhedora, técnica e profissional.',
      },
    });

    const reply = response.text || 'Desculpe, não consegui gerar uma resposta para esta consulta.';
    res.json({ reply });
  } catch (error: any) {
    console.error('Erro na rota /api/chat Gemini:', error);
    res.status(500).json({
      error: error?.message || 'Erro ao processar mensagem com a IA Gemini.',
    });
  }
});

// Mount Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`OdontoFlow server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
