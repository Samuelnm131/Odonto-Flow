const fs = require('fs');
const zlib = require('zlib');
const path = require('path');

function createPng(width, height, drawFn) {
  const rowBytes = 1 + width * 4;
  const rawData = Buffer.alloc(rowBytes * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowBytes;
    rawData[rowOffset] = 0;
    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const deflated = zlib.deflateSync(rawData);

  const crcTable = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      if (c & 1) c = 0xedb88320 ^ (c >>> 1);
      else c = c >>> 1;
    }
    crcTable[n] = c;
  }

  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const combined = Buffer.concat([typeBuf, data]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(crc32(combined), 0);
    return Buffer.concat([len, combined, crc]);
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8;
  ihdrData[9] = 6;
  ihdrData[10] = 0;
  ihdrData[11] = 0;
  ihdrData[12] = 0;

  const ihdrChunk = makeChunk('IHDR', ihdrData);
  const idatChunk = makeChunk('IDAT', deflated);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function dentalIconDrawer(x, y, w, h) {
  const nx = x / w;
  const ny = y / h;

  const cornerRadius = 0.22;
  let inCorner = false;
  if (nx < cornerRadius && ny < cornerRadius) {
    const dx = nx - cornerRadius, dy = ny - cornerRadius;
    if (dx*dx + dy*dy > cornerRadius*cornerRadius) inCorner = true;
  } else if (nx > 1 - cornerRadius && ny < cornerRadius) {
    const dx = nx - (1 - cornerRadius), dy = ny - cornerRadius;
    if (dx*dx + dy*dy > cornerRadius*cornerRadius) inCorner = true;
  } else if (nx < cornerRadius && ny > 1 - cornerRadius) {
    const dx = nx - cornerRadius, dy = ny - (1 - cornerRadius);
    if (dx*dx + dy*dy > cornerRadius*cornerRadius) inCorner = true;
  } else if (nx > 1 - cornerRadius && ny > 1 - cornerRadius) {
    const dx = nx - (1 - cornerRadius), dy = ny - (1 - cornerRadius);
    if (dx*dx + dy*dy > cornerRadius*cornerRadius) inCorner = true;
  }

  if (inCorner) return [0, 0, 0, 0];

  let r = Math.round(13 + (15 - 13) * ny);
  let g = Math.round(148 + (118 - 148) * ny);
  let b = Math.round(136 + (110 - 136) * ny);
  let a = 255;

  const cx = (nx - 0.5) * 2;
  const cy = (ny - 0.52) * 2;

  let isTooth = false;
  if (cy > -0.65 && cy < 0.65) {
    if (cy <= 0.05) {
      const crownWidth = 0.55 * Math.sqrt(Math.max(0, 1 - Math.pow((cy + 0.1) / 0.6, 2)));
      if (Math.abs(cx) <= crownWidth) isTooth = true;
    } else {
      const rootY = (cy - 0.05) / 0.6;
      const leftRootCenter = -0.22 + rootY * 0.05;
      const rightRootCenter = 0.22 - rootY * 0.05;
      const rootRadius = 0.16 * (1 - rootY * 0.45);

      if (Math.abs(cx - leftRootCenter) < rootRadius && rootY <= 0.95) isTooth = true;
      if (Math.abs(cx - rightRootCenter) < rootRadius && rootY <= 0.95) isTooth = true;
    }
  }

  const scx = cx - 0.4;
  const scy = cy + 0.45;
  const isSparkle = (Math.abs(scx) < 0.035 && Math.abs(scy) < 0.12) ||
                    (Math.abs(scy) < 0.035 && Math.abs(scx) < 0.12);

  if (isSparkle) {
    return [94, 234, 212, 255];
  }

  if (isTooth) {
    return [255, 255, 255, 255];
  }

  return [r, g, b, a];
}

const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), createPng(192, 192, dentalIconDrawer));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), createPng(512, 512, dentalIconDrawer));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), createPng(512, 512, dentalIconDrawer));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), createPng(180, 180, dentalIconDrawer));
console.log('Successfully created PWA icons in /public: pwa-192x192.png, pwa-512x512.png, pwa-maskable-512x512.png, apple-touch-icon.png');
